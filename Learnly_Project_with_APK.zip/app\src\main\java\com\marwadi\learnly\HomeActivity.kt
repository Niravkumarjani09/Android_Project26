package com.marwadi.learnly

import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.View
import android.view.Window
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment

class HomeActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_TAB = "extra_tab"
    }

    private var currentTab: NavTab = NavTab.HOME

    private lateinit var txtWelcome: TextView
    private lateinit var txtSubtitle: TextView
    private lateinit var imgUserAvatar: ImageView
    private lateinit var btnNotification: View

    private lateinit var navHome: View
    private lateinit var navLessons: View
    private lateinit var navPuzzle: View
    private lateinit var navProgress: View
    private lateinit var navProfile: View

    private lateinit var navHomeText: TextView
    private lateinit var navLessonsText: TextView
    private lateinit var navPuzzleText: TextView
    private lateinit var navProgressText: TextView
    private lateinit var navProfileText: TextView

    private lateinit var navHomeIcon: ImageView
    private lateinit var navLessonsIcon: ImageView
    private lateinit var navPuzzleIcon: ImageView
    private lateinit var navProgressIcon: ImageView
    private lateinit var navProfileIcon: ImageView

    private lateinit var navHomeIndicator: View
    private lateinit var navLessonsIndicator: View
    private lateinit var navPuzzleIndicator: View
    private lateinit var navProgressIndicator: View
    private lateinit var navProfileIndicator: View

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        // Initialize header views (Permanent & fixed at top)
        txtWelcome = findViewById(R.id.txtWelcome)
        txtSubtitle = findViewById(R.id.txtSubtitle)
        imgUserAvatar = findViewById(R.id.imgUserAvatar)
        btnNotification = findViewById(R.id.btnNotification)

        // Initialize bottom navigation views (Permanent & fixed at bottom)
        navHome = findViewById(R.id.navHome)
        navLessons = findViewById(R.id.navLessons)
        navPuzzle = findViewById(R.id.navPuzzle)
        navProgress = findViewById(R.id.navProgress)
        navProfile = findViewById(R.id.navProfile)

        navHomeText = findViewById(R.id.navHomeText)
        navLessonsText = findViewById(R.id.navLessonsText)
        navPuzzleText = findViewById(R.id.navPuzzleText)
        navProgressText = findViewById(R.id.navProgressText)
        navProfileText = findViewById(R.id.navProfileText)

        navHomeIcon = findViewById(R.id.navHomeIcon)
        navLessonsIcon = findViewById(R.id.navLessonsIcon)
        navPuzzleIcon = findViewById(R.id.navPuzzleIcon)
        navProgressIcon = findViewById(R.id.navProgressIcon)
        navProfileIcon = findViewById(R.id.navProfileIcon)

        navHomeIndicator = findViewById(R.id.navHomeIndicator)
        navLessonsIndicator = findViewById(R.id.navLessonsIndicator)
        navPuzzleIndicator = findViewById(R.id.navPuzzleIndicator)
        navProgressIndicator = findViewById(R.id.navProgressIndicator)
        navProfileIndicator = findViewById(R.id.navProfileIndicator)

        updateHeaderWelcome()

        // Header actions
        btnNotification.setOnClickListener {
            showNotificationsDialog()
        }

        imgUserAvatar.setOnClickListener {
            switchToTab(NavTab.PROFILE)
        }

        // Bottom nav click handlers - change only the fragment body without switching activity
        navHome.setOnClickListener { switchToTab(NavTab.HOME) }
        navLessons.setOnClickListener { switchToTab(NavTab.LESSONS) }
        navPuzzle.setOnClickListener { switchToTab(NavTab.PUZZLE) }
        navProgress.setOnClickListener { switchToTab(NavTab.PROGRESS) }
        navProfile.setOnClickListener { switchToTab(NavTab.PROFILE) }

        // Handle Back button: if not on HOME, return to HOME first
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (currentTab != NavTab.HOME) {
                    switchToTab(NavTab.HOME)
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })

        // Determine starting tab
        val targetTabName = intent.getStringExtra(EXTRA_TAB)
        val initialTab = if (targetTabName != null) {
            try {
                NavTab.valueOf(targetTabName)
            } catch (_: Exception) {
                NavTab.HOME
            }
        } else {
            NavTab.HOME
        }

        switchToTab(initialTab)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        val targetTabName = intent.getStringExtra(EXTRA_TAB)
        if (targetTabName != null) {
            try {
                val tab = NavTab.valueOf(targetTabName)
                switchToTab(tab)
            } catch (_: Exception) {
            }
        }
    }

    fun switchToTab(tab: NavTab) {
        currentTab = tab

        val activeColor = Color.parseColor("#4361EE")
        val inactiveColor = Color.parseColor("#64748B")

        // Reset all navigation items
        val allTexts = listOf(navHomeText, navLessonsText, navPuzzleText, navProgressText, navProfileText)
        val allIcons = listOf(navHomeIcon, navLessonsIcon, navPuzzleIcon, navProgressIcon, navProfileIcon)
        val allIndicators = listOf(navHomeIndicator, navLessonsIndicator, navPuzzleIndicator, navProgressIndicator, navProfileIndicator)

        allTexts.forEach { it.setTextColor(inactiveColor) }
        allIcons.forEach { it.setColorFilter(inactiveColor) }
        allIndicators.forEach { it.visibility = View.INVISIBLE }

        // Highlight selected tab & update top header subtitle
        val fragment: Fragment = when (tab) {
            NavTab.HOME -> {
                navHomeText.setTextColor(activeColor)
                navHomeIcon.setColorFilter(activeColor)
                navHomeIndicator.visibility = View.VISIBLE
                txtSubtitle.text = "Keep going, you're doing great!"
                HomeFragment()
            }
            NavTab.LESSONS -> {
                navLessonsText.setTextColor(activeColor)
                navLessonsIcon.setColorFilter(activeColor)
                navLessonsIndicator.visibility = View.VISIBLE
                txtSubtitle.text = "Build your language skills step by step"
                LessonsFragment()
            }
            NavTab.PUZZLE -> {
                navPuzzleText.setTextColor(activeColor)
                navPuzzleIcon.setColorFilter(activeColor)
                navPuzzleIndicator.visibility = View.VISIBLE
                txtSubtitle.text = "Solve today's word challenge & earn XP"
                DailyPuzzleFragment()
            }
            NavTab.PROGRESS -> {
                navProgressText.setTextColor(activeColor)
                navProgressIcon.setColorFilter(activeColor)
                navProgressIndicator.visibility = View.VISIBLE
                txtSubtitle.text = "Track your streaks, stats & achievements"
                ProgressFragment()
            }
            NavTab.PROFILE -> {
                navProfileText.setTextColor(activeColor)
                navProfileIcon.setColorFilter(activeColor)
                navProfileIndicator.visibility = View.VISIBLE
                txtSubtitle.text = "Manage your account & learning journey"
                ProfileFragment()
            }
        }

        // Smoothly replace fragment content inside fragmentContainer without changing Activity
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragmentContainer, fragment)
            .commit()
    }

    private fun updateHeaderWelcome() {
        val prefs = getSharedPreferences("LearnlyProfile", MODE_PRIVATE)
        val savedName = prefs.getString("userName", "Nirav") ?: "Nirav"
        txtWelcome.text = "Hello, $savedName! 👋"
    }

    private fun showNotificationsDialog() {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setContentView(R.layout.dialog_notifications)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.setCancelable(true)

        val btnClose = dialog.findViewById<View>(R.id.btnCloseNotifications)
        val btnMarkAllRead = dialog.findViewById<View>(R.id.btnMarkAllRead)
        val layoutList = dialog.findViewById<View>(R.id.layoutNotificationsList)
        val layoutEmpty = dialog.findViewById<View>(R.id.layoutNotificationsEmpty)
        val txtStreakTitle = dialog.findViewById<TextView>(R.id.txtNotifStreakTitle)
        val txtStreakSub = dialog.findViewById<TextView>(R.id.txtNotifStreakSubtitle)

        val notifPrefs = getSharedPreferences("LearnlyNotifications", MODE_PRIVATE)
        val isCleared = notifPrefs.getBoolean("isCleared", false)

        // Read real streak dynamically
        val profilePrefs = getSharedPreferences("LearnlyProfile", MODE_PRIVATE)
        val streak = profilePrefs.getInt("streak", 1)
        txtStreakTitle?.text = "$streak-Day Streak Alive! 🔥"
        txtStreakSub?.text = "Keep learning daily to increase your streak from $streak days."

        if (isCleared) {
            layoutList?.visibility = View.GONE
            layoutEmpty?.visibility = View.VISIBLE
        } else {
            layoutList?.visibility = View.VISIBLE
            layoutEmpty?.visibility = View.GONE
        }

        btnClose?.setOnClickListener {
            dialog.dismiss()
        }

        btnMarkAllRead?.setOnClickListener {
            notifPrefs.edit().putBoolean("isCleared", true).apply()
            layoutList?.visibility = View.GONE
            layoutEmpty?.visibility = View.VISIBLE
            Toast.makeText(this, "Notifications cleared!", Toast.LENGTH_SHORT).show()
        }

        dialog.show()
    }

    override fun onResume() {
        super.onResume()
        updateHeaderWelcome()
    }
}