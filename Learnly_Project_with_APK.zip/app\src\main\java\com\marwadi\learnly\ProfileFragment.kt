package com.marwadi.learnly

import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment

class ProfileFragment : Fragment() {

    private lateinit var txtName: TextView
    private lateinit var txtEmail: TextView
    private lateinit var txtComfortable: TextView
    private lateinit var txtLearn: TextView
    private lateinit var imgFlag1: ImageView
    private lateinit var imgFlag2: ImageView
    private var txtProfileFragStreak: TextView? = null
    private var txtProfileFragXP: TextView? = null
    private var txtProfileFragRank: TextView? = null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_profile, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        txtName = view.findViewById(R.id.txtProfileFragName)
        txtEmail = view.findViewById(R.id.txtProfileFragEmail)
        txtComfortable = view.findViewById(R.id.txtProfileFragComfortable)
        txtLearn = view.findViewById(R.id.txtProfileFragLearn)
        imgFlag1 = view.findViewById(R.id.imgProfileFragFlag1)
        imgFlag2 = view.findViewById(R.id.imgProfileFragFlag2)
        txtProfileFragStreak = view.findViewById(R.id.txtProfileFragStreak)
        txtProfileFragXP = view.findViewById(R.id.txtProfileFragXP)
        txtProfileFragRank = view.findViewById(R.id.txtProfileFragRank)

        val cardLanguagePair = view.findViewById<View>(R.id.cardLanguagePairProfileFrag)
        val menuMyProgress = view.findViewById<View>(R.id.menuFragMyProgress)
        val menuLeaderboard = view.findViewById<View>(R.id.menuFragLeaderboard)
        val menuSettings = view.findViewById<View>(R.id.menuFragSettings)
        val menuHelp = view.findViewById<View>(R.id.menuFragHelp)
        val menuAboutDevelopers = view.findViewById<View>(R.id.menuFragAboutDevelopers)
        val btnLogout = view.findViewById<View>(R.id.btnFragLogout)

        updateProfile()

        cardLanguagePair.setOnClickListener {
            val intent = Intent(requireContext(), LanguageSetupActivity::class.java)
            startActivity(intent)
        }

        menuMyProgress.setOnClickListener {
            (activity as? HomeActivity)?.switchToTab(NavTab.PROGRESS)
        }

        menuLeaderboard.setOnClickListener {
            val intent = Intent(requireContext(), LeaderboardActivity::class.java)
            startActivity(intent)
        }

        menuSettings.setOnClickListener {
            Toast.makeText(requireContext(), "Settings coming soon", Toast.LENGTH_SHORT).show()
        }

        menuHelp.setOnClickListener {
            Toast.makeText(requireContext(), "Help & FAQ coming soon", Toast.LENGTH_SHORT).show()
        }

        menuAboutDevelopers?.setOnClickListener {
            val intent = Intent(requireContext(), AboutDevelopersActivity::class.java)
            startActivity(intent)
        }

        btnLogout.setOnClickListener {
            showLogoutDialog()
        }
    }

    private fun updateProfile() {
        val context = context ?: return
        val prefs = context.getSharedPreferences("LearnlyProfile", Context.MODE_PRIVATE)
        val userName = prefs.getString("userName", "Nirav Jani") ?: "Nirav Jani"
        val userEmail = prefs.getString("userEmail", "niravjani@example.com") ?: "niravjani@example.com"
        val comfortableLanguage = prefs.getString("comfortableLanguage", "Gujarati") ?: "Gujarati"
        val learningLanguage = prefs.getString("learningLanguage", "English") ?: "English"

        txtName.text = userName
        txtEmail.text = userEmail
        txtComfortable.text = comfortableLanguage
        txtLearn.text = learningLanguage

        val streak = UserStatsHelper.getStreak(context)
        val totalXP = UserStatsHelper.getTotalXP(context)
        txtProfileFragStreak?.text = "🔥 $streak"
        txtProfileFragXP?.text = "⭐ ${String.format("%,d", totalXP)}"

        FirebaseHelper.fetchAllStudents { list ->
            if (!isAdded) return@fetchAllStudents
            val userUid = prefs.getString("userUid", "") ?: ""
            val sorted = list.sortedByDescending { it.totalXP * 10000 + it.streak }
            val rankIdx = sorted.indexOfFirst { it.id == userUid || (userEmail.isNotEmpty() && it.email.equals(userEmail, true)) }
            val rank = if (rankIdx != -1) rankIdx + 1 else 1
            txtProfileFragRank?.text = "🏆 #$rank"
        }

        if (comfortableLanguage == "English") {
            imgFlag1.setImageResource(R.drawable.ic_flag_uk)
            imgFlag2.setImageResource(R.drawable.ic_flag_india)
        } else {
            imgFlag1.setImageResource(R.drawable.ic_flag_india)
            imgFlag2.setImageResource(R.drawable.ic_flag_uk)
        }
    }

    private fun showLogoutDialog() {
        val dialog = Dialog(requireContext())
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setContentView(R.layout.dialog_logout_confirmation)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.setCancelable(true)

        val btnConfirm = dialog.findViewById<Button>(R.id.btnConfirmLogout)
        val btnCancel = dialog.findViewById<Button>(R.id.btnCancelLogout)

        btnConfirm.setOnClickListener {
            dialog.dismiss()
            FirebaseHelper.signOut(requireContext())
            val intent = Intent(requireContext(), WelcomeActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            activity?.finish()
        }

        btnCancel.setOnClickListener {
            dialog.dismiss()
        }

        dialog.show()
    }

    override fun onResume() {
        super.onResume()
        updateProfile()
    }
}
