package com.marwadi.learnly

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.view.View
import android.widget.ImageView
import android.widget.TextView

enum class NavTab {
    HOME,
    LESSONS,
    PUZZLE,
    PROGRESS,
    PROFILE
}

object NavigationHelper {

    fun setupBottomNav(activity: Activity, activeTab: NavTab) {
        if (activity is HomeActivity) {
            return
        }

        val navHome = activity.findViewById<View>(R.id.navHome) ?: return
        val navLessons = activity.findViewById<View>(R.id.navLessons)
        val navPuzzle = activity.findViewById<View>(R.id.navPuzzle)
        val navProgress = activity.findViewById<View>(R.id.navProgress)
        val navProfile = activity.findViewById<View>(R.id.navProfile)

        val homeText = activity.findViewById<TextView>(R.id.navHomeText)
        val lessonsText = activity.findViewById<TextView>(R.id.navLessonsText)
        val puzzleText = activity.findViewById<TextView>(R.id.navPuzzleText)
        val progressText = activity.findViewById<TextView>(R.id.navProgressText)
        val profileText = activity.findViewById<TextView>(R.id.navProfileText)

        val homeIcon = activity.findViewById<ImageView>(R.id.navHomeIcon)
        val lessonsIcon = activity.findViewById<ImageView>(R.id.navLessonsIcon)
        val puzzleIcon = activity.findViewById<ImageView>(R.id.navPuzzleIcon)
        val progressIcon = activity.findViewById<ImageView>(R.id.navProgressIcon)
        val profileIcon = activity.findViewById<ImageView>(R.id.navProfileIcon)

        val activeColor = Color.parseColor("#4361EE")
        val inactiveColor = Color.parseColor("#64748B")

        // Reset all
        homeText?.setTextColor(inactiveColor)
        lessonsText?.setTextColor(inactiveColor)
        puzzleText?.setTextColor(inactiveColor)
        progressText?.setTextColor(inactiveColor)
        profileText?.setTextColor(inactiveColor)

        homeIcon?.setColorFilter(inactiveColor)
        lessonsIcon?.setColorFilter(inactiveColor)
        puzzleIcon?.setColorFilter(inactiveColor)
        progressIcon?.setColorFilter(inactiveColor)
        profileIcon?.setColorFilter(inactiveColor)

        // Highlight active tab
        when (activeTab) {
            NavTab.HOME -> {
                homeText?.setTextColor(activeColor)
                homeIcon?.setColorFilter(activeColor)
            }
            NavTab.LESSONS -> {
                lessonsText?.setTextColor(activeColor)
                lessonsIcon?.setColorFilter(activeColor)
            }
            NavTab.PUZZLE -> {
                puzzleText?.setTextColor(activeColor)
                puzzleIcon?.setColorFilter(activeColor)
            }
            NavTab.PROGRESS -> {
                progressText?.setTextColor(activeColor)
                progressIcon?.setColorFilter(activeColor)
            }
            NavTab.PROFILE -> {
                profileText?.setTextColor(activeColor)
                profileIcon?.setColorFilter(activeColor)
            }
        }

        // Click listeners navigate back to HomeActivity with selected tab
        navHome.setOnClickListener {
            navigateToHomeTab(activity, NavTab.HOME)
        }

        navLessons?.setOnClickListener {
            navigateToHomeTab(activity, NavTab.LESSONS)
        }

        navPuzzle?.setOnClickListener {
            navigateToHomeTab(activity, NavTab.PUZZLE)
        }

        navProgress?.setOnClickListener {
            navigateToHomeTab(activity, NavTab.PROGRESS)
        }

        navProfile?.setOnClickListener {
            navigateToHomeTab(activity, NavTab.PROFILE)
        }
    }

    private fun navigateToHomeTab(activity: Activity, tab: NavTab) {
        val intent = Intent(activity, HomeActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra(HomeActivity.EXTRA_TAB, tab.name)
        }
        activity.startActivity(intent)
        if (activity !is HomeActivity) {
            activity.finish()
        }
    }

    fun setupDarkBottomNav(activity: Activity) {
        val navHome = activity.findViewById<View>(R.id.navDarkHome) ?: return
        val navLessons = activity.findViewById<View>(R.id.navDarkLessons)
        val navProgress = activity.findViewById<View>(R.id.navDarkProgress)
        val navProfile = activity.findViewById<View>(R.id.navDarkProfile)

        navHome.setOnClickListener {
            navigateToHomeTab(activity, NavTab.HOME)
        }

        navLessons?.setOnClickListener {
            navigateToHomeTab(activity, NavTab.LESSONS)
        }

        navProgress?.setOnClickListener {
            navigateToHomeTab(activity, NavTab.PROGRESS)
        }

        navProfile?.setOnClickListener {
            navigateToHomeTab(activity, NavTab.PROFILE)
        }
    }
}
