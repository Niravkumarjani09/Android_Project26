package com.marwadi.learnly

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class AdminAddQuestionActivity : AppCompatActivity() {

    private lateinit var edtText: EditText
    private lateinit var spinnerCategory: Spinner
    private lateinit var edtOption1: EditText
    private lateinit var edtOption2: EditText
    private lateinit var edtOption3: EditText
    private lateinit var edtOption4: EditText
    private lateinit var spinnerCorrect: Spinner
    private lateinit var edtExplanation: EditText

    private var editingQuestion: AdminQuestion? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin_add_question)

        val btnBack = findViewById<ImageButton>(R.id.btnBackAddQuestion)
        val txtHeader = findViewById<TextView>(R.id.txtAddQuestionHeaderTitle)
        edtText = findViewById(R.id.edtQuestionTextInput)
        spinnerCategory = findViewById(R.id.spinnerQuestionCategory)
        edtOption1 = findViewById(R.id.edtOption1)
        edtOption2 = findViewById(R.id.edtOption2)
        edtOption3 = findViewById(R.id.edtOption3)
        edtOption4 = findViewById(R.id.edtOption4)
        spinnerCorrect = findViewById(R.id.spinnerCorrectAnswer)
        edtExplanation = findViewById(R.id.edtQuestionExplanation)
        val btnCancel = findViewById<Button>(R.id.btnCancelAddQuestion)
        val btnSave = findViewById<Button>(R.id.btnSaveQuestion)

        btnBack.setOnClickListener { finish() }
        btnCancel.setOnClickListener { finish() }

        // Setup Category Spinner
        val categories = listOf("Vocabulary", "Sentence", "Grammar")
        val catAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, categories)
        spinnerCategory.adapter = catAdapter

        // Setup Correct Answer Spinner
        val answerLabels = listOf("Option 1", "Option 2", "Option 3", "Option 4")
        val ansAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, answerLabels)
        spinnerCorrect.adapter = ansAdapter

        // Check if editing
        @Suppress("DEPRECATION")
        editingQuestion = intent.getSerializableExtra("EXTRA_QUESTION") as? AdminQuestion
        editingQuestion?.let { q ->
            txtHeader.text = "Edit Question"
            edtText.setText(q.questionText)
            edtExplanation.setText(q.explanation)

            val catIndex = categories.indexOf(q.categoryTag)
            if (catIndex != -1) spinnerCategory.setSelection(catIndex)

            if (q.options.isNotEmpty()) edtOption1.setText(q.options.getOrNull(0) ?: "")
            if (q.options.size > 1) edtOption2.setText(q.options.getOrNull(1) ?: "")
            if (q.options.size > 2) edtOption3.setText(q.options.getOrNull(2) ?: "")
            if (q.options.size > 3) edtOption4.setText(q.options.getOrNull(3) ?: "")

            if (q.correctAnswerIndex in answerLabels.indices) {
                spinnerCorrect.setSelection(q.correctAnswerIndex)
            }
        }

        btnSave.setOnClickListener {
            val text = edtText.text.toString().trim()
            val category = spinnerCategory.selectedItem.toString()
            val opt1 = edtOption1.text.toString().trim()
            val opt2 = edtOption2.text.toString().trim()
            val opt3 = edtOption3.text.toString().trim()
            val opt4 = edtOption4.text.toString().trim()
            val correctIndex = spinnerCorrect.selectedItemPosition
            val explanation = edtExplanation.text.toString().trim()

            if (text.isEmpty()) {
                edtText.error = "Please enter question text"
                return@setOnClickListener
            }

            if (opt1.isEmpty() || opt2.isEmpty()) {
                Toast.makeText(this, "Please enter at least Option 1 and Option 2", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val optionsList = listOf(
                opt1,
                opt2,
                if (opt3.isNotEmpty()) opt3 else "None of the above",
                if (opt4.isNotEmpty()) opt4 else "All of the above"
            )

            if (editingQuestion != null) {
                editingQuestion?.let {
                    it.questionText = text
                    it.categoryTag = category
                    it.options = optionsList
                    it.correctAnswerIndex = correctIndex
                    it.explanation = explanation
                    AdminDataRepository.updateQuestion(it)
                    Toast.makeText(this, "Question updated successfully", Toast.LENGTH_SHORT).show()
                }
            } else {
                val newQuestion = AdminQuestion(
                    id = "q_${System.currentTimeMillis()}",
                    questionText = text,
                    categoryTag = category,
                    sourceLanguage = "English",
                    targetLanguage = "Gujarati",
                    options = optionsList,
                    correctAnswerIndex = correctIndex,
                    explanation = explanation
                )
                AdminDataRepository.addQuestion(newQuestion)
                Toast.makeText(this, "Question created successfully", Toast.LENGTH_SHORT).show()
            }

            finish()
        }
    }
}

