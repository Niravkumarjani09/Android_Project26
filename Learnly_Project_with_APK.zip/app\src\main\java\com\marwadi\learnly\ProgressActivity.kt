package com.marwadi.learnly

import android.os.Bundle
import android.view.View
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class ProgressActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_progress)

        NavigationHelper.setupBottomNav(this, NavTab.PROGRESS)

        val btnBack = findViewById<ImageButton>(R.id.btnBackProgress)
        btnBack.setOnClickListener {
            finish()
        }

        val tabOverview = findViewById<TextView>(R.id.tabOverview)
        val tabDetailed = findViewById<TextView>(R.id.tabDetailed)

        val layoutOverviewSection = findViewById<View>(R.id.layoutOverviewSection)
        val layoutDetailedSection = findViewById<View>(R.id.layoutDetailedSection)

        tabOverview.setOnClickListener {
            tabOverview.setBackgroundResource(R.drawable.bg_tab_active)
            tabOverview.setTextColor(getColor(R.color.white))
            tabDetailed.setBackgroundResource(R.drawable.bg_tab_inactive)
            tabDetailed.setTextColor(getColor(R.color.text_muted))

            layoutOverviewSection.visibility = View.VISIBLE
            layoutDetailedSection.visibility = View.GONE
        }

        tabDetailed.setOnClickListener {
            tabDetailed.setBackgroundResource(R.drawable.bg_tab_active)
            tabDetailed.setTextColor(getColor(R.color.white))
            tabOverview.setBackgroundResource(R.drawable.bg_tab_inactive)
            tabOverview.setTextColor(getColor(R.color.text_muted))

            layoutOverviewSection.visibility = View.GONE
            layoutDetailedSection.visibility = View.VISIBLE
        }

        renderDynamicProgress()
    }

    private fun renderDynamicProgress() {
        val profilePrefs = getSharedPreferences("LearnlyProfile", MODE_PRIVATE)
        val progressPrefs = getSharedPreferences("LearnlyProgress", MODE_PRIVATE)

        val streak = UserStatsHelper.getStreak(this)
        val accuracy = UserStatsHelper.getAccuracy(this)
        val overallPercent = UserStatsHelper.getOverallProgressPercent(this)

        val wordsCompleted = progressPrefs.getInt("wordsCompleted", 0)
        val sentencesCompleted = progressPrefs.getInt("sentencesCompleted", 0)
        val grammarCompleted = progressPrefs.getInt("grammarCompleted", 0)

        val totalWords = 15
        val totalSentences = 20
        val totalGrammar = 15

        // Overview stats
        val txtStreak = findViewById<TextView>(R.id.txtProgressStreak)
        val txtAccuracy = findViewById<TextView>(R.id.txtProgressAccuracy)
        val progressGauge = findViewById<android.widget.ProgressBar>(R.id.progressGauge)
        val txtOverallPercent = findViewById<TextView>(R.id.txtOverallProgressPercent)

        txtStreak?.text = streak.toString()
        txtAccuracy?.text = "$accuracy%"
        progressGauge?.progress = overallPercent
        txtOverallPercent?.text = "$overallPercent%"

        // Dynamic weekly study time
        val txtStudyTimeWeek = findViewById<TextView>(R.id.txtStudyTimeWeek)
        val txtStudyTimeAvg = findViewById<TextView>(R.id.txtStudyTimeAvg)
        val (totalStudyTime, dailyAvgStudy) = UserStatsHelper.getFormattedStudyTime(this)
        txtStudyTimeWeek?.text = totalStudyTime
        txtStudyTimeAvg?.text = dailyAvgStudy

        // Skills progress
        val txtSkillVocab = findViewById<TextView>(R.id.txtSkillVocabPercent)
        val progSkillVocab = findViewById<android.widget.ProgressBar>(R.id.progressSkillVocab)
        val txtSkillGrammar = findViewById<TextView>(R.id.txtSkillGrammarPercent)
        val progSkillGrammar = findViewById<android.widget.ProgressBar>(R.id.progressSkillGrammar)

        val vocabPercent = ((wordsCompleted * 100) / totalWords).coerceIn(0, 100)
        txtSkillVocab?.text = "$vocabPercent%"
        progSkillVocab?.progress = vocabPercent

        val grammarPercent = ((grammarCompleted * 100) / totalGrammar).coerceIn(0, 100)
        txtSkillGrammar?.text = "$grammarPercent%"
        progSkillGrammar?.progress = grammarPercent

        // Detailed lesson status
        val txtWordsStatus = findViewById<TextView>(R.id.txtStatusWordsRatio)
        val progWordsStatus = findViewById<android.widget.ProgressBar>(R.id.progressStatusWords)
        val txtSentencesStatus = findViewById<TextView>(R.id.txtStatusSentencesRatio)
        val progSentencesStatus = findViewById<android.widget.ProgressBar>(R.id.progressStatusSentences)
        val txtGrammarStatus = findViewById<TextView>(R.id.txtStatusGrammarRatio)
        val progGrammarStatus = findViewById<android.widget.ProgressBar>(R.id.progressStatusGrammar)

        txtWordsStatus?.text = "$wordsCompleted / $totalWords completed ($vocabPercent%)"
        progWordsStatus?.progress = wordsCompleted

        val sentencesPercent = ((sentencesCompleted * 100) / totalSentences).coerceIn(0, 100)
        txtSentencesStatus?.text = "$sentencesCompleted / $totalSentences completed ($sentencesPercent%)"
        progSentencesStatus?.progress = sentencesCompleted

        txtGrammarStatus?.text = "$grammarCompleted / $totalGrammar completed ($grammarPercent%)"
        progGrammarStatus?.progress = grammarCompleted
    }

    override fun onResume() {
        super.onResume()
        NavigationHelper.setupBottomNav(this, NavTab.PROGRESS)
        renderDynamicProgress()
    }
}
