package com.marwadi.learnly

import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment

enum class AdminNavTab {
    DASHBOARD, LESSONS, QUESTIONS, STUDENTS, REPORTS
}

class AdminMainActivity : AppCompatActivity() {

    private var currentTab: AdminNavTab = AdminNavTab.DASHBOARD

    private lateinit var navDashboard: View
    private lateinit var navLessons: View
    private lateinit var navQuestions: View
    private lateinit var navStudents: View
    private lateinit var navReports: View

    private lateinit var navDashboardText: TextView
    private lateinit var navLessonsText: TextView
    private lateinit var navQuestionsText: TextView
    private lateinit var navStudentsText: TextView
    private lateinit var navReportsText: TextView

    private lateinit var navDashboardIcon: ImageView
    private lateinit var navLessonsIcon: ImageView
    private lateinit var navQuestionsIcon: ImageView
    private lateinit var navStudentsIcon: ImageView
    private lateinit var navReportsIcon: ImageView

    private lateinit var navDashboardIndicator: View
    private lateinit var navLessonsIndicator: View
    private lateinit var navQuestionsIndicator: View
    private lateinit var navStudentsIndicator: View
    private lateinit var navReportsIndicator: View

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin_main)

        navDashboard = findViewById(R.id.adminNavDashboard)
        navLessons = findViewById(R.id.adminNavLessons)
        navQuestions = findViewById(R.id.adminNavQuestions)
        navStudents = findViewById(R.id.adminNavStudents)
        navReports = findViewById(R.id.adminNavReports)

        navDashboardText = findViewById(R.id.adminNavDashboardText)
        navLessonsText = findViewById(R.id.adminNavLessonsText)
        navQuestionsText = findViewById(R.id.adminNavQuestionsText)
        navStudentsText = findViewById(R.id.adminNavStudentsText)
        navReportsText = findViewById(R.id.adminNavReportsText)

        navDashboardIcon = findViewById(R.id.adminNavDashboardIcon)
        navLessonsIcon = findViewById(R.id.adminNavLessonsIcon)
        navQuestionsIcon = findViewById(R.id.adminNavQuestionsIcon)
        navStudentsIcon = findViewById(R.id.adminNavStudentsIcon)
        navReportsIcon = findViewById(R.id.adminNavReportsIcon)

        navDashboardIndicator = findViewById(R.id.adminNavDashboardIndicator)
        navLessonsIndicator = findViewById(R.id.adminNavLessonsIndicator)
        navQuestionsIndicator = findViewById(R.id.adminNavQuestionsIndicator)
        navStudentsIndicator = findViewById(R.id.adminNavStudentsIndicator)
        navReportsIndicator = findViewById(R.id.adminNavReportsIndicator)

        navDashboard.setOnClickListener { switchToTab(AdminNavTab.DASHBOARD) }
        navLessons.setOnClickListener { switchToTab(AdminNavTab.LESSONS) }
        navQuestions.setOnClickListener { switchToTab(AdminNavTab.QUESTIONS) }
        navStudents.setOnClickListener { switchToTab(AdminNavTab.STUDENTS) }
        navReports.setOnClickListener { switchToTab(AdminNavTab.REPORTS) }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (currentTab != AdminNavTab.DASHBOARD) {
                    switchToTab(AdminNavTab.DASHBOARD)
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })

        switchToTab(AdminNavTab.DASHBOARD)
    }

    fun switchToTab(tab: AdminNavTab) {
        currentTab = tab

        val activeColor = Color.parseColor("#5956E9")
        val inactiveColor = Color.parseColor("#64748B")

        val allTexts = listOf(navDashboardText, navLessonsText, navQuestionsText, navStudentsText, navReportsText)
        val allIcons = listOf(navDashboardIcon, navLessonsIcon, navQuestionsIcon, navStudentsIcon, navReportsIcon)
        val allIndicators = listOf(navDashboardIndicator, navLessonsIndicator, navQuestionsIndicator, navStudentsIndicator, navReportsIndicator)

        allTexts.forEach { it.setTextColor(inactiveColor) }
        allIcons.forEach { it.setColorFilter(inactiveColor) }
        allIndicators.forEach { it.visibility = View.INVISIBLE }

        val fragment: Fragment = when (tab) {
            AdminNavTab.DASHBOARD -> {
                navDashboardText.setTextColor(activeColor)
                navDashboardIcon.setColorFilter(activeColor)
                navDashboardIndicator.visibility = View.VISIBLE
                AdminDashboardFragment()
            }
            AdminNavTab.LESSONS -> {
                navLessonsText.setTextColor(activeColor)
                navLessonsIcon.setColorFilter(activeColor)
                navLessonsIndicator.visibility = View.VISIBLE
                AdminLessonsFragment()
            }
            AdminNavTab.QUESTIONS -> {
                navQuestionsText.setTextColor(activeColor)
                navQuestionsIcon.setColorFilter(activeColor)
                navQuestionsIndicator.visibility = View.VISIBLE
                AdminQuestionsFragment()
            }
            AdminNavTab.STUDENTS -> {
                navStudentsText.setTextColor(activeColor)
                navStudentsIcon.setColorFilter(activeColor)
                navStudentsIndicator.visibility = View.VISIBLE
                AdminStudentsFragment()
            }
            AdminNavTab.REPORTS -> {
                navReportsText.setTextColor(activeColor)
                navReportsIcon.setColorFilter(activeColor)
                navReportsIndicator.visibility = View.VISIBLE
                AdminReportsFragment()
            }
        }

        supportFragmentManager.beginTransaction()
            .replace(R.id.adminFragmentContainer, fragment)
            .commit()
    }
}

