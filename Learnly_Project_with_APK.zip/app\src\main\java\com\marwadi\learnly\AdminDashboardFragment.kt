package com.marwadi.learnly

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment

class AdminDashboardFragment : Fragment() {

    private lateinit var txtTotalStudentsCount: TextView
    private lateinit var txtTotalLessonsCount: TextView
    private lateinit var txtTotalQuestionsCount: TextView
    private lateinit var txtPuzzlesCompletedCount: TextView
    private lateinit var recentActivityContainer: LinearLayout

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_admin_dashboard, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        txtTotalStudentsCount = view.findViewById(R.id.txtTotalStudentsCount)
        txtTotalLessonsCount = view.findViewById(R.id.txtTotalLessonsCount)
        txtTotalQuestionsCount = view.findViewById(R.id.txtTotalQuestionsCount)
        txtPuzzlesCompletedCount = view.findViewById(R.id.txtPuzzlesCompletedCount)
        recentActivityContainer = view.findViewById(R.id.recentActivityContainer)

        val btnAdminProfilePill = view.findViewById<View>(R.id.btnAdminProfilePill)
        val btnQuickAddLesson = view.findViewById<View>(R.id.btnQuickAddLesson)
        val btnQuickAddQuestion = view.findViewById<View>(R.id.btnQuickAddQuestion)
        val btnSeedCurriculum = view.findViewById<View>(R.id.btnSeedCurriculum)
        val btnViewAllActivity = view.findViewById<View>(R.id.btnViewAllActivity)

        // Ensure repository has curriculum loaded
        AdminDataRepository.initFromSeed(requireContext())

        btnAdminProfilePill.setOnClickListener {
            (activity as? AdminMainActivity)?.switchToTab(AdminNavTab.REPORTS)
        }

        btnQuickAddLesson.setOnClickListener {
            val intent = Intent(requireContext(), AdminAddLessonActivity::class.java)
            startActivity(intent)
        }

        btnQuickAddQuestion.setOnClickListener {
            val intent = Intent(requireContext(), AdminAddQuestionActivity::class.java)
            startActivity(intent)
        }

        btnSeedCurriculum?.setOnClickListener {
            Toast.makeText(requireContext(), "Publishing curriculum to Cloud Firestore...", Toast.LENGTH_SHORT).show()
            FirebaseHelper.seedCurriculumToFirestore(requireContext()) { success, count, error ->
                if (success) {
                    AdminDataRepository.initFromSeed(requireContext())
                    refreshData()
                    Toast.makeText(requireContext(), "🎉 Live sync complete! $count records published to Firestore.", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(requireContext(), "Notice: Local seed loaded ($count items)", Toast.LENGTH_SHORT).show()
                }
            }
        }

        btnViewAllActivity.setOnClickListener {
            Toast.makeText(requireContext(), "Displaying all recent system events", Toast.LENGTH_SHORT).show()
        }

        refreshData()
    }

    override fun onResume() {
        super.onResume()
        refreshData()
    }

    private fun refreshData() {
        FirebaseHelper.fetchAllStudents { studentsList ->
            if (isAdded) {
                txtTotalStudentsCount.text = studentsList.size.toString()
            }
        }

        val stats = AdminDataRepository.getStats()
        txtTotalLessonsCount.text = stats.totalLessons.toString()
        txtTotalQuestionsCount.text = String.format("%,d", stats.totalQuestions)
        txtPuzzlesCompletedCount.text = stats.puzzlesCompleted.toString()

        // Populate recent activities dynamically from Cloud Firestore
        FirebaseHelper.fetchRecentActivities { activities ->
            if (!isAdded) return@fetchRecentActivities
            recentActivityContainer.removeAllViews()
            val inflater = LayoutInflater.from(requireContext())

            for (item in activities) {
                val itemView = inflater.inflate(R.layout.item_admin_recent_activity, recentActivityContainer, false)
                val txtTitle = itemView.findViewById<TextView>(R.id.txtActivityTitle)
                val txtSubtitle = itemView.findViewById<TextView>(R.id.txtActivitySubtitle)
                val txtTimeAgo = itemView.findViewById<TextView>(R.id.txtActivityTimeAgo)
                val imgIcon = itemView.findViewById<ImageView>(R.id.imgActivityIcon)

                txtTitle.text = item.title
                txtSubtitle.text = item.subtitle
                txtTimeAgo.text = item.timeAgo

                when (item.type) {
                    "student" -> {
                        imgIcon.setImageResource(R.drawable.ic_students)
                        imgIcon.setColorFilter(resources.getColor(R.color.brand_primary, null))
                    }
                    "lesson" -> {
                        imgIcon.setImageResource(R.drawable.ic_book)
                        imgIcon.setColorFilter(resources.getColor(R.color.brand_green_dark, null))
                    }
                    "question" -> {
                        imgIcon.setImageResource(R.drawable.ic_help)
                        imgIcon.setColorFilter(resources.getColor(R.color.accent_orange_start, null))
                    }
                    else -> {
                        imgIcon.setImageResource(R.drawable.ic_crown)
                        imgIcon.setColorFilter(resources.getColor(R.color.brand_secondary, null))
                    }
                }

                recentActivityContainer.addView(itemView)
            }
        }
    }
}
