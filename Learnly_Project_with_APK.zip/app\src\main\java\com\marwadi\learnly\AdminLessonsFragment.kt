package com.marwadi.learnly

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment

class AdminLessonsFragment : Fragment() {

    private lateinit var edtSearchLessons: EditText
    private lateinit var lessonsContainer: LinearLayout
    private lateinit var chipAll: TextView
    private lateinit var chipWords: TextView
    private lateinit var chipSentences: TextView
    private lateinit var chipGrammar: TextView

    private var selectedCategory: String = "All"
    private var searchQuery: String = ""

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_admin_lessons, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        edtSearchLessons = view.findViewById(R.id.edtSearchLessons)
        lessonsContainer = view.findViewById(R.id.adminLessonsContainer)
        chipAll = view.findViewById(R.id.chipFilterAllLessons)
        chipWords = view.findViewById(R.id.chipFilterBasicWords)
        chipSentences = view.findViewById(R.id.chipFilterBasicSentences)
        chipGrammar = view.findViewById(R.id.chipFilterGrammar)

        val btnAddLessonTop = view.findViewById<ImageButton>(R.id.btnAddLessonTop)
        btnAddLessonTop.setOnClickListener {
            val intent = Intent(requireContext(), AdminAddLessonActivity::class.java)
            startActivity(intent)
        }

        // Chip filter handlers
        chipAll.setOnClickListener { setCategoryFilter("All") }
        chipWords.setOnClickListener { setCategoryFilter("Basic Words") }
        chipSentences.setOnClickListener { setCategoryFilter("Basic Sentences") }
        chipGrammar.setOnClickListener { setCategoryFilter("Everyday Grammar") }

        edtSearchLessons.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                searchQuery = s?.toString()?.trim() ?: ""
                renderLessons()
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        renderLessons()
    }

    override fun onResume() {
        super.onResume()
        renderLessons()
    }

    private fun setCategoryFilter(category: String) {
        selectedCategory = category

        val chips = listOf(chipAll, chipWords, chipSentences, chipGrammar)
        for (c in chips) {
            c.setBackgroundResource(R.drawable.bg_admin_chip_unselected)
            c.setTextColor(resources.getColor(R.color.text_body, null))
        }

        val activeChip = when (category) {
            "Basic Words" -> chipWords
            "Basic Sentences" -> chipSentences
            "Everyday Grammar" -> chipGrammar
            else -> chipAll
        }

        activeChip.setBackgroundResource(R.drawable.bg_admin_chip_selected)
        activeChip.setTextColor(resources.getColor(R.color.white, null))

        renderLessons()
    }

    private fun renderLessons() {
        lessonsContainer.removeAllViews()
        val inflater = LayoutInflater.from(requireContext())
        var lessons = AdminDataRepository.getLessons()

        if (selectedCategory != "All") {
            lessons = lessons.filter { it.category.equals(selectedCategory, ignoreCase = true) }
        }

        if (searchQuery.isNotEmpty()) {
            lessons = lessons.filter {
                it.title.contains(searchQuery, ignoreCase = true) ||
                it.description.contains(searchQuery, ignoreCase = true) ||
                it.sourceLanguage.contains(searchQuery, ignoreCase = true) ||
                it.targetLanguage.contains(searchQuery, ignoreCase = true)
            }
        }

        if (lessons.isEmpty()) {
            val emptyView = TextView(requireContext()).apply {
                text = "No lessons found matching criteria"
                setTextColor(resources.getColor(R.color.text_muted, null))
                textSize = 14f
                setPadding(20, 60, 20, 40)
                gravity = android.view.Gravity.CENTER
            }
            lessonsContainer.addView(emptyView)
            return
        }

        for (lesson in lessons) {
            val itemView = inflater.inflate(R.layout.item_admin_lesson, lessonsContainer, false)
            val imgCategoryIcon = itemView.findViewById<ImageView>(R.id.imgLessonCategoryIcon)
            val txtTitle = itemView.findViewById<TextView>(R.id.txtLessonTitle)
            val txtDescription = itemView.findViewById<TextView>(R.id.txtLessonDescription)
            val txtLanguagePair = itemView.findViewById<TextView>(R.id.txtLessonLanguagePair)
            val txtQuestionCount = itemView.findViewById<TextView>(R.id.txtLessonQuestionCount)
            val btnEdit = itemView.findViewById<ImageButton>(R.id.btnEditLesson)
            val btnDelete = itemView.findViewById<ImageButton>(R.id.btnDeleteLesson)

            txtTitle.text = lesson.title
            txtDescription.text = lesson.description
            txtLanguagePair.text = "${lesson.sourceLanguage} → ${lesson.targetLanguage}"
            txtQuestionCount.text = "${lesson.questionCount} questions"

            when (lesson.category) {
                "Basic Words" -> {
                    imgCategoryIcon.setBackgroundResource(R.drawable.bg_badge_active)
                    imgCategoryIcon.setImageResource(R.drawable.ic_book)
                    imgCategoryIcon.setColorFilter(resources.getColor(R.color.brand_green_dark, null))
                }
                "Basic Sentences" -> {
                    imgCategoryIcon.setBackgroundResource(R.drawable.bg_badge_tag)
                    imgCategoryIcon.setImageResource(R.drawable.ic_chat)
                    imgCategoryIcon.setColorFilter(resources.getColor(R.color.brand_primary, null))
                }
                else -> {
                    imgCategoryIcon.setBackgroundResource(R.drawable.bg_badge_tag)
                    imgCategoryIcon.setImageResource(R.drawable.ic_grammar)
                    imgCategoryIcon.setColorFilter(resources.getColor(R.color.accent_purple_card_start, null))
                }
            }

            btnEdit.setOnClickListener {
                val intent = Intent(requireContext(), AdminAddLessonActivity::class.java).apply {
                    putExtra("EXTRA_LESSON", lesson)
                }
                startActivity(intent)
            }

            btnDelete.setOnClickListener {
                AlertDialog.Builder(requireContext())
                    .setTitle("Delete Lesson")
                    .setMessage("Are you sure you want to delete '${lesson.title}'?")
                    .setPositiveButton("Delete") { _, _ ->
                        AdminDataRepository.deleteLesson(lesson.id)
                        Toast.makeText(requireContext(), "Lesson deleted", Toast.LENGTH_SHORT).show()
                        renderLessons()
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            }

            lessonsContainer.addView(itemView)
        }
    }
}

