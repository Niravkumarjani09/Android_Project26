package com.marwadi.learnly

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.widget.AppCompatButton
import androidx.fragment.app.Fragment

class DailyPuzzleFragment : Fragment() {

    data class PuzzleWord(val word: String, val hint: String)

    private val puzzlePool = listOf(
        PuzzleWord("LEARN", "To gain knowledge or skill through study"),
        PuzzleWord("SMART", "Having or showing quick intelligence"),
        PuzzleWord("BRAIN", "The organ of thinking and memory"),
        PuzzleWord("WORDS", "Units of language used for communication"),
        PuzzleWord("STUDY", "Applying mental effort to acquire knowledge"),
        PuzzleWord("SPEAK", "Expressing thoughts through spoken words"),
        PuzzleWord("WRITE", "Marking letters on paper or screen"),
        PuzzleWord("FOCUS", "Directing your attention to one goal"),
        PuzzleWord("SHINE", "Giving out bright light or standing out"),
        PuzzleWord("QUICK", "Moving or learning with great speed"),
        PuzzleWord("DREAM", "A cherished aspiration or ambition"),
        PuzzleWord("GUIDE", "Directing or pointing out the way"),
        PuzzleWord("PEACE", "State of harmony and calmness"),
        PuzzleWord("WATER", "The essential fluid of all life"),
        PuzzleWord("APPLE", "A popular crisp, sweet fruit")
    )

    private var targetWord = "LEARN"
    private var targetHint = ""
    private var scrambledLetters = mutableListOf<String>()
    private val selectedLetters = mutableListOf<String>()
    private var hintsLeft = 3

    private lateinit var slotViews: List<TextView>
    private lateinit var bubbleViews: List<TextView>
    private lateinit var txtHintCount: TextView
    private var txtPuzzlePromptFrag: TextView? = null
    private var txtPuzzleStreak: TextView? = null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_daily_puzzle, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val slot1 = view.findViewById<TextView>(R.id.slotFrag1)
        val slot2 = view.findViewById<TextView>(R.id.slotFrag2)
        val slot3 = view.findViewById<TextView>(R.id.slotFrag3)
        val slot4 = view.findViewById<TextView>(R.id.slotFrag4)
        val slot5 = view.findViewById<TextView>(R.id.slotFrag5)
        slotViews = listOf(slot1, slot2, slot3, slot4, slot5)

        val bubble1 = view.findViewById<TextView>(R.id.bubbleFragL)
        val bubble2 = view.findViewById<TextView>(R.id.bubbleFragE)
        val bubble3 = view.findViewById<TextView>(R.id.bubbleFragA)
        val bubble4 = view.findViewById<TextView>(R.id.bubbleFragR)
        val bubble5 = view.findViewById<TextView>(R.id.bubbleFragN)
        bubbleViews = listOf(bubble1, bubble2, bubble3, bubble4, bubble5)

        val btnHint = view.findViewById<LinearLayout>(R.id.btnHintFragment)
        txtHintCount = view.findViewById(R.id.txtHintCountFragment)
        txtPuzzlePromptFrag = view.findViewById(R.id.txtPuzzlePromptFrag)
        txtPuzzleStreak = view.findViewById(R.id.txtPuzzleStreak)
        val btnClear = view.findViewById<AppCompatButton>(R.id.btnClearPuzzleFrag)
        val btnSubmit = view.findViewById<AppCompatButton>(R.id.btnSubmitPuzzleFrag)

        // Setup letter bubble click listeners
        bubbleViews.forEach { bubble ->
            bubble.setOnClickListener {
                val letter = bubble.text.toString()
                if (selectedLetters.size < targetWord.length) {
                    selectedLetters.add(letter)
                    bubble.isEnabled = false
                    bubble.alpha = 0.35f
                    updateSlots()
                }
            }
        }

        // Click slots to remove letters
        slotViews.forEachIndexed { index, slot ->
            slot.setOnClickListener {
                if (index < selectedLetters.size) {
                    val removedLetter = selectedLetters.removeAt(index)
                    val matchingBubble = bubbleViews.firstOrNull { !it.isEnabled && it.text == removedLetter }
                    matchingBubble?.let {
                        it.isEnabled = true
                        it.alpha = 1.0f
                    }
                    updateSlots()
                }
            }
        }

        // Hint click
        btnHint.setOnClickListener {
            if (hintsLeft > 0) {
                if (selectedLetters.size < targetWord.length) {
                    hintsLeft--
                    txtHintCount.text = "Hint ($hintsLeft left)"
                    val nextChar = targetWord[selectedLetters.size].toString()
                    selectedLetters.add(nextChar)
                    val matchingBubble = bubbleViews.firstOrNull { it.isEnabled && it.text == nextChar }
                    matchingBubble?.let {
                        it.isEnabled = false
                        it.alpha = 0.35f
                    }
                    updateSlots()
                } else {
                    Toast.makeText(requireContext(), "All slots are filled!", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(requireContext(), "No hints left today!", Toast.LENGTH_SHORT).show()
            }
        }

        // Clear click
        btnClear.setOnClickListener {
            selectedLetters.clear()
            bubbleViews.forEach {
                it.isEnabled = true
                it.alpha = 1.0f
            }
            updateSlots()
        }

        // Submit click
        btnSubmit.setOnClickListener {
            val formedWord = selectedLetters.joinToString("")
            if (formedWord.equals(targetWord, ignoreCase = true)) {
                Toast.makeText(requireContext(), "🎉 Outstanding! \"$targetWord\" is correct! +50 XP", Toast.LENGTH_LONG).show()
                val prefs = requireContext().getSharedPreferences("LearnlyProgress", Context.MODE_PRIVATE)
                val solved = prefs.getInt("puzzlesSolved", 0) + 1
                prefs.edit().putInt("puzzlesSolved", solved).apply()

                UserStatsHelper.incrementStreak(requireContext())
                val streak = UserStatsHelper.getStreak(requireContext())
                txtPuzzleStreak?.text = "$streak Day Puzzle Streak!"

                // Reset notification clear flag so completion notification reflects
                requireContext().getSharedPreferences("LearnlyNotifications", Context.MODE_PRIVATE)
                    .edit().putBoolean("isCleared", false).apply()

                // Sync daily puzzle solve to Firebase
                FirebaseHelper.recordDailyPuzzleSolve(requireContext())

                // Load next shuffled word from the pool
                view.postDelayed({
                    if (isAdded) {
                        loadNewPuzzle()
                    }
                }, 1200)
            } else {
                Toast.makeText(requireContext(), "Not quite! Try another combination or use a Hint.", Toast.LENGTH_SHORT).show()
            }
        }

        loadNewPuzzle()
    }

    private fun loadNewPuzzle() {
        if (!isAdded) return
        val prefs = requireContext().getSharedPreferences("LearnlyProgress", Context.MODE_PRIVATE)
        val lastWord = prefs.getString("lastPuzzleWord", "") ?: ""

        val candidates = puzzlePool.filter { it.word != lastWord }
        val puzzle = candidates.random()
        targetWord = puzzle.word
        targetHint = puzzle.hint
        prefs.edit().putString("lastPuzzleWord", targetWord).apply()

        var scrambled = targetWord.map { it.toString() }.shuffled().toMutableList()
        while (scrambled.joinToString("") == targetWord) {
            scrambled = targetWord.map { it.toString() }.shuffled().toMutableList()
        }
        scrambledLetters = scrambled
        selectedLetters.clear()
        hintsLeft = 3
        txtHintCount.text = "Hint ($hintsLeft left)"

        txtPuzzlePromptFrag?.text = "💡 Clue: $targetHint"

        val profilePrefs = requireContext().getSharedPreferences("LearnlyProfile", Context.MODE_PRIVATE)
        val streak = profilePrefs.getInt("streak", 1)
        txtPuzzleStreak?.text = "$streak Day Puzzle Streak!"

        bubbleViews.forEachIndexed { index, bubble ->
            if (index < scrambledLetters.size) {
                bubble.text = scrambledLetters[index]
            }
            bubble.isEnabled = true
            bubble.alpha = 1.0f
        }
        updateSlots()
    }

    private fun updateSlots() {
        slotViews.forEachIndexed { i, slot ->
            if (i < selectedLetters.size) {
                slot.text = selectedLetters[i]
            } else {
                slot.text = ""
            }
        }
    }
}
