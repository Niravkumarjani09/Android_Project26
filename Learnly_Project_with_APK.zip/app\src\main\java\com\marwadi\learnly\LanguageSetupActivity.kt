package com.marwadi.learnly

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton

class LanguageSetupActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_language_setup)

        val btnBack = findViewById<ImageButton>(R.id.btnBack)
        val spinnerComfortable = findViewById<Spinner>(R.id.spinnerComfortable)
        val spinnerLearn = findViewById<Spinner>(R.id.spinnerLearn)
        val imgFlagComfortable = findViewById<ImageView>(R.id.imgFlagComfortable)
        val imgFlagLearn = findViewById<ImageView>(R.id.imgFlagLearn)
        val btnContinue = findViewById<AppCompatButton>(R.id.btnContinue)

        btnBack.setOnClickListener {
            finish()
        }

        val languages = arrayOf("Gujarati", "English", "Hindi", "Spanish", "French", "Japanese")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, languages)

        spinnerComfortable.adapter = adapter
        spinnerLearn.adapter = adapter

        // Defaults as shown in screen 4
        spinnerComfortable.setSelection(0) // Gujarati
        spinnerLearn.setSelection(1) // English

        spinnerComfortable.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (languages[position] == "Gujarati" || languages[position] == "Hindi") {
                    imgFlagComfortable.setImageResource(R.drawable.ic_flag_india)
                } else {
                    imgFlagComfortable.setImageResource(R.drawable.ic_flag_uk)
                }
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        spinnerLearn.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (languages[position] == "English") {
                    imgFlagLearn.setImageResource(R.drawable.ic_flag_uk)
                } else {
                    imgFlagLearn.setImageResource(R.drawable.ic_flag_india)
                }
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        btnContinue.setOnClickListener {
            val comfortable = spinnerComfortable.selectedItem.toString()
            val learning = spinnerLearn.selectedItem.toString()

            if (comfortable == learning) {
                Toast.makeText(this, "Both languages cannot be the same", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Save in prefs and sync with Firestore
            FirebaseHelper.saveLanguagePair(this, comfortable, learning)

            val intent = Intent(this, HomeActivity::class.java)
            intent.putExtra("comfortableLanguage", comfortable)
            intent.putExtra("learningLanguage", learning)
            startActivity(intent)
            finish()
        }
    }
}