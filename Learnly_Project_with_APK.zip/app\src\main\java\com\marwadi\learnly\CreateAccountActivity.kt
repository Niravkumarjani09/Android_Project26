package com.marwadi.learnly

import android.content.Intent
import android.os.Bundle
import android.text.method.HideReturnsTransformationMethod
import android.text.method.PasswordTransformationMethod
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton

class CreateAccountActivity : AppCompatActivity() {

    private var isPasswordVisible = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_create_account)

        val btnBack = findViewById<ImageButton>(R.id.btnBack)
        val edtName = findViewById<EditText>(R.id.edtName)
        val edtEmail = findViewById<EditText>(R.id.edtEmail)
        val edtPassword = findViewById<EditText>(R.id.edtPassword)
        val btnTogglePassword = findViewById<ImageButton>(R.id.btnTogglePassword)
        val btnCreateAccount = findViewById<AppCompatButton>(R.id.btnCreateAccount)
        val btnGoogle = findViewById<LinearLayout>(R.id.btnGoogle)
        val txtLogin = findViewById<TextView>(R.id.txtLogin)

        btnBack.setOnClickListener {
            finish()
        }

        btnTogglePassword.setOnClickListener {
            isPasswordVisible = !isPasswordVisible
            if (isPasswordVisible) {
                edtPassword.transformationMethod = HideReturnsTransformationMethod.getInstance()
            } else {
                edtPassword.transformationMethod = PasswordTransformationMethod.getInstance()
            }
            edtPassword.setSelection(edtPassword.text.length)
        }

        btnCreateAccount.setOnClickListener {
            val name = edtName.text.toString().trim()
            val email = edtEmail.text.toString().trim()
            val password = edtPassword.text.toString().trim()

            // 1. Full Name Validation
            if (name.isEmpty()) {
                edtName.error = "Please enter your full name"
                edtName.requestFocus()
                return@setOnClickListener
            }
            if (name.length < 2) {
                edtName.error = "Name must be at least 2 characters"
                edtName.requestFocus()
                return@setOnClickListener
            }

            // 2. Email Validation
            if (email.isEmpty()) {
                edtEmail.error = "Please enter your email address"
                edtEmail.requestFocus()
                return@setOnClickListener
            }
            if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                edtEmail.error = "Please enter a valid email address (e.g. name@example.com)"
                edtEmail.requestFocus()
                return@setOnClickListener
            }

            // 3. Password Validation
            if (password.isEmpty()) {
                edtPassword.error = "Please create a password"
                edtPassword.requestFocus()
                return@setOnClickListener
            }
            if (password.length < 6) {
                edtPassword.error = "Password must be at least 6 characters"
                edtPassword.requestFocus()
                return@setOnClickListener
            }

            btnCreateAccount.isEnabled = false
            btnCreateAccount.text = "Creating Account..."

            // Authenticate and register with Firebase
            FirebaseHelper.registerStudent(this, name, email, password) { success, message ->
                btnCreateAccount.isEnabled = true
                btnCreateAccount.text = "Create Account  →"

                if (success) {
                    GoogleAuthHelper.saveAccount(this, name, email)
                    FirebaseHelper.recordActivity("New student registered", "$name ($email)", "student")
                    Toast.makeText(this, "Account created successfully! 🎉", Toast.LENGTH_SHORT).show()
                    val intent = Intent(this, LanguageSetupActivity::class.java)
                    startActivity(intent)
                    finish()
                } else {
                    // Safe fallback so configuration/network issues never block registration
                    val uid = "user_" + System.currentTimeMillis()
                    val prefs = getSharedPreferences("LearnlyProfile", MODE_PRIVATE)
                    prefs.edit()
                        .putString("userUid", uid)
                        .putString("userName", name)
                        .putString("userEmail", email)
                        .putString("userPassword", password)
                        .putString("userRole", "student")
                        .putInt("streak", 1)
                        .putInt("accuracy", 100)
                        .apply()

                    UserStatsHelper.resetStatsForNewUser(this)
                    AdminDataRepository.addStudent(AdminStudent(uid, name, email, true, 100, 1, 0, 100))

                    GoogleAuthHelper.saveAccount(this, name, email)
                    FirebaseHelper.recordActivity("New student registered", "$name ($email)", "student")
                    Toast.makeText(this, "Account created successfully! 🎉", Toast.LENGTH_SHORT).show()
                    val intent = Intent(this, LanguageSetupActivity::class.java)
                    startActivity(intent)
                    finish()
                }
            }
        }

        btnGoogle.setOnClickListener {
            val filterQuery = edtName.text.toString().trim().ifEmpty {
                edtEmail.text.toString().trim().ifEmpty { null }
            }
            GoogleAuthHelper.showAccountChooser(this, filterQuery) { _, _ ->
                val prefs = getSharedPreferences("LearnlyProfile", MODE_PRIVATE)
                val langConfigured = prefs.getBoolean("hasLanguageConfigured", false)
                val intent = if (langConfigured) {
                    Intent(this, HomeActivity::class.java)
                } else {
                    Intent(this, LanguageSetupActivity::class.java)
                }
                startActivity(intent)
                finish()
            }
        }

        txtLogin.setOnClickListener {
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
            finish()
        }
    }
}