package com.marwadi.learnly

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class LessonsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lessons)

        NavigationHelper.setupBottomNav(this, NavTab.LESSONS)

        val comfortableLanguage = intent.getStringExtra("comfortableLanguage") ?: "Gujarati"
        val learningLanguage = intent.getStringExtra("learningLanguage") ?: "English"

        val cardBasicWords = findViewById<View>(R.id.cardBasicWords)
        val cardBasicSentences = findViewById<View>(R.id.cardBasicSentences)
        val cardGrammar = findViewById<View>(R.id.cardGrammar)
        val btnLanguagePill = findViewById<View>(R.id.btnLanguagePill)

        val chipAll = findViewById<TextView>(R.id.chipAll)
        val chipWords = findViewById<TextView>(R.id.chipWords)
        val chipSentences = findViewById<TextView>(R.id.chipSentences)
        val chipGrammar = findViewById<TextView>(R.id.chipGrammar)

        // Filter chips click handling
        chipAll.setOnClickListener {
            listOf(chipAll, chipWords, chipSentences, chipGrammar).forEach {
                it.setBackgroundResource(R.drawable.bg_chip_unselected)
                it.setTextColor(getColor(R.color.text_body))
            }
            chipAll.setBackgroundResource(R.drawable.bg_chip_selected)
            chipAll.setTextColor(getColor(R.color.white))
            cardBasicWords.visibility = View.VISIBLE
            cardBasicSentences.visibility = View.VISIBLE
            cardGrammar.visibility = View.VISIBLE
        }

        chipWords.setOnClickListener {
            listOf(chipAll, chipWords, chipSentences, chipGrammar).forEach {
                it.setBackgroundResource(R.drawable.bg_chip_unselected)
                it.setTextColor(getColor(R.color.text_body))
            }
            chipWords.setBackgroundResource(R.drawable.bg_chip_selected)
            chipWords.setTextColor(getColor(R.color.white))
            cardBasicWords.visibility = View.VISIBLE
            cardBasicSentences.visibility = View.GONE
            cardGrammar.visibility = View.GONE
        }

        chipSentences.setOnClickListener {
            listOf(chipAll, chipWords, chipSentences, chipGrammar).forEach {
                it.setBackgroundResource(R.drawable.bg_chip_unselected)
                it.setTextColor(getColor(R.color.text_body))
            }
            chipSentences.setBackgroundResource(R.drawable.bg_chip_selected)
            chipSentences.setTextColor(getColor(R.color.white))
            cardBasicWords.visibility = View.GONE
            cardBasicSentences.visibility = View.VISIBLE
            cardGrammar.visibility = View.GONE
        }

        chipGrammar.setOnClickListener {
            listOf(chipAll, chipWords, chipSentences, chipGrammar).forEach {
                it.setBackgroundResource(R.drawable.bg_chip_unselected)
                it.setTextColor(getColor(R.color.text_body))
            }
            chipGrammar.setBackgroundResource(R.drawable.bg_chip_selected)
            chipGrammar.setTextColor(getColor(R.color.white))
            cardBasicWords.visibility = View.GONE
            cardBasicSentences.visibility = View.GONE
            cardGrammar.visibility = View.VISIBLE
        }

        btnLanguagePill.setOnClickListener {
            val intent = Intent(this, LanguageSetupActivity::class.java)
            startActivity(intent)
        }

        cardBasicWords.setOnClickListener {
            val intent = Intent(this, LessonActivity::class.java)
            intent.putExtra("lessonName", "basic_words")
            intent.putExtra("comfortableLanguage", comfortableLanguage)
            intent.putExtra("learningLanguage", learningLanguage)
            startActivity(intent)
        }

        cardBasicSentences.setOnClickListener {
            val intent = Intent(this, LessonActivity::class.java)
            intent.putExtra("lessonName", "basic_sentences")
            intent.putExtra("comfortableLanguage", comfortableLanguage)
            intent.putExtra("learningLanguage", learningLanguage)
            startActivity(intent)
        }

        cardGrammar.setOnClickListener {
            val intent = Intent(this, LessonActivity::class.java)
            intent.putExtra("lessonName", "grammar")
            intent.putExtra("comfortableLanguage", comfortableLanguage)
            intent.putExtra("learningLanguage", learningLanguage)
            startActivity(intent)
        }
    }

    override fun onResume() {
        super.onResume()
        NavigationHelper.setupBottomNav(this, NavTab.LESSONS)
    }
}