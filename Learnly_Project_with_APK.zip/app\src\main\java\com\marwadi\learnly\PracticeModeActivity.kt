package com.marwadi.learnly

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton

class PracticeModeActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_practice_mode)

        NavigationHelper.setupBottomNav(this, NavTab.LESSONS)

        val btnBack = findViewById<ImageButton>(R.id.btnBackPractice)
        btnBack.setOnClickListener {
            finish()
        }

        val btnStartPractice = findViewById<AppCompatButton>(R.id.btnStartPractice)
        val cardRecVocabulary = findViewById<View>(R.id.cardRecVocabulary)
        val cardRecGrammar = findViewById<View>(R.id.cardRecGrammar)
        val cardRecSentences = findViewById<View>(R.id.cardRecSentences)

        val txtRecVocabCount = findViewById<TextView>(R.id.txtRecVocabCount)
        val txtRecGrammarCount = findViewById<TextView>(R.id.txtRecGrammarCount)
        val txtRecSentencesCount = findViewById<TextView>(R.id.txtRecSentencesCount)

        val comfortableLanguage = intent.getStringExtra("comfortableLanguage") ?: "Gujarati"
        val learningLanguage = intent.getStringExtra("learningLanguage") ?: "English"

        // Dynamically load category question counts from Firestore
        FirebaseHelper.fetchQuestionsForQuiz(this, "Vocabulary", comfortableLanguage, learningLanguage) { list ->
            txtRecVocabCount.text = "(${list.size} questions)"
        }
        FirebaseHelper.fetchQuestionsForQuiz(this, "Grammar", comfortableLanguage, learningLanguage) { list ->
            txtRecGrammarCount.text = "(${list.size} questions)"
        }
        FirebaseHelper.fetchQuestionsForQuiz(this, "Sentence", comfortableLanguage, learningLanguage) { list ->
            txtRecSentencesCount.text = "(${list.size} questions)"
        }

        val openLesson = { lesson: String ->
            val intent = Intent(this, LessonActivity::class.java)
            intent.putExtra("lessonName", lesson)
            intent.putExtra("comfortableLanguage", comfortableLanguage)
            intent.putExtra("learningLanguage", learningLanguage)
            startActivity(intent)
        }

        btnStartPractice.setOnClickListener {
            // Check if user has mistake records in Firestore
            FirebaseHelper.fetchMistakesForStudent(this) { mistakes ->
                if (mistakes.isNotEmpty()) {
                    openLesson("practice_mistakes")
                } else {
                    // Check local SharedPreferences fallback
                    val mistakePrefs = getSharedPreferences("LearnlyMistakes", MODE_PRIVATE)
                    val localMistakes = mistakePrefs.getString("mistakes", "") ?: ""
                    if (localMistakes.isNotEmpty()) {
                        openLesson("practice_mistakes")
                    } else {
                        android.widget.Toast.makeText(
                            this,
                            "Great job! No mistakes logged yet. Starting general practice quiz.",
                            android.widget.Toast.LENGTH_SHORT
                        ).show()
                        openLesson("basic_words")
                    }
                }
            }
        }

        cardRecVocabulary.setOnClickListener { openLesson("basic_words") }
        cardRecGrammar.setOnClickListener { openLesson("grammar") }
        cardRecSentences.setOnClickListener { openLesson("basic_sentences") }
    }

    override fun onResume() {
        super.onResume()
        NavigationHelper.setupBottomNav(this, NavTab.LESSONS)
    }
}
