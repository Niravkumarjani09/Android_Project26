package com.marwadi.learnly

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment

class LessonsFragment : Fragment() {

    private lateinit var txtPillLang1: TextView
    private lateinit var txtPillLang2: TextView
    private lateinit var imgPillFlag1: ImageView
    private lateinit var imgPillFlag2: ImageView

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_lessons, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        txtPillLang1 = view.findViewById(R.id.txtPillLang1)
        txtPillLang2 = view.findViewById(R.id.txtPillLang2)
        imgPillFlag1 = view.findViewById(R.id.imgPillFlag1)
        imgPillFlag2 = view.findViewById(R.id.imgPillFlag2)

        val cardBasicWords = view.findViewById<View>(R.id.cardBasicWords)
        val cardBasicSentences = view.findViewById<View>(R.id.cardBasicSentences)
        val cardGrammar = view.findViewById<View>(R.id.cardGrammar)
        val btnLanguagePill = view.findViewById<View>(R.id.btnLanguagePill)

        val chipAll = view.findViewById<TextView>(R.id.chipAll)
        val chipWords = view.findViewById<TextView>(R.id.chipWords)
        val chipSentences = view.findViewById<TextView>(R.id.chipSentences)
        val chipGrammar = view.findViewById<TextView>(R.id.chipGrammar)

        val chips = listOf(chipAll, chipWords, chipSentences, chipGrammar)

        updateLanguagePill()

        val selectChip = { selected: TextView ->
            val ctx = requireContext()
            chips.forEach { chip ->
                chip.setBackgroundResource(R.drawable.bg_chip_unselected)
                chip.setTextColor(ContextCompat.getColor(ctx, R.color.text_body))
            }
            selected.setBackgroundResource(R.drawable.bg_chip_selected)
            selected.setTextColor(ContextCompat.getColor(ctx, R.color.white))
        }

        chipAll.setOnClickListener {
            selectChip(chipAll)
            cardBasicWords.visibility = View.VISIBLE
            cardBasicSentences.visibility = View.VISIBLE
            cardGrammar.visibility = View.VISIBLE
        }

        chipWords.setOnClickListener {
            selectChip(chipWords)
            cardBasicWords.visibility = View.VISIBLE
            cardBasicSentences.visibility = View.GONE
            cardGrammar.visibility = View.GONE
        }

        chipSentences.setOnClickListener {
            selectChip(chipSentences)
            cardBasicWords.visibility = View.GONE
            cardBasicSentences.visibility = View.VISIBLE
            cardGrammar.visibility = View.GONE
        }

        chipGrammar.setOnClickListener {
            selectChip(chipGrammar)
            cardBasicWords.visibility = View.GONE
            cardBasicSentences.visibility = View.GONE
            cardGrammar.visibility = View.VISIBLE
        }

        btnLanguagePill.setOnClickListener {
            val intent = Intent(requireContext(), LanguageSetupActivity::class.java)
            startActivity(intent)
        }

        val openLesson = { lesson: String ->
            val prefs = requireContext().getSharedPreferences("LearnlyProfile", Context.MODE_PRIVATE)
            val comfortableLanguage = prefs.getString("comfortableLanguage", "Gujarati") ?: "Gujarati"
            val learningLanguage = prefs.getString("learningLanguage", "English") ?: "English"

            val intent = Intent(requireContext(), LessonActivity::class.java)
            intent.putExtra("lessonName", lesson)
            intent.putExtra("comfortableLanguage", comfortableLanguage)
            intent.putExtra("learningLanguage", learningLanguage)
            startActivity(intent)
        }

        cardBasicWords.setOnClickListener { openLesson("basic_words") }
        cardBasicSentences.setOnClickListener { openLesson("basic_sentences") }
        cardGrammar.setOnClickListener { openLesson("grammar") }

        updateProgressBars()
    }

    private fun updateProgressBars() {
        val view = view ?: return
        val prefs = requireContext().getSharedPreferences("LearnlyProgress", Context.MODE_PRIVATE)

        val wordsCompleted = prefs.getInt("wordsCompleted", 0)
        val sentencesCompleted = prefs.getInt("sentencesCompleted", 0)
        val grammarCompleted = prefs.getInt("grammarCompleted", 0)

        val totalWords = 15
        val totalSentences = 20
        val totalGrammar = 15

        val txtWordsRatio = view.findViewById<TextView>(R.id.txtProgressWordsRatio)
        val progressWords = view.findViewById<android.widget.ProgressBar>(R.id.progressBarWords)
        val txtSentencesRatio = view.findViewById<TextView>(R.id.txtProgressSentencesRatio)
        val progressSentences = view.findViewById<android.widget.ProgressBar>(R.id.progressBarSentences)
        val txtGrammarRatio = view.findViewById<TextView>(R.id.txtProgressGrammarRatio)
        val progressGrammar = view.findViewById<android.widget.ProgressBar>(R.id.progressBarGrammar)

        txtWordsRatio?.text = "$wordsCompleted/$totalWords"
        val wordsPercent = (wordsCompleted * 100) / totalWords
        progressWords?.progress = wordsPercent.coerceIn(0, 100)

        txtSentencesRatio?.text = "$sentencesCompleted/$totalSentences"
        val sentencesPercent = (sentencesCompleted * 100) / totalSentences
        progressSentences?.progress = sentencesPercent.coerceIn(0, 100)

        txtGrammarRatio?.text = "$grammarCompleted/$totalGrammar"
        val grammarPercent = (grammarCompleted * 100) / totalGrammar
        progressGrammar?.progress = grammarPercent.coerceIn(0, 100)
    }

    private fun updateLanguagePill() {
        val context = context ?: return
        val prefs = context.getSharedPreferences("LearnlyProfile", Context.MODE_PRIVATE)
        val comfortableLanguage = prefs.getString("comfortableLanguage", "Gujarati") ?: "Gujarati"
        val learningLanguage = prefs.getString("learningLanguage", "English") ?: "English"

        txtPillLang1.text = comfortableLanguage
        txtPillLang2.text = learningLanguage

        if (comfortableLanguage == "English") {
            imgPillFlag1.setImageResource(R.drawable.ic_flag_uk)
            imgPillFlag2.setImageResource(R.drawable.ic_flag_india)
        } else {
            imgPillFlag1.setImageResource(R.drawable.ic_flag_india)
            imgPillFlag2.setImageResource(R.drawable.ic_flag_uk)
        }
    }

    override fun onResume() {
        super.onResume()
        updateLanguagePill()
        updateProgressBars()
    }
}
