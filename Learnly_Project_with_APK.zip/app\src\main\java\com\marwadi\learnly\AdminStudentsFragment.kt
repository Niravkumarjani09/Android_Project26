package com.marwadi.learnly

import android.app.AlertDialog
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.widget.PopupMenu
import androidx.fragment.app.Fragment

class AdminStudentsFragment : Fragment() {

    private lateinit var edtSearchStudents: EditText
    private lateinit var studentsContainer: LinearLayout
    private lateinit var chipAll: TextView
    private lateinit var chipActive: TextView
    private lateinit var chipInactive: TextView

    private var filterMode: String = "All"
    private var searchQuery: String = ""

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_admin_students, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        edtSearchStudents = view.findViewById(R.id.edtSearchStudents)
        studentsContainer = view.findViewById(R.id.adminStudentsContainer)
        chipAll = view.findViewById(R.id.chipFilterAllStudents)
        chipActive = view.findViewById(R.id.chipFilterActiveStudents)
        chipInactive = view.findViewById(R.id.chipFilterInactiveStudents)

        chipAll.setOnClickListener { setStatusFilter("All") }
        chipActive.setOnClickListener { setStatusFilter("Active") }
        chipInactive.setOnClickListener { setStatusFilter("Inactive") }

        edtSearchStudents.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                searchQuery = s?.toString()?.trim() ?: ""
                renderStudents()
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        renderStudents()
    }

    override fun onResume() {
        super.onResume()
        renderStudents()
    }

    private fun setStatusFilter(filter: String) {
        filterMode = filter

        val chips = listOf(chipAll, chipActive, chipInactive)
        for (c in chips) {
            c.setBackgroundResource(R.drawable.bg_admin_chip_unselected)
            c.setTextColor(resources.getColor(R.color.text_body, null))
        }

        val activeChip = when (filter) {
            "Active" -> chipActive
            "Inactive" -> chipInactive
            else -> chipAll
        }

        activeChip.setBackgroundResource(R.drawable.bg_admin_chip_selected)
        activeChip.setTextColor(resources.getColor(R.color.white, null))

        renderStudents()
    }

    private fun renderStudents() {
        FirebaseHelper.fetchAllStudents { liveStudents ->
            if (!isAdded) return@fetchAllStudents
            studentsContainer.removeAllViews()
            val inflater = LayoutInflater.from(requireContext())
            var students = liveStudents

            when (filterMode) {
                "Active" -> students = students.filter { it.isActive }
                "Inactive" -> students = students.filter { !it.isActive }
            }

            if (searchQuery.isNotEmpty()) {
                students = students.filter {
                    it.name.contains(searchQuery, ignoreCase = true) ||
                    it.email.contains(searchQuery, ignoreCase = true)
                }
            }

            if (students.isEmpty()) {
                val emptyView = TextView(requireContext()).apply {
                    text = "No registered students found.\n(Students appear dynamically here once they register)"
                    setTextColor(resources.getColor(R.color.text_muted, null))
                    textSize = 14f
                    setPadding(30, 80, 30, 40)
                    gravity = android.view.Gravity.CENTER
                }
                studentsContainer.addView(emptyView)
                return@fetchAllStudents
            }

            for (student in students) {
                val itemView = inflater.inflate(R.layout.item_admin_student, studentsContainer, false)
                val txtAvatar = itemView.findViewById<TextView>(R.id.txtStudentAvatarInitial)
                val txtName = itemView.findViewById<TextView>(R.id.txtStudentName)
                val txtEmail = itemView.findViewById<TextView>(R.id.txtStudentEmail)
                val txtStatus = itemView.findViewById<TextView>(R.id.txtStudentStatusBadge)
                val btnActions = itemView.findViewById<ImageButton>(R.id.btnStudentActions)

                txtAvatar.text = if (student.name.isNotEmpty()) student.name.take(1).uppercase() else "S"
                txtName.text = student.name
                txtEmail.text = student.email

                if (student.isActive) {
                    txtStatus.text = "Active"
                    txtStatus.setBackgroundResource(R.drawable.bg_badge_active)
                    txtStatus.setTextColor(resources.getColor(R.color.admin_badge_active_text, null))
                } else {
                    txtStatus.text = "Inactive"
                    txtStatus.setBackgroundResource(R.drawable.bg_badge_inactive)
                    txtStatus.setTextColor(resources.getColor(R.color.admin_badge_inactive_text, null))
                }

                btnActions.setOnClickListener { v ->
                    val popup = PopupMenu(requireContext(), v)
                    popup.menu.add(0, 1, 0, if (student.isActive) "Mark Inactive" else "Mark Active")
                    popup.menu.add(0, 2, 1, "View Performance Stats")
                    popup.menu.add(0, 3, 2, "Delete Student Account")

                    popup.setOnMenuItemClickListener { menuItem ->
                        when (menuItem.itemId) {
                            1 -> {
                                val newStatus = !student.isActive
                                FirebaseHelper.updateStudentStatus(student.id, newStatus)
                                AdminDataRepository.toggleStudentStatus(student.id)
                                Toast.makeText(requireContext(), "Status updated to ${if (newStatus) "Active" else "Inactive"}", Toast.LENGTH_SHORT).show()
                                renderStudents()
                                true
                            }
                            2 -> {
                                AlertDialog.Builder(requireContext())
                                    .setTitle("${student.name} - Performance")
                                    .setMessage("Accuracy: ${student.accuracy}%\nLearning Streak: ${student.streak} days\nPuzzles Solved: ${student.puzzlesCompleted}\nAccount Status: ${if (student.isActive) "Active" else "Inactive"}")
                                    .setPositiveButton("Close", null)
                                    .show()
                                true
                            }
                            3 -> {
                                AlertDialog.Builder(requireContext())
                                    .setTitle("Delete Student")
                                    .setMessage("Are you sure you want to permanently delete ${student.name} from Cloud Firestore?")
                                    .setPositiveButton("Delete") { _, _ ->
                                        FirebaseHelper.deleteStudentFromFirestore(student.id) {
                                            AdminDataRepository.deleteStudent(student.id)
                                            Toast.makeText(requireContext(), "Student deleted from database", Toast.LENGTH_SHORT).show()
                                            renderStudents()
                                        }
                                    }
                                    .setNegativeButton("Cancel", null)
                                    .show()
                                true
                            }
                            else -> false
                        }
                    }
                    popup.show()
                }

                studentsContainer.addView(itemView)
            }
        }
    }
}

