package com.marwadi.learnly

import java.io.Serializable

data class AdminLesson(
    val id: String,
    var title: String,
    var description: String,
    var category: String, // "Basic Words", "Basic Sentences", "Everyday Grammar"
    var sourceLanguage: String = "English",
    var targetLanguage: String = "Gujarati",
    var questionCount: Int = 0
) : Serializable

data class AdminQuestion(
    val id: String,
    var lessonId: String = "",
    var questionText: String,
    var categoryTag: String, // "Vocabulary", "Sentence", "Grammar"
    var sourceLanguage: String = "English",
    var targetLanguage: String = "Gujarati",
    var options: List<String>,
    var correctAnswerIndex: Int = 0,
    var explanation: String = ""
) : Serializable

data class AdminStudent(
    val id: String,
    var name: String,
    var email: String,
    var isActive: Boolean = true,
    var accuracy: Int = 85,
    var streak: Int = 1,
    var puzzlesCompleted: Int = 0,
    var totalXP: Int = 100
) : Serializable

data class AdminRecentActivity(
    val id: String,
    val title: String,
    val subtitle: String,
    val timeAgo: String,
    val type: String // "student", "lesson", "question"
)

data class AdminPlatformStats(
    val totalStudents: Int = 248,
    val totalLessons: Int = 36,
    val totalQuestions: Int = 1248,
    val puzzlesCompleted: Int = 892,
    val studentGrowth: String = "+12% vs last week",
    val lessonGrowth: String = "+8% vs last week",
    val questionGrowth: String = "+5% vs last week",
    val puzzleGrowth: String = "+18% vs last week"
)
