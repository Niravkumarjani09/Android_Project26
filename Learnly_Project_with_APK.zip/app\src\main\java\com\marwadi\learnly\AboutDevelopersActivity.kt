package com.marwadi.learnly

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class AboutDevelopersActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_about_developers)

        val btnBack = findViewById<ImageButton>(R.id.btnBackAboutDev)
        btnBack.setOnClickListener {
            finish()
        }

        val layoutStudentEmail = findViewById<View>(R.id.layoutStudentEmail)
        val txtStudentEmail = findViewById<TextView>(R.id.txtStudentEmail)

        layoutStudentEmail?.setOnClickListener {
            val email = txtStudentEmail.text.toString().trim()
            try {
                val intent = Intent(Intent.ACTION_SENDTO).apply {
                    data = Uri.parse("mailto:$email")
                    putExtra(Intent.EXTRA_SUBJECT, "Inquiry about Learnly Project")
                }
                startActivity(intent)
            } catch (e: Exception) {
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                val clip = ClipData.newPlainText("Developer Email", email)
                clipboard.setPrimaryClip(clip)
                Toast.makeText(this, "Email copied to clipboard: $email", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
