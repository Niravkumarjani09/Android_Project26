package com.marwadi.learnly

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.view.View
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.RelativeLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton
import java.util.Locale

class LessonActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    data class Question(
        val title: String,
        val prompt: String,
        val graphicResId: Int,
        val options: List<String>,
        val correctIndex: Int,
        val speakText: String,
        val explanation: String = ""
    )

    private var currentQuestionIndex = 0
    private var score = 0
    private var selectedOptionIndex = -1
    private var isAnswerChecked = false

    private lateinit var txtLessonName: TextView
    private lateinit var txtQuestionNumber: TextView
    private lateinit var progressBarLesson: ProgressBar
    private lateinit var imgQuestionGraphic: ImageView
    private lateinit var txtWordTitle: TextView
    private lateinit var btnAudioSpeaker: View
    private lateinit var txtQuestion: TextView
    private lateinit var txtResult: TextView
    private lateinit var btnCheck: AppCompatButton
    private lateinit var optionsContainer: View

    private lateinit var optionLayouts: List<RelativeLayout>
    private lateinit var optionRadios: List<ImageView>
    private lateinit var optionTexts: List<TextView>
    private lateinit var optionBadges: List<ImageView>

    private var comfortableLanguage = "Gujarati"
    private var learningLanguage = "English"
    private var lessonName = "basic_words"

    private var textToSpeech: TextToSpeech? = null
    private var ttsReady = false

    private val questions = mutableListOf<Question>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lesson)

        findViewById<View>(R.id.btnBackLesson)?.setOnClickListener {
            finish()
        }

        // Init views
        txtLessonName = findViewById(R.id.txtLessonName)
        txtQuestionNumber = findViewById(R.id.txtQuestionNumber)
        progressBarLesson = findViewById(R.id.progressBarLesson)
        imgQuestionGraphic = findViewById(R.id.imgQuestionGraphic)
        txtWordTitle = findViewById(R.id.txtWordTitle)
        btnAudioSpeaker = findViewById(R.id.btnAudioSpeaker)
        txtQuestion = findViewById(R.id.txtQuestion)
        txtResult = findViewById(R.id.txtResult)
        btnCheck = findViewById(R.id.btnCheck)
        optionsContainer = findViewById(R.id.optionsContainer)

        optionLayouts = listOf(
            findViewById(R.id.layoutOption1),
            findViewById(R.id.layoutOption2),
            findViewById(R.id.layoutOption3),
            findViewById(R.id.layoutOption4)
        )
        optionRadios = listOf(
            findViewById(R.id.radioIcon1),
            findViewById(R.id.radioIcon2),
            findViewById(R.id.radioIcon3),
            findViewById(R.id.radioIcon4)
        )
        optionTexts = listOf(
            findViewById(R.id.txtOption1),
            findViewById(R.id.txtOption2),
            findViewById(R.id.txtOption3),
            findViewById(R.id.txtOption4)
        )
        optionBadges = listOf(
            findViewById(R.id.checkBadge1),
            findViewById(R.id.checkBadge2),
            findViewById(R.id.checkBadge3),
            findViewById(R.id.checkBadge4)
        )

        // Read intent data
        val prefs = getSharedPreferences("LearnlyProfile", MODE_PRIVATE)
        comfortableLanguage = intent.getStringExtra("comfortableLanguage")
            ?: prefs.getString("comfortableLanguage", "Gujarati") ?: "Gujarati"
        learningLanguage = intent.getStringExtra("learningLanguage")
            ?: prefs.getString("learningLanguage", "English") ?: "English"
        lessonName = intent.getStringExtra("lessonName") ?: "basic_words"

        // Set screen title
        txtLessonName.text = when (lessonName) {
            "basic_words" -> if (comfortableLanguage == "Gujarati") "મૂળભૂત શબ્દો" else "Basic Words"
            "basic_sentences" -> if (comfortableLanguage == "Gujarati") "મૂળભૂત વાક્યો" else "Basic Sentences"
            "practice_mistakes" -> if (comfortableLanguage == "Gujarati") "ભૂલોની પ્રેક્ટિસ" else "Mistakes Practice"
            else -> if (comfortableLanguage == "Gujarati") "રોજિંદું વ્યાકરણ" else "Everyday Grammar"
        }

        // Setup TTS
        textToSpeech = TextToSpeech(this, this)

        // Audio speaker click
        btnAudioSpeaker.setOnClickListener {
            if (currentQuestionIndex < questions.size) {
                speakWord(questions[currentQuestionIndex].speakText)
            }
        }

        // Setup options click listeners
        optionLayouts.forEachIndexed { index, layout ->
            layout.setOnClickListener {
                if (!isAnswerChecked) {
                    selectOption(index)
                }
            }
        }

        // Setup Check/Next button click listener
        btnCheck.setOnClickListener {
            if (!isAnswerChecked) {
                handleCheckAnswer()
            } else {
                handleNextQuestion()
            }
        }

        // Load dynamic questions from Cloud Firestore
        loadQuestions()
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = textToSpeech?.setLanguage(Locale.US)
            ttsReady = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED
        }
    }

    private fun speakWord(text: String) {
        if (ttsReady && text.isNotEmpty()) {
            textToSpeech?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "LearnlyTTS")
        } else {
            Toast.makeText(this, "Pronunciation: $text", Toast.LENGTH_SHORT).show()
        }
    }

    private fun loadQuestions() {
        if (lessonName == "practice_mistakes") {
            txtWordTitle.text = "Loading..."
            txtQuestion.text = "Fetching your personalized mistake review questions..."

            FirebaseHelper.fetchMistakesForStudent(this) { mistakes ->
                if (mistakes.isNotEmpty()) {
                    questions.clear()
                    mistakes.take(10).forEach { item ->
                        val qText = item["questionText"]?.toString() ?: "Review Question"
                        val correct = item["correctAnswer"]?.toString() ?: "Correct"
                        val wrong = item["selectedAnswer"]?.toString() ?: "Wrong"
                        val cat = item["lessonCategory"]?.toString() ?: "Practice"

                        val dummyOpts = listOf("Option A", "Option B", "Option C").filter { it != correct && it != wrong }
                        val opts = mutableListOf(correct, wrong)
                        opts.addAll(dummyOpts.take(2))
                        while (opts.size < 4) opts.add("Choice ${opts.size + 1}")
                        opts.shuffle()
                        val correctIdx = opts.indexOf(correct)

                        questions.add(
                            Question(
                                title = qText,
                                speakText = correct,
                                prompt = if (comfortableLanguage == "Gujarati") "આ પ્રશ્નનો સાચો જવાબ પસંદ કરો:" else "Select the correct answer to master this question:",
                                options = opts,
                                correctIndex = correctIdx,
                                graphicResId = R.drawable.ic_target,
                                explanation = "Correct answer: $correct ($cat)"
                            )
                        )
                    }
                    currentQuestionIndex = 0
                    if (questions.isNotEmpty()) {
                        displayQuestion()
                    } else {
                        loadGeneralQuestions("Vocabulary")
                    }
                } else {
                    loadGeneralQuestions("Vocabulary")
                }
            }
            return
        }

        val categoryTag = when (lessonName) {
            "basic_words" -> "Vocabulary"
            "basic_sentences" -> "Sentence"
            else -> "Grammar"
        }
        loadGeneralQuestions(categoryTag)
    }

    private fun loadGeneralQuestions(categoryTag: String) {
        txtWordTitle.text = "Loading..."
        txtQuestion.text = "Fetching live questions from Firestore..."

        FirebaseHelper.fetchQuestionsForQuiz(
            context = this,
            categoryTag = categoryTag,
            sourceLanguage = comfortableLanguage,
            targetLanguage = learningLanguage
        ) { fetchedQuestions ->
            questions.clear()
            questions.addAll(fetchedQuestions)
            currentQuestionIndex = 0
            if (questions.isNotEmpty()) {
                displayQuestion()
            } else {
                txtWordTitle.text = "No Questions Available"
                txtQuestion.text = "Please add questions for $categoryTag from the Admin Panel."
            }
        }
    }

    private fun displayQuestion() {
        if (currentQuestionIndex >= questions.size) {
            showCompletionScreen()
            return
        }

        val q = questions[currentQuestionIndex]

        // Reset state
        selectedOptionIndex = -1
        isAnswerChecked = false
        txtResult.text = ""
        btnCheck.text = "Check Answer"

        // Update question progress and header
        txtQuestionNumber.text = "${currentQuestionIndex + 1}/${questions.size}"
        progressBarLesson.max = questions.size
        progressBarLesson.progress = currentQuestionIndex + 1

        // Update graphic, title, and prompt
        imgQuestionGraphic.setImageResource(q.graphicResId)
        txtWordTitle.text = q.title
        txtQuestion.text = q.prompt

        // Reset all options to unselected, normal state (NO PRE-SHOWING ANSWERS!)
        optionLayouts.forEachIndexed { index, layout ->
            layout.setBackgroundResource(R.drawable.bg_quiz_option_normal)
            layout.isClickable = true
            optionRadios[index].setImageResource(R.drawable.bg_quiz_radio_unchecked)
            optionTexts[index].text = q.options[index]
            optionBadges[index].visibility = View.GONE
        }
    }

    private fun selectOption(index: Int) {
        selectedOptionIndex = index

        // Highlight selected option, reset others to neutral
        optionLayouts.forEachIndexed { i, layout ->
            if (i == index) {
                layout.setBackgroundResource(R.drawable.bg_quiz_option_selected)
                optionRadios[i].setImageResource(R.drawable.bg_quiz_radio_selected)
            } else {
                layout.setBackgroundResource(R.drawable.bg_quiz_option_normal)
                optionRadios[i].setImageResource(R.drawable.bg_quiz_radio_unchecked)
            }
            optionBadges[i].visibility = View.GONE
        }
    }

    private fun handleCheckAnswer() {
        if (selectedOptionIndex == -1) {
            Toast.makeText(this, "Please select an answer first!", Toast.LENGTH_SHORT).show()
            return
        }

        val q = questions[currentQuestionIndex]
        isAnswerChecked = true

        // Disable clicks on options
        optionLayouts.forEach { it.isClickable = false }

        if (selectedOptionIndex == q.correctIndex) {
            // Correct answer
            score++
            optionLayouts[selectedOptionIndex].setBackgroundResource(R.drawable.bg_quiz_option_correct)
            optionRadios[selectedOptionIndex].setImageResource(R.drawable.bg_quiz_radio_checked)
            optionBadges[selectedOptionIndex].setImageResource(R.drawable.ic_check)
            optionBadges[selectedOptionIndex].visibility = View.VISIBLE

            txtResult.setTextColor(getColor(R.color.brand_green))
            val expl = if (q.explanation.isNotEmpty()) "\n💡 ${q.explanation}" else ""
            txtResult.text = "Awesome! Correct answer 🎉$expl"
        } else {
            // Wrong answer
            optionLayouts[selectedOptionIndex].setBackgroundResource(R.drawable.bg_quiz_option_wrong)
            optionBadges[selectedOptionIndex].setImageResource(R.drawable.ic_close_red)
            optionBadges[selectedOptionIndex].visibility = View.VISIBLE

            // Reveal the correct option in green
            val correctIdx = q.correctIndex
            optionLayouts[correctIdx].setBackgroundResource(R.drawable.bg_quiz_option_correct)
            optionRadios[correctIdx].setImageResource(R.drawable.bg_quiz_radio_checked)
            optionBadges[correctIdx].setImageResource(R.drawable.ic_check)
            optionBadges[correctIdx].visibility = View.VISIBLE

            txtResult.setTextColor(getColor(R.color.brand_red))
            val expl = if (q.explanation.isNotEmpty()) "\n💡 ${q.explanation}" else ""
            txtResult.text = "Correct answer: ${q.options[correctIdx]}$expl"

            // Record mistake in SharedPreferences for Practice Mode
            saveMistake(q.title, q.options[selectedOptionIndex], q.options[correctIdx])
        }

        // Change button to Next
        btnCheck.text = if (currentQuestionIndex == questions.size - 1) "See Results →" else "Next  →"
    }

    private fun handleNextQuestion() {
        currentQuestionIndex++
        displayQuestion()
    }

    private fun saveMistake(questionTitle: String, wrong: String, correct: String) {
        val prefs = getSharedPreferences("LearnlyMistakes", Context.MODE_PRIVATE)
        val old = prefs.getString("mistakes", "") ?: ""
        val entry = "$lessonName: $questionTitle (Your answer: $wrong | Correct: $correct)"
        val updated = if (old.isEmpty()) entry else "$old\n$entry"
        prefs.edit().putString("mistakes", updated).apply()

        // Sync to Firebase
        FirebaseHelper.recordMistake(this, questionTitle, wrong, correct, lessonName)
    }

    private fun showCompletionScreen() {
        // Save lesson completion in preferences
        val progressPrefs = getSharedPreferences("LearnlyProgress", MODE_PRIVATE)
        val completedCount = progressPrefs.getInt("completedLessons", 0) + 1
        progressPrefs.edit().putInt("completedLessons", completedCount).apply()

        // Track category-specific completion for dynamic progress bars
        val catKey = when (lessonName) {
            "basic_words" -> "wordsCompleted"
            "basic_sentences" -> "sentencesCompleted"
            else -> "grammarCompleted"
        }
        val catCount = progressPrefs.getInt(catKey, 0) + 1
        progressPrefs.edit().putInt(catKey, catCount).apply()

        // Update real accuracy
        val accuracy = if (questions.isNotEmpty()) (score * 100) / questions.size else 100
        UserStatsHelper.setAccuracy(this, accuracy)

        // Sync attempt and score to Firebase
        FirebaseHelper.recordQuizAttempt(this, lessonName, score, questions.size)

        val email = getSharedPreferences("LearnlyProfile", MODE_PRIVATE).getString("userEmail", "Student") ?: "Student"
        FirebaseHelper.recordActivity(
            title = "Quiz completed",
            subtitle = "$email scored $score/${questions.size} in $lessonName",
            type = "quiz"
        )

        // Update UI to completion card
        imgQuestionGraphic.setImageResource(R.drawable.ic_crown)
        txtWordTitle.text = "Congratulations! 🎉"
        txtQuestion.text = "You scored $score out of ${questions.size} in $lessonName!"
        txtQuestionNumber.text = "Completed"
        progressBarLesson.progress = questions.size

        optionsContainer.visibility = View.GONE
        txtResult.setTextColor(getColor(R.color.brand_green))
        txtResult.text = if (score >= 4) "Excellent mastery! Keep up the momentum!" else "Great effort! Review mistakes in Practice Mode."

        btnCheck.text = "Return to Lessons ✓"
        btnCheck.setOnClickListener {
            finish()
        }
    }

    override fun onDestroy() {
        textToSpeech?.stop()
        textToSpeech?.shutdown()
        super.onDestroy()
    }
}