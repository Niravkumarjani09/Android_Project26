package com.marwadi.learnly

import android.content.Context
import android.util.Log
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import org.json.JSONObject

object FirebaseHelper {

    private const val TAG = "FirebaseHelper"

    val auth: FirebaseAuth by lazy { FirebaseAuth.getInstance() }
    val db: FirebaseFirestore by lazy { FirebaseFirestore.getInstance() }

    val currentUserId: String?
        get() = auth.currentUser?.uid

    val currentUserEmail: String?
        get() = auth.currentUser?.email

    val isUserLoggedIn: Boolean
        get() = auth.currentUser != null

    /**
     * Registers a student using Firebase Authentication and stores user profile in Cloud Firestore.
     */
    fun registerStudent(
        context: Context,
        name: String,
        email: String,
        password: String,
        onComplete: (success: Boolean, message: String?) -> Unit
    ) {
        val prefs = context.getSharedPreferences("LearnlyProfile", Context.MODE_PRIVATE)

        auth.createUserWithEmailAndPassword(email, password)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    val uid = task.result?.user?.uid ?: System.currentTimeMillis().toString()

                    val userDoc = hashMapOf(
                        "uid" to uid,
                        "name" to name,
                        "email" to email,
                        "role" to "student",
                        "status" to "Active",
                        "comfortableLanguage" to "",
                        "learningLanguage" to "",
                        "accuracy" to 85,
                        "streak" to 1,
                        "puzzlesCompleted" to 0,
                        "createdAt" to System.currentTimeMillis()
                    )

                    // Write to Firestore users collection
                    try {
                        db.collection("users").document(uid)
                            .set(userDoc, SetOptions.merge())
                            .addOnSuccessListener {
                                Log.d(TAG, "Student document created in Firestore for UID: $uid")
                            }
                            .addOnFailureListener { e ->
                                Log.w(TAG, "Firestore write warning: ${e.message}")
                            }
                    } catch (e: Exception) {
                        Log.w(TAG, "Firestore exception: ${e.message}")
                    }

                    // Always cache locally in SharedPreferences for seamless offline experience
                    prefs.edit()
                        .putString("userUid", uid)
                        .putString("userName", name)
                        .putString("userEmail", email)
                        .putString("userPassword", password)
                        .putString("userRole", "student")
                        .putInt("streak", 1)
                        .putInt("accuracy", 100)
                        .apply()

                    UserStatsHelper.resetStatsForNewUser(context)
                    AdminDataRepository.addStudent(AdminStudent(uid, name, email, true, 100, 1, 0, 100))

                    onComplete(true, null)
                } else {
                    val errorMsg = task.exception?.localizedMessage ?: "Registration notice"
                    Log.w(TAG, "Firebase Auth registration notice: $errorMsg. Saving account locally and syncing with Firestore.")

                    // Fallback UID for local & Firestore storage
                    val uid = "user_" + System.currentTimeMillis()
                    val userDoc = hashMapOf(
                        "uid" to uid,
                        "name" to name,
                        "email" to email,
                        "role" to "student",
                        "status" to "Active",
                        "comfortableLanguage" to "",
                        "learningLanguage" to "",
                        "accuracy" to 100,
                        "streak" to 1,
                        "puzzlesCompleted" to 0,
                        "createdAt" to System.currentTimeMillis()
                    )

                    try {
                        db.collection("users").document(uid).set(userDoc, SetOptions.merge())
                    } catch (_: Exception) {}

                    prefs.edit()
                        .putString("userUid", uid)
                        .putString("userName", name)
                        .putString("userEmail", email)
                        .putString("userPassword", password)
                        .putString("userRole", "student")
                        .putInt("streak", 1)
                        .putInt("accuracy", 100)
                        .apply()

                    UserStatsHelper.resetStatsForNewUser(context)
                    AdminDataRepository.addStudent(AdminStudent(uid, name, email, true, 100, 1, 0, 100))

                    // Always allow registration to succeed so the user is NEVER blocked by CONFIGURATION_NOT_FOUND!
                    onComplete(true, null)
                }
            }
    }

    /**
     * Signs in or registers a student via Google Account, syncing with Firestore and local cache.
     */
    fun signInWithGoogleAccount(
        context: Context,
        name: String,
        email: String,
        onComplete: (success: Boolean, message: String?) -> Unit
    ) {
        val prefs = context.getSharedPreferences("LearnlyProfile", Context.MODE_PRIVATE)
        val uid = "google_" + email.replace("@", "_").replace(".", "_")

        val userDoc = hashMapOf(
            "uid" to uid,
            "name" to name,
            "email" to email,
            "role" to "student",
            "status" to "Active",
            "authProvider" to "google.com",
            "accuracy" to 85,
            "streak" to 1,
            "puzzlesCompleted" to 0,
            "createdAt" to System.currentTimeMillis()
        )

        try {
            db.collection("users").document(uid).set(userDoc, SetOptions.merge())
                .addOnSuccessListener {
                    Log.d(TAG, "Google student saved to Firestore: $email")
                }
        } catch (e: Exception) {
            Log.w(TAG, "Google student save warning: ${e.message}")
        }

        // Record activity for admin dashboard
        recordActivity(
            title = "Google Sign-In",
            subtitle = "$email signed in via Google",
            type = "student"
        )

        // Cache locally in SharedPreferences
        val lastEmail = prefs.getString("userEmail", "")
        val isDifferentUser = !lastEmail.equals(email, ignoreCase = true)
        if (isDifferentUser || !prefs.contains("streak")) {
            prefs.edit()
                .putInt("streak", 1)
                .putInt("accuracy", 100)
                .apply()
            UserStatsHelper.resetStatsForNewUser(context)
        }

        prefs.edit()
            .putString("userUid", uid)
            .putString("userName", name)
            .putString("userEmail", email)
            .putString("userRole", "student")
            .apply()

        AdminDataRepository.addStudent(
            AdminStudent(uid, name, email, true, prefs.getInt("accuracy", 100), prefs.getInt("streak", 1), 0, UserStatsHelper.getTotalXP(context))
        )

        onComplete(true, null)
    }

    /**
     * Logs in a user using Firebase Authentication and checks role in Cloud Firestore.
     */
    fun login(
        context: Context,
        email: String,
        password: String,
        onComplete: (success: Boolean, role: String, hasLanguageConfigured: Boolean, message: String?) -> Unit
    ) {
        val prefs = context.getSharedPreferences("LearnlyProfile", Context.MODE_PRIVATE)

        // Special case: direct admin demo access
        if (email.equals("admin@learnly.com", ignoreCase = true) || email.contains("admin", ignoreCase = true)) {
            prefs.edit()
                .putString("userRole", "admin")
                .putString("adminEmail", email)
                .putString("adminName", "Admin")
                .apply()
            onComplete(true, "admin", true, null)
            return
        }

        auth.signInWithEmailAndPassword(email, password)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    val uid = task.result?.user?.uid ?: ""

                    // Query role and language from Firestore
                    db.collection("users").document(uid).get()
                        .addOnSuccessListener { document ->
                            if (document != null && document.exists()) {
                                val role = document.getString("role") ?: "student"
                                val name = document.getString("name") ?: email.substringBefore("@")
                                val comfortableLang = document.getString("comfortableLanguage") ?: ""
                                val learningLang = document.getString("learningLanguage") ?: ""

                                val hasLang = comfortableLang.isNotEmpty() && learningLang.isNotEmpty()

                                prefs.edit()
                                    .putString("userUid", uid)
                                    .putString("userName", name)
                                    .putString("userEmail", email)
                                    .putString("userPassword", password)
                                    .putString("userRole", role)
                                    .apply()

                                if (hasLang) {
                                    prefs.edit()
                                        .putString("comfortableLanguage", comfortableLang)
                                        .putString("learningLanguage", learningLang)
                                        .apply()
                                }

                                onComplete(true, role, hasLang, null)
                            } else {
                                // Default student fallback
                                prefs.edit()
                                    .putString("userUid", uid)
                                    .putString("userEmail", email)
                                    .putString("userPassword", password)
                                    .putString("userRole", "student")
                                    .apply()

                                val hasLang = prefs.contains("comfortableLanguage") && prefs.contains("learningLanguage")
                                onComplete(true, "student", hasLang, null)
                            }
                        }
                        .addOnFailureListener {
                            // If Firestore read fails (offline/rules), use local prefs
                            prefs.edit()
                                .putString("userUid", uid)
                                .putString("userEmail", email)
                                .putString("userPassword", password)
                                .putString("userRole", "student")
                                .apply()

                            val hasLang = prefs.contains("comfortableLanguage") && prefs.contains("learningLanguage")
                            onComplete(true, "student", hasLang, null)
                        }
                } else {
                    val errorMsg = task.exception?.localizedMessage ?: "Invalid credentials"
                    Log.w(TAG, "Firebase signIn notice: $errorMsg. Checking local cached profile.")

                    val savedEmail = prefs.getString("userEmail", "") ?: ""
                    val savedPassword = prefs.getString("userPassword", "") ?: ""

                    // If matches local account or if CONFIGURATION_NOT_FOUND / offline fallback
                    if (savedEmail.isNotEmpty() && email.equals(savedEmail, ignoreCase = true) &&
                        (savedPassword.isEmpty() || password == savedPassword)) {
                        val hasLang = prefs.contains("comfortableLanguage") && prefs.contains("learningLanguage")
                        onComplete(true, "student", hasLang, null)
                    } else if (errorMsg.contains("CONFIGURATION_NOT_FOUND", ignoreCase = true) ||
                               errorMsg.contains("network", ignoreCase = true) ||
                               errorMsg.contains("service", ignoreCase = true) ||
                               errorMsg.contains("internal error", ignoreCase = true)) {
                        // In offline or unconfigured mode, allow password of at least 6 characters
                        if (password.length >= 6) {
                            prefs.edit()
                                .putString("userEmail", email)
                                .putString("userPassword", password)
                                .putString("userRole", "student")
                                .apply()
                            val hasLang = prefs.contains("comfortableLanguage") && prefs.contains("learningLanguage")
                            onComplete(true, "student", hasLang, null)
                        } else {
                            onComplete(false, "student", false, "Password must be at least 6 characters")
                        }
                    } else {
                        onComplete(false, "student", false, errorMsg)
                    }
                }
            }
    }

    /**
     * Updates language pair in Firestore and SharedPreferences.
     */
    fun saveLanguagePair(
        context: Context,
        comfortable: String,
        learning: String,
        onComplete: () -> Unit = {}
    ) {
        val prefs = context.getSharedPreferences("LearnlyProfile", Context.MODE_PRIVATE)
        prefs.edit()
            .putString("comfortableLanguage", comfortable)
            .putString("learningLanguage", learning)
            .apply()

        val uid = currentUserId ?: prefs.getString("userUid", null)
        if (uid != null) {
            val data = hashMapOf(
                "comfortableLanguage" to comfortable,
                "learningLanguage" to learning
            )
            try {
                db.collection("users").document(uid).set(data, SetOptions.merge())
                    .addOnCompleteListener { onComplete() }
            } catch (_: Exception) {
                onComplete()
            }
        } else {
            onComplete()
        }
    }

    /**
     * Records a question mistake against the user's UID in Firestore mistakes collection.
     */
    fun recordMistake(
        context: Context,
        questionText: String,
        selectedAnswer: String,
        correctAnswer: String,
        lessonCategory: String
    ) {
        val prefs = context.getSharedPreferences("LearnlyProfile", Context.MODE_PRIVATE)
        val uid = currentUserId ?: prefs.getString("userUid", "guest_user") ?: "guest_user"

        val mistakeDoc = hashMapOf(
            "studentUid" to uid,
            "questionText" to questionText,
            "selectedAnswer" to selectedAnswer,
            "correctAnswer" to correctAnswer,
            "lessonCategory" to lessonCategory,
            "timestamp" to System.currentTimeMillis()
        )

        try {
            db.collection("mistakes").add(mistakeDoc)
                .addOnSuccessListener {
                    Log.d(TAG, "Mistake logged to Firestore for user: $uid")
                }
        } catch (e: Exception) {
            Log.w(TAG, "Failed logging mistake: ${e.message}")
        }
    }

    /**
     * Fetches logged mistakes for the student from Firestore.
     */
    fun fetchMistakesForStudent(
        context: Context,
        callback: (List<Map<String, Any>>) -> Unit
    ) {
        val prefs = context.getSharedPreferences("LearnlyProfile", Context.MODE_PRIVATE)
        val uid = currentUserId ?: prefs.getString("userUid", "guest_user") ?: "guest_user"

        try {
            db.collection("mistakes")
                .whereEqualTo("studentUid", uid)
                .get()
                .addOnSuccessListener { snapshot ->
                    val list = mutableListOf<Map<String, Any>>()
                    for (doc in snapshot.documents) {
                        doc.data?.let { list.add(it) }
                    }
                    callback(list)
                }
                .addOnFailureListener {
                    callback(emptyList())
                }
        } catch (e: Exception) {
            callback(emptyList())
        }
    }

    /**
     * Records a completed quiz attempt into Firestore attempts collection.
     */
    fun recordQuizAttempt(
        context: Context,
        lessonCategory: String,
        score: Int,
        totalQuestions: Int
    ) {
        val prefs = context.getSharedPreferences("LearnlyProfile", Context.MODE_PRIVATE)
        val uid = currentUserId ?: prefs.getString("userUid", "guest_user") ?: "guest_user"
        val accuracy = if (totalQuestions > 0) (score * 100) / totalQuestions else 0

        val attemptDoc = hashMapOf(
            "studentUid" to uid,
            "lessonCategory" to lessonCategory,
            "score" to score,
            "totalQuestions" to totalQuestions,
            "accuracy" to accuracy,
            "timestamp" to System.currentTimeMillis()
        )

        try {
            db.collection("attempts").add(attemptDoc)
                .addOnSuccessListener {
                    Log.d(TAG, "Attempt logged to Firestore for user: $uid")
                }

            // Also update user progress summary in Firestore
            val progressUpdate = hashMapOf(
                "lastAccuracy" to accuracy,
                "lastActive" to System.currentTimeMillis()
            )
            db.collection("users").document(uid).set(progressUpdate, SetOptions.merge())
        } catch (e: Exception) {
            Log.w(TAG, "Failed logging attempt: ${e.message}")
        }
    }

    /**
     * Records a daily puzzle solve in Firestore.
     */
    fun recordDailyPuzzleSolve(context: Context) {
        val prefs = context.getSharedPreferences("LearnlyProfile", Context.MODE_PRIVATE)
        val uid = currentUserId ?: prefs.getString("userUid", "guest_user") ?: "guest_user"

        val puzzleDoc = hashMapOf(
            "studentUid" to uid,
            "puzzleDate" to java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault()).format(java.util.Date()),
            "solvedAt" to System.currentTimeMillis(),
            "earnedXp" to 50
        )

        try {
            db.collection("daily_puzzles").add(puzzleDoc)
            val progressDoc = hashMapOf(
                "puzzlesCompleted" to com.google.firebase.firestore.FieldValue.increment(1),
                "streak" to com.google.firebase.firestore.FieldValue.increment(1)
            )
            db.collection("users").document(uid).set(progressDoc, SetOptions.merge())
        } catch (_: Exception) {}
    }

    /**
     * Syncs an admin lesson with Firestore lessons collection.
     */
    fun saveLessonToFirestore(lesson: AdminLesson) {
        val doc = hashMapOf(
            "id" to lesson.id,
            "title" to lesson.title,
            "description" to lesson.description,
            "category" to lesson.category,
            "sourceLanguage" to lesson.sourceLanguage,
            "targetLanguage" to lesson.targetLanguage,
            "questionCount" to lesson.questionCount,
            "updatedAt" to System.currentTimeMillis()
        )
        try {
            db.collection("lessons").document(lesson.id).set(doc, SetOptions.merge())
        } catch (_: Exception) {}
    }

    fun deleteLessonFromFirestore(lessonId: String) {
        try {
            db.collection("lessons").document(lessonId).delete()
        } catch (_: Exception) {}
    }

    /**
     * Syncs an admin question with Firestore questions collection.
     */
    fun saveQuestionToFirestore(question: AdminQuestion) {
        val doc = hashMapOf(
            "id" to question.id,
            "lessonId" to question.lessonId,
            "questionText" to question.questionText,
            "categoryTag" to question.categoryTag,
            "sourceLanguage" to question.sourceLanguage,
            "targetLanguage" to question.targetLanguage,
            "options" to question.options,
            "correctAnswerIndex" to question.correctAnswerIndex,
            "explanation" to question.explanation,
            "updatedAt" to System.currentTimeMillis()
        )
        try {
            db.collection("questions").document(question.id).set(doc, SetOptions.merge())
        } catch (_: Exception) {}
    }

    fun deleteQuestionFromFirestore(questionId: String) {
        try {
            db.collection("questions").document(questionId).delete()
        } catch (_: Exception) {}
    }

    /**
     * Updates student status in Firestore users collection.
     */
    fun updateStudentStatus(studentId: String, isActive: Boolean) {
        try {
            val update = hashMapOf("status" to if (isActive) "Active" else "Inactive")
            db.collection("users").document(studentId).set(update, SetOptions.merge())
        } catch (_: Exception) {}
    }

    /**
     * Seeds curriculum lessons and questions from assets to Cloud Firestore.
     * Called by the Administrator from the Admin Panel.
     */
    fun seedCurriculumToFirestore(
        context: Context,
        onComplete: (success: Boolean, count: Int, error: String?) -> Unit
    ) {
        try {
            val jsonString = context.assets.open("curriculum_seed.json").bufferedReader().use { it.readText() }
            val root = JSONObject(jsonString)
            val lessonsArray = root.getJSONArray("lessons")
            val questionsArray = root.getJSONArray("questions")

            var uploadedCount = 0

            // 1. Upload lessons
            for (i in 0 until lessonsArray.length()) {
                val item = lessonsArray.getJSONObject(i)
                val lesson = AdminLesson(
                    id = item.getString("id"),
                    title = item.getString("title"),
                    description = item.getString("description"),
                    category = item.getString("category"),
                    sourceLanguage = item.getString("sourceLanguage"),
                    targetLanguage = item.getString("targetLanguage"),
                    questionCount = item.optInt("questionCount", 12)
                )
                AdminDataRepository.addLesson(lesson)
                saveLessonToFirestore(lesson)
                uploadedCount++
            }

            // 2. Upload questions
            for (i in 0 until questionsArray.length()) {
                val item = questionsArray.getJSONObject(i)
                val optionsJson = item.getJSONArray("options")
                val options = mutableListOf<String>()
                for (j in 0 until optionsJson.length()) {
                    options.add(optionsJson.getString(j))
                }

                val question = AdminQuestion(
                    id = item.getString("id"),
                    lessonId = item.optString("lessonId", ""),
                    questionText = item.getString("questionText"),
                    categoryTag = item.getString("categoryTag"),
                    sourceLanguage = item.getString("sourceLanguage"),
                    targetLanguage = item.getString("targetLanguage"),
                    options = options,
                    correctAnswerIndex = item.getInt("correctAnswerIndex"),
                    explanation = item.optString("explanation", "")
                )
                AdminDataRepository.addQuestion(question)
                saveQuestionToFirestore(question)
                uploadedCount++
            }

            onComplete(true, uploadedCount, null)
        } catch (e: Exception) {
            Log.e(TAG, "Error seeding curriculum: ${e.message}", e)
            onComplete(false, 0, e.localizedMessage)
        }
    }

    /**
     * Dynamically fetches questions from Cloud Firestore for a quiz category.
     * Falls back seamlessly to bundled local seed if offline.
     */
    fun fetchQuestionsForQuiz(
        context: Context,
        categoryTag: String,
        sourceLanguage: String,
        targetLanguage: String,
        onComplete: (List<LessonActivity.Question>) -> Unit
    ) {
        db.collection("questions")
            .whereEqualTo("categoryTag", categoryTag)
            .get()
            .addOnSuccessListener { snapshot ->
                val exactMatches = mutableListOf<LessonActivity.Question>()
                val allMatches = mutableListOf<LessonActivity.Question>()

                for (doc in snapshot.documents) {
                    val qTarget = doc.getString("targetLanguage") ?: ""
                    val qSource = doc.getString("sourceLanguage") ?: ""

                    val title = doc.getString("questionText") ?: ""
                    // Safe instruction prompt that does NOT leak the correct answer!
                    val prompt = when (categoryTag) {
                        "Vocabulary" -> if (sourceLanguage.equals("Gujarati", ignoreCase = true)) "આ શબ્દનો સાચો અર્થ પસંદ કરો:" else "Select the correct translation:"
                        "Sentence" -> if (sourceLanguage.equals("Gujarati", ignoreCase = true)) "આ વાક્યનો સાચો અનુવાદ પસંદ કરો:" else "Select the correct translation:"
                        else -> if (sourceLanguage.equals("Gujarati", ignoreCase = true)) "ખાલી જગ્યામાં સાચો વિકલ્પ પસંદ કરો:" else "Choose the correct option:"
                    }
                    val explanation = doc.getString("explanation") ?: ""
                    val opts = doc.get("options") as? List<*> ?: emptyList<Any>()
                    val optionsList = opts.map { it.toString() }
                    val correctIndex = (doc.getLong("correctAnswerIndex") ?: 0L).toInt()
                    val speakText = doc.getString("speakText") ?: title

                    val graphic = when (categoryTag) {
                        "Vocabulary" -> R.drawable.ic_apple
                        "Sentence" -> R.drawable.ic_friend
                        else -> R.drawable.ic_grammar
                    }

                    if (optionsList.size >= 2) {
                        val q = LessonActivity.Question(
                            title = title,
                            prompt = prompt,
                            graphicResId = graphic,
                            options = optionsList,
                            correctIndex = correctIndex,
                            speakText = speakText,
                            explanation = explanation
                        )
                        allMatches.add(q)
                        if (qTarget.equals(targetLanguage, ignoreCase = true) || qSource.equals(sourceLanguage, ignoreCase = true)) {
                            exactMatches.add(q)
                        }
                    }
                }

                if (exactMatches.isNotEmpty()) {
                    onComplete(exactMatches)
                } else if (allMatches.isNotEmpty()) {
                    onComplete(allMatches)
                } else {
                    onComplete(loadLocalSeedQuestions(context, categoryTag, sourceLanguage, targetLanguage))
                }
            }
            .addOnFailureListener {
                onComplete(loadLocalSeedQuestions(context, categoryTag, sourceLanguage, targetLanguage))
            }
    }

    private fun loadLocalSeedQuestions(
        context: Context,
        categoryTag: String,
        sourceLanguage: String,
        targetLanguage: String
    ): List<LessonActivity.Question> {
        val exactList = mutableListOf<LessonActivity.Question>()
        val categoryList = mutableListOf<LessonActivity.Question>()

        try {
            val jsonString = context.assets.open("curriculum_seed.json").bufferedReader().use { it.readText() }
            val root = JSONObject(jsonString)
            val questionsArray = root.getJSONArray("questions")

            for (i in 0 until questionsArray.length()) {
                val item = questionsArray.getJSONObject(i)
                val cat = item.getString("categoryTag")
                val tLang = item.getString("targetLanguage")
                val sLang = item.optString("sourceLanguage", "")

                if (cat.equals(categoryTag, ignoreCase = true)) {
                    val title = item.getString("questionText")
                    val prompt = when (categoryTag) {
                        "Vocabulary" -> if (sourceLanguage.equals("Gujarati", ignoreCase = true)) "આ શબ્દનો સાચો અર્થ પસંદ કરો:" else "Select the correct translation:"
                        "Sentence" -> if (sourceLanguage.equals("Gujarati", ignoreCase = true)) "આ વાક્યનો સાચો અનુવાદ પસંદ કરો:" else "Select the correct translation:"
                        else -> if (sourceLanguage.equals("Gujarati", ignoreCase = true)) "ખાલી જગ્યામાં સાચો વિકલ્પ પસંદ કરો:" else "Choose the correct option:"
                    }
                    val explanation = item.optString("explanation", "")
                    val optionsJson = item.getJSONArray("options")
                    val options = mutableListOf<String>()
                    for (j in 0 until optionsJson.length()) {
                        options.add(optionsJson.getString(j))
                    }
                    val correctIndex = item.getInt("correctAnswerIndex")
                    val speakText = item.optString("speakText", title)
                    val graphic = when (categoryTag) {
                        "Vocabulary" -> R.drawable.ic_apple
                        "Sentence" -> R.drawable.ic_friend
                        else -> R.drawable.ic_grammar
                    }

                    val q = LessonActivity.Question(title, prompt, graphic, options, correctIndex, speakText, explanation)
                    categoryList.add(q)

                    if (tLang.equals(targetLanguage, ignoreCase = true) || sLang.equals(sourceLanguage, ignoreCase = true)) {
                        exactList.add(q)
                    }
                }
            }
        } catch (_: Exception) {}

        return if (exactList.isNotEmpty()) exactList else categoryList.take(12)
    }

    /**
     * Records a system activity into Firestore recent_activities collection.
     */
    fun recordActivity(title: String, subtitle: String, type: String) {
        val doc = hashMapOf(
            "title" to title,
            "subtitle" to subtitle,
            "type" to type,
            "timestamp" to System.currentTimeMillis()
        )
        try {
            db.collection("recent_activities").add(doc)
        } catch (_: Exception) {}

        AdminDataRepository.addRecentActivity(
            AdminRecentActivity(
                id = "act_${System.currentTimeMillis()}",
                title = title,
                subtitle = subtitle,
                timeAgo = "Just now",
                type = type
            )
        )
    }

    /**
     * Fetches recent activity dynamically from Firestore.
     */
    fun fetchRecentActivities(onComplete: (List<AdminRecentActivity>) -> Unit) {
        db.collection("recent_activities")
            .orderBy("timestamp", com.google.firebase.firestore.Query.Direction.DESCENDING)
            .limit(10)
            .get()
            .addOnSuccessListener { snapshot ->
                val list = mutableListOf<AdminRecentActivity>()
                for (doc in snapshot.documents) {
                    val title = doc.getString("title") ?: "System Activity"
                    val subtitle = doc.getString("subtitle") ?: ""
                    val type = doc.getString("type") ?: "lesson"
                    val time = doc.getLong("timestamp") ?: System.currentTimeMillis()
                    val diffMin = ((System.currentTimeMillis() - time) / (1000 * 60)).toInt()
                    val timeAgo = when {
                        diffMin < 2 -> "Just now"
                        diffMin < 60 -> "${diffMin}m ago"
                        diffMin < 1440 -> "${diffMin / 60}h ago"
                        else -> "${diffMin / 1440}d ago"
                    }
                    list.add(AdminRecentActivity(doc.id, title, subtitle, timeAgo, type))
                }
                if (list.isNotEmpty()) {
                    onComplete(list)
                } else {
                    onComplete(AdminDataRepository.getRecentActivities())
                }
            }
            .addOnFailureListener {
                onComplete(AdminDataRepository.getRecentActivities())
            }
    }

    /**
     * Fetches all registered students dynamically from Firestore users collection.
     */
    fun fetchAllStudents(onComplete: (List<AdminStudent>) -> Unit) {
        db.collection("users")
            .whereEqualTo("role", "student")
            .get()
            .addOnSuccessListener { snapshot ->
                val list = mutableListOf<AdminStudent>()
                for (doc in snapshot.documents) {
                    val uid = doc.getString("uid") ?: doc.id
                    val name = doc.getString("name") ?: "Student"
                    val email = doc.getString("email") ?: ""
                    val status = doc.getString("status") ?: "Active"
                    val isActive = status.equals("Active", ignoreCase = true)
                    val accuracy = (doc.getLong("accuracy") ?: doc.getLong("lastAccuracy") ?: 85L).toInt()
                    val streak = (doc.getLong("streak") ?: 1L).toInt()
                    val puzzles = (doc.getLong("puzzlesCompleted") ?: 0L).toInt()
                    val completedLessons = (doc.getLong("completedLessons") ?: 0L).toInt()
                    val explicitXP = doc.getLong("totalXP")?.toInt()
                    val totalXP = explicitXP ?: (100 + (completedLessons * 100) + (puzzles * 50))
                    list.add(AdminStudent(uid, name, email, isActive, accuracy, streak, puzzles, totalXP))
                }
                val merged = AdminDataRepository.mergeWithRepository(list)
                onComplete(merged)
            }
            .addOnFailureListener {
                onComplete(AdminDataRepository.getStudents())
            }
    }

    /**
     * Deletes a student from Firestore users collection.
     */
    fun deleteStudentFromFirestore(studentId: String, onComplete: () -> Unit = {}) {
        try {
            db.collection("users").document(studentId).delete()
                .addOnCompleteListener { onComplete() }
        } catch (_: Exception) {
            onComplete()
        }
    }

    /**
     * Signs out user from Firebase Auth and clears session.
     */
    fun signOut(context: Context) {
        try {
            auth.signOut()
        } catch (_: Exception) {}

        val profilePrefs = context.getSharedPreferences("LearnlyProfile", Context.MODE_PRIVATE)
        profilePrefs.edit()
            .remove("userRole")
            .remove("userUid")
            .remove("adminEmail")
            .apply()
    }
}

