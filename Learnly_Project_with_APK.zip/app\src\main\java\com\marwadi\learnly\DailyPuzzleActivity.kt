package com.marwadi.learnly

import android.os.Bundle
import android.widget.ImageButton
import android.widget.RelativeLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton

class DailyPuzzleActivity : AppCompatActivity() {

    data class PuzzleWord(val word: String, val hint: String)

    private val puzzlePool = listOf(
        PuzzleWord("LEARN", "To gain knowledge or skill through study"),
        PuzzleWord("SMART", "Having or showing quick intelligence"),
        PuzzleWord("BRAIN", "The organ of thinking and memory"),
        PuzzleWord("WORDS", "Units of language used for communication"),
        PuzzleWord("STUDY", "Applying mental effort to acquire knowledge"),
        PuzzleWord("SPEAK", "Expressing thoughts through spoken words"),
        PuzzleWord("WRITE", "Marking letters on paper or screen"),
        PuzzleWord("FOCUS", "Directing your attention to one goal"),
        PuzzleWord("SHINE", "Giving out bright light or standing out"),
        PuzzleWord("QUICK", "Moving or learning with great speed"),
        PuzzleWord("DREAM", "A cherished aspiration or ambition"),
        PuzzleWord("GUIDE", "Directing or pointing out the way"),
        PuzzleWord("PEACE", "State of harmony and calmness"),
        PuzzleWord("WATER", "The essential fluid of all life"),
        PuzzleWord("APPLE", "A popular crisp, sweet fruit")
    )

    private var targetWord = "LEARN"
    private var targetHint = ""
    private var scrambledLetters = mutableListOf<String>()
    private val selectedLetters = mutableListOf<String>()
    private var hintsLeft = 3

    private lateinit var slotViews: List<TextView>
    private lateinit var bubbleViews: List<TextView>
    private lateinit var txtHintLeft: TextView
    private lateinit var txtStreakPuzzle: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_daily_puzzle)

        NavigationHelper.setupDarkBottomNav(this)

        val btnBack = findViewById<ImageButton>(R.id.btnBackPuzzle)
        btnBack.setOnClickListener {
            finish()
        }

        val slot1 = findViewById<TextView>(R.id.slot1)
        val slot2 = findViewById<TextView>(R.id.slot2)
        val slot3 = findViewById<TextView>(R.id.slot3)
        val slot4 = findViewById<TextView>(R.id.slot4)
        val slot5 = findViewById<TextView>(R.id.slot5)
        slotViews = listOf(slot1, slot2, slot3, slot4, slot5)

        val bubbleL = findViewById<TextView>(R.id.bubbleL)
        val bubbleE = findViewById<TextView>(R.id.bubbleE)
        val bubbleA = findViewById<TextView>(R.id.bubbleA)
        val bubbleR = findViewById<TextView>(R.id.bubbleR_center)
        val bubbleN = findViewById<TextView>(R.id.bubbleN)
        bubbleViews = listOf(bubbleL, bubbleE, bubbleA, bubbleR, bubbleN)

        val btnHint = findViewById<RelativeLayout>(R.id.btnHint)
        txtHintLeft = findViewById(R.id.txtHintLeft)
        txtStreakPuzzle = findViewById(R.id.txtStreakPuzzle)
        val btnSubmit = findViewById<AppCompatButton>(R.id.btnSubmitPuzzle)

        // Setup letter bubble click listeners
        bubbleViews.forEach { bubble ->
            bubble.setOnClickListener {
                val letter = bubble.text.toString()
                if (selectedLetters.size < targetWord.length) {
                    selectedLetters.add(letter)
                    bubble.isEnabled = false
                    bubble.alpha = 0.35f
                    updateSlots()
                }
            }
        }

        // Click slots to remove the last letter or that specific letter
        slotViews.forEachIndexed { index, slot ->
            slot.setOnClickListener {
                if (index < selectedLetters.size) {
                    val removedLetter = selectedLetters.removeAt(index)
                    val matchingBubble = bubbleViews.firstOrNull { !it.isEnabled && it.text == removedLetter }
                    matchingBubble?.let {
                        it.isEnabled = true
                        it.alpha = 1.0f
                    }
                    updateSlots()
                }
            }
        }

        // Hint click
        btnHint.setOnClickListener {
            if (hintsLeft > 0) {
                if (selectedLetters.size < targetWord.length) {
                    hintsLeft--
                    txtHintLeft.text = "($hintsLeft left)"
                    val nextChar = targetWord[selectedLetters.size].toString()
                    selectedLetters.add(nextChar)
                    val matchingBubble = bubbleViews.firstOrNull { it.isEnabled && it.text == nextChar }
                    matchingBubble?.let {
                        it.isEnabled = false
                        it.alpha = 0.35f
                    }
                    updateSlots()
                } else {
                    Toast.makeText(this, "All slots are filled!", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "No hints left today!", Toast.LENGTH_SHORT).show()
            }
        }

        // Submit click
        btnSubmit.setOnClickListener {
            val formedWord = selectedLetters.joinToString("")
            if (formedWord.equals(targetWord, ignoreCase = true)) {
                Toast.makeText(this, "🎉 Awesome! \"$targetWord\" is correct! +50 XP", Toast.LENGTH_LONG).show()
                val prefs = getSharedPreferences("LearnlyProgress", MODE_PRIVATE)
                val solved = prefs.getInt("puzzlesSolved", 0) + 1
                prefs.edit().putInt("puzzlesSolved", solved).apply()

                UserStatsHelper.incrementStreak(this)
                val streak = UserStatsHelper.getStreak(this)
                txtStreakPuzzle.text = "Streak $streak"

                getSharedPreferences("LearnlyNotifications", MODE_PRIVATE)
                    .edit().putBoolean("isCleared", false).apply()

                // Sync daily puzzle solve to Firebase
                FirebaseHelper.recordDailyPuzzleSolve(this)

                // Load next shuffled word from pool
                window.decorView.postDelayed({
                    if (!isFinishing) {
                        loadNewPuzzle()
                    }
                }, 1200)
            } else {
                Toast.makeText(this, "Not quite! Try another combination or use a Hint.", Toast.LENGTH_SHORT).show()
            }
        }

        loadNewPuzzle()
    }

    private fun loadNewPuzzle() {
        val prefs = getSharedPreferences("LearnlyProgress", MODE_PRIVATE)
        val lastWord = prefs.getString("lastPuzzleWord", "") ?: ""

        val candidates = puzzlePool.filter { it.word != lastWord }
        val puzzle = candidates.random()
        targetWord = puzzle.word
        targetHint = puzzle.hint
        prefs.edit().putString("lastPuzzleWord", targetWord).apply()

        var scrambled = targetWord.map { it.toString() }.shuffled().toMutableList()
        while (scrambled.joinToString("") == targetWord) {
            scrambled = targetWord.map { it.toString() }.shuffled().toMutableList()
        }
        scrambledLetters = scrambled
        selectedLetters.clear()
        hintsLeft = 3
        txtHintLeft.text = "($hintsLeft left)"

        val profilePrefs = getSharedPreferences("LearnlyProfile", MODE_PRIVATE)
        val streak = profilePrefs.getInt("streak", 1)
        txtStreakPuzzle.text = "Streak $streak"

        bubbleViews.forEachIndexed { index, bubble ->
            if (index < scrambledLetters.size) {
                bubble.text = scrambledLetters[index]
            }
            bubble.isEnabled = true
            bubble.alpha = 1.0f
        }
        updateSlots()
    }

    private fun updateSlots() {
        slotViews.forEachIndexed { i, slot ->
            if (i < selectedLetters.size) {
                slot.text = selectedLetters[i]
            } else {
                slot.text = ""
            }
        }
    }

    override fun onResume() {
        super.onResume()
        NavigationHelper.setupDarkBottomNav(this)
    }
}