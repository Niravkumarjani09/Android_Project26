package com.marwadi.learnly

import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.View
import android.view.Window
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class ProfileActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        NavigationHelper.setupBottomNav(this, NavTab.PROFILE)

        val txtUserName = findViewById<TextView>(R.id.txtUserName)
        val txtUserEmail = findViewById<TextView>(R.id.txtUserEmail)
        val txtProfileComfortable = findViewById<TextView>(R.id.txtProfileComfortable)
        val txtProfileLearn = findViewById<TextView>(R.id.txtProfileLearn)
        val imgProfileFlag1 = findViewById<ImageView>(R.id.imgProfileFlag1)
        val imgProfileFlag2 = findViewById<ImageView>(R.id.imgProfileFlag2)

        val cardLanguagePairProfile = findViewById<View>(R.id.cardLanguagePairProfile)
        val menuMyProgress = findViewById<View>(R.id.menuMyProgress)
        val menuLeaderboard = findViewById<View>(R.id.menuLeaderboard)
        val menuSettings = findViewById<View>(R.id.menuSettings)
        val menuHelp = findViewById<View>(R.id.menuHelp)
        val menuAboutDevelopers = findViewById<View>(R.id.menuAboutDevelopers)
        val btnLogout = findViewById<View>(R.id.btnLogout)
        val btnSettingsTop = findViewById<View>(R.id.btnSettingsTop)

        // Read user data from prefs
        val prefs = getSharedPreferences("LearnlyProfile", MODE_PRIVATE)
        val userName = prefs.getString("userName", "Nirav Jani") ?: "Nirav Jani"
        val userEmail = prefs.getString("userEmail", "niravjani@example.com") ?: "niravjani@example.com"
        val comfortableLanguage = prefs.getString("comfortableLanguage", "Gujarati") ?: "Gujarati"
        val learningLanguage = prefs.getString("learningLanguage", "English") ?: "English"

        txtUserName.text = userName
        txtUserEmail.text = userEmail
        txtProfileComfortable.text = comfortableLanguage
        txtProfileLearn.text = learningLanguage

        if (comfortableLanguage == "English") {
            imgProfileFlag1.setImageResource(R.drawable.ic_flag_uk)
            imgProfileFlag2.setImageResource(R.drawable.ic_flag_india)
        } else {
            imgProfileFlag1.setImageResource(R.drawable.ic_flag_india)
            imgProfileFlag2.setImageResource(R.drawable.ic_flag_uk)
        }

        cardLanguagePairProfile.setOnClickListener {
            val intent = Intent(this, LanguageSetupActivity::class.java)
            startActivity(intent)
        }

        menuMyProgress.setOnClickListener {
            val intent = Intent(this, ProgressActivity::class.java)
            startActivity(intent)
        }

        menuLeaderboard.setOnClickListener {
            val intent = Intent(this, LeaderboardActivity::class.java)
            startActivity(intent)
        }

        menuSettings.setOnClickListener {
            Toast.makeText(this, "Settings coming soon", Toast.LENGTH_SHORT).show()
        }

        btnSettingsTop.setOnClickListener {
            Toast.makeText(this, "Settings coming soon", Toast.LENGTH_SHORT).show()
        }

        menuHelp.setOnClickListener {
            Toast.makeText(this, "Help & Support coming soon", Toast.LENGTH_SHORT).show()
        }

        menuAboutDevelopers?.setOnClickListener {
            val intent = Intent(this, AboutDevelopersActivity::class.java)
            startActivity(intent)
        }

        // Show Logout Confirmation Modal (Screen 13)
        btnLogout.setOnClickListener {
            showLogoutDialog()
        }
    }

    private fun showLogoutDialog() {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setContentView(R.layout.dialog_logout_confirmation)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.setCancelable(true)

        val btnConfirm = dialog.findViewById<Button>(R.id.btnConfirmLogout)
        val btnCancel = dialog.findViewById<Button>(R.id.btnCancelLogout)

        btnConfirm.setOnClickListener {
            dialog.dismiss()
            FirebaseHelper.signOut(this)
            // Return to Welcome Screen (Screen 14)
            val intent = Intent(this, WelcomeActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            finish()
        }

        btnCancel.setOnClickListener {
            dialog.dismiss()
        }

        dialog.show()
    }

    override fun onResume() {
        super.onResume()
        NavigationHelper.setupBottomNav(this, NavTab.PROFILE)
    }
}