package com.marwadi.learnly

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class AdminAddLessonActivity : AppCompatActivity() {

    private lateinit var edtTitle: EditText
    private lateinit var spinnerCategory: Spinner
    private lateinit var spinnerSource: Spinner
    private lateinit var spinnerTarget: Spinner
    private lateinit var edtContent: EditText

    private var editingLesson: AdminLesson? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin_add_lesson)

        val btnBack = findViewById<ImageButton>(R.id.btnBackAddLesson)
        val txtHeader = findViewById<TextView>(R.id.txtAddLessonHeaderTitle)
        edtTitle = findViewById(R.id.edtLessonTitleInput)
        spinnerCategory = findViewById(R.id.spinnerLessonCategory)
        spinnerSource = findViewById(R.id.spinnerSourceLanguage)
        spinnerTarget = findViewById(R.id.spinnerTargetLanguage)
        edtContent = findViewById(R.id.edtLessonContentInput)
        val btnCancel = findViewById<Button>(R.id.btnCancelAddLesson)
        val btnSave = findViewById<Button>(R.id.btnSaveLesson)

        btnBack.setOnClickListener { finish() }
        btnCancel.setOnClickListener { finish() }

        // Setup Spinners
        val categories = listOf("Basic Words", "Basic Sentences", "Everyday Grammar")
        val categoryAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, categories)
        spinnerCategory.adapter = categoryAdapter

        val languages = listOf("English", "Gujarati", "Spanish", "French", "Japanese")
        val sourceAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, languages)
        val targetAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, languages)
        spinnerSource.adapter = sourceAdapter
        spinnerTarget.adapter = targetAdapter

        // Default: English -> Gujarati
        spinnerSource.setSelection(languages.indexOf("English"))
        spinnerTarget.setSelection(languages.indexOf("Gujarati"))

        // Check if editing
        @Suppress("DEPRECATION")
        editingLesson = intent.getSerializableExtra("EXTRA_LESSON") as? AdminLesson
        editingLesson?.let { lesson ->
            txtHeader.text = "Edit Lesson"
            edtTitle.setText(lesson.title)
            edtContent.setText(lesson.description)

            val catIndex = categories.indexOf(lesson.category)
            if (catIndex != -1) spinnerCategory.setSelection(catIndex)

            val srcIndex = languages.indexOf(lesson.sourceLanguage)
            if (srcIndex != -1) spinnerSource.setSelection(srcIndex)

            val tgtIndex = languages.indexOf(lesson.targetLanguage)
            if (tgtIndex != -1) spinnerTarget.setSelection(tgtIndex)
        }

        btnSave.setOnClickListener {
            val title = edtTitle.text.toString().trim()
            val category = spinnerCategory.selectedItem.toString()
            val sourceLang = spinnerSource.selectedItem.toString()
            val targetLang = spinnerTarget.selectedItem.toString()
            val content = edtContent.text.toString().trim()

            if (title.isEmpty()) {
                edtTitle.error = "Please enter a lesson title"
                return@setOnClickListener
            }

            if (sourceLang == targetLang) {
                Toast.makeText(this, "Source and Target languages must be different", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val finalDesc = if (content.isNotEmpty()) content else "Interactive $category practice in $targetLang"

            if (editingLesson != null) {
                editingLesson?.let {
                    it.title = title
                    it.category = category
                    it.sourceLanguage = sourceLang
                    it.targetLanguage = targetLang
                    it.description = finalDesc
                    AdminDataRepository.updateLesson(it)
                    Toast.makeText(this, "Lesson updated successfully", Toast.LENGTH_SHORT).show()
                }
            } else {
                val newLesson = AdminLesson(
                    id = "les_${System.currentTimeMillis()}",
                    title = title,
                    description = finalDesc,
                    category = category,
                    sourceLanguage = sourceLang,
                    targetLanguage = targetLang,
                    questionCount = 10
                )
                AdminDataRepository.addLesson(newLesson)
                Toast.makeText(this, "Lesson created successfully", Toast.LENGTH_SHORT).show()
            }

            finish()
        }
    }
}

