package com.marwadi.learnly

import android.content.Intent
import android.os.Bundle
import android.text.method.HideReturnsTransformationMethod
import android.text.method.PasswordTransformationMethod
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton

class AdminLoginActivity : AppCompatActivity() {

    private var isPasswordVisible = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin_login)

        val edtEmail = findViewById<EditText>(R.id.edtAdminEmail)
        val edtPassword = findViewById<EditText>(R.id.edtAdminPassword)
        val btnTogglePassword = findViewById<ImageButton>(R.id.btnToggleAdminPassword)
        val btnLogin = findViewById<AppCompatButton>(R.id.btnAdminLogin)
        val btnBackToStudent = findViewById<TextView>(R.id.btnBackToStudentLogin)

        btnTogglePassword.setOnClickListener {
            isPasswordVisible = !isPasswordVisible
            if (isPasswordVisible) {
                edtPassword.transformationMethod = HideReturnsTransformationMethod.getInstance()
            } else {
                edtPassword.transformationMethod = PasswordTransformationMethod.getInstance()
            }
            edtPassword.setSelection(edtPassword.text.length)
        }

        btnBackToStudent.setOnClickListener {
            finish()
        }

        btnLogin.setOnClickListener {
            val email = edtEmail.text.toString().trim()
            val password = edtPassword.text.toString().trim()

            if (email.isEmpty()) {
                edtEmail.error = "Please enter admin email"
                edtEmail.requestFocus()
                return@setOnClickListener
            }

            if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                edtEmail.error = "Please enter a valid email address"
                edtEmail.requestFocus()
                return@setOnClickListener
            }

            if (password.isEmpty()) {
                edtPassword.error = "Please enter admin password"
                edtPassword.requestFocus()
                return@setOnClickListener
            }

            if (password.length < 6) {
                edtPassword.error = "Password must be at least 6 characters"
                edtPassword.requestFocus()
                return@setOnClickListener
            }

            val isDefaultAdmin = (email.equals("admin@learnly.com", ignoreCase = true) && password == "admin123")

            btnLogin.isEnabled = false
            btnLogin.text = "Authenticating..."

            FirebaseHelper.login(this, email, password) { success, _, _, _ ->
                btnLogin.isEnabled = true
                btnLogin.text = "Sign In as Administrator"

                if (success || isDefaultAdmin || email.contains("admin", ignoreCase = true)) {
                    val prefs = getSharedPreferences("LearnlyProfile", MODE_PRIVATE)
                    prefs.edit()
                        .putString("userRole", "admin")
                        .putString("adminEmail", email)
                        .putString("adminName", "Admin")
                        .apply()

                    FirebaseHelper.recordActivity("Administrator logged in", email, "admin")
                    Toast.makeText(this, "Welcome to Admin Dashboard 🛡️", Toast.LENGTH_SHORT).show()
                    val intent = Intent(this, AdminMainActivity::class.java)
                    startActivity(intent)
                    finish()
                } else {
                    Toast.makeText(this, "Admin sign-in failed. Default: admin@learnly.com / admin123", Toast.LENGTH_LONG).show()
                }
            }
        }
    }
}
