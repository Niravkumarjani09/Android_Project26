package com.marwadi.learnly

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.google.android.material.bottomsheet.BottomSheetDialog

object GoogleAuthHelper {

    data class GoogleAccount(val name: String, val email: String)

    private const val PREFS_SAVED_ACCOUNTS = "LearnlySavedAccounts"
    private const val KEY_ACCOUNTS_SERIALIZED = "accounts_list"

    private val AVATAR_COLORS = listOf(
        "#4F46E5", // Indigo
        "#059669", // Emerald
        "#7C3AED", // Violet
        "#D97706", // Amber
        "#2563EB", // Blue
        "#DC2626"  // Rose
    )

    /**
     * Saves an account to the device's persistent Google account pool so that
     * newly registered users immediately see their email available next time.
     */
    fun saveAccount(context: Context, name: String, email: String) {
        if (email.isBlank()) return
        val cleanEmail = email.trim()
        val cleanName = if (name.isNotBlank()) name.trim() else cleanEmail.substringBefore("@")

        val currentAccounts = getAllSavedAccounts(context)
        // Remove existing duplicate by email
        currentAccounts.removeAll { it.email.equals(cleanEmail, ignoreCase = true) }
        // Prepend newest at the top
        currentAccounts.add(0, GoogleAccount(cleanName, cleanEmail))

        saveAllAccounts(context, currentAccounts)
    }

    private fun getAllSavedAccounts(context: Context): MutableList<GoogleAccount> {
        val prefs = context.getSharedPreferences(PREFS_SAVED_ACCOUNTS, Context.MODE_PRIVATE)
        val serialized = prefs.getString(KEY_ACCOUNTS_SERIALIZED, null)

        val list = mutableListOf<GoogleAccount>()
        if (!serialized.isNullOrEmpty()) {
            val lines = serialized.split("\n")
            for (line in lines) {
                val parts = line.split("|")
                if (parts.size >= 2) {
                    list.add(GoogleAccount(parts[0], parts[1]))
                }
            }
        }

        // If list is empty, initialize default seed accounts for Nirav
        if (list.isEmpty()) {
            list.add(GoogleAccount("Nirav Jani", "niravjani@gmail.com"))
            list.add(GoogleAccount("Nirav Student", "nirav.student@gmail.com"))
            saveAllAccounts(context, list)
        }

        return list
    }

    private fun saveAllAccounts(context: Context, accounts: List<GoogleAccount>) {
        val prefs = context.getSharedPreferences(PREFS_SAVED_ACCOUNTS, Context.MODE_PRIVATE)
        val serialized = accounts.joinToString("\n") { "${it.name}|${it.email}" }
        prefs.edit().putString(KEY_ACCOUNTS_SERIALIZED, serialized).apply()
    }

    /**
     * Filters available Google accounts so that only emails respective to the specified user
     * (e.g. Nirav's emails if user is Nirav) are displayed, avoiding displaying all emails across the app.
     */
    fun getFilteredAccountsForUser(context: Context, userFilter: String?): List<GoogleAccount> {
        val allAccounts = getAllSavedAccounts(context)

        // Determine effective filter keyword from argument or active profile
        val profilePrefs = context.getSharedPreferences("LearnlyProfile", Context.MODE_PRIVATE)
        val activeUserName = profilePrefs.getString("userName", "Nirav") ?: "Nirav"
        val activeUserEmail = profilePrefs.getString("userEmail", "") ?: ""

        val filterQuery = when {
            !userFilter.isNullOrBlank() -> userFilter.trim()
            activeUserName.isNotBlank() -> activeUserName.trim()
            activeUserEmail.isNotBlank() -> activeUserEmail.substringBefore("@")
            else -> "Nirav"
        }

        // Extract first word / handle (e.g. "nirav" from "Nirav Jani" or "nirav@...")
        val searchToken = filterQuery.split(" ", "@", ".").firstOrNull { it.length >= 2 }?.lowercase() ?: filterQuery.lowercase()

        // Filter accounts matching this specific user
        val userAccounts = allAccounts.filter {
            it.name.lowercase().contains(searchToken) || it.email.lowercase().contains(searchToken)
        }.toMutableList()

        // If user typed a custom new name/email not yet in the list, dynamically synthesize an option for them
        if (userAccounts.isEmpty()) {
            val derivedName = if (filterQuery.contains("@")) {
                filterQuery.substringBefore("@").replaceFirstChar { it.uppercase() }
            } else {
                filterQuery
            }
            val derivedEmail = if (filterQuery.contains("@")) {
                filterQuery
            } else {
                "${filterQuery.lowercase().replace(" ", ".")}@gmail.com"
            }
            userAccounts.add(GoogleAccount(derivedName, derivedEmail))
        }

        return userAccounts
    }

    /**
     * Displays a dynamic Google Account Chooser bottom-sheet modal
     * showing only the accounts respective to the target user.
     */
    fun showAccountChooser(
        activity: Activity,
        userFilterQuery: String? = null,
        onSuccess: (name: String, email: String) -> Unit
    ) {
        val bottomSheet = BottomSheetDialog(activity)
        val dialogView = LayoutInflater.from(activity).inflate(R.layout.dialog_google_account_picker, null)
        bottomSheet.setContentView(dialogView)

        val layoutAccountsList = dialogView.findViewById<LinearLayout>(R.id.layoutAccountsList)
        val dynamicContainer = dialogView.findViewById<LinearLayout>(R.id.layoutDynamicAccountsContainer)
        val layoutGoogleLoading = dialogView.findViewById<LinearLayout>(R.id.layoutGoogleLoading)
        val txtGoogleLoadingStatus = dialogView.findViewById<TextView>(R.id.txtGoogleLoadingStatus)
        val btnAddAccount = dialogView.findViewById<View>(R.id.btnAddAccount)

        val proceedWithAccount = { chosenName: String, chosenEmail: String ->
            layoutAccountsList?.visibility = View.GONE
            layoutGoogleLoading?.visibility = View.VISIBLE
            txtGoogleLoadingStatus?.text = "Signing in as $chosenEmail..."

            // Save to persistent device accounts so it is always available next time
            saveAccount(activity, chosenName, chosenEmail)

            FirebaseHelper.signInWithGoogleAccount(activity, chosenName, chosenEmail) { success, _ ->
                if (success) {
                    dialogView.postDelayed({
                        if (!activity.isFinishing) {
                            bottomSheet.dismiss()
                            Toast.makeText(activity, "Signed in as $chosenEmail", Toast.LENGTH_SHORT).show()
                            onSuccess(chosenName, chosenEmail)
                        }
                    }, 500)
                } else {
                    layoutAccountsList?.visibility = View.VISIBLE
                    layoutGoogleLoading?.visibility = View.GONE
                    Toast.makeText(activity, "Google sign in error. Please try again.", Toast.LENGTH_SHORT).show()
                }
            }
        }

        // Dynamically populate matching accounts for this user
        val targetAccounts = getFilteredAccountsForUser(activity, userFilterQuery)
        dynamicContainer?.removeAllViews()

        targetAccounts.forEachIndexed { index, account ->
            val itemView = LayoutInflater.from(activity).inflate(R.layout.item_google_account, dynamicContainer, false)
            val avatarContainer = itemView.findViewById<FrameLayout>(R.id.avatarContainer)
            val txtAvatar = itemView.findViewById<TextView>(R.id.txtAvatarLetter)
            val txtName = itemView.findViewById<TextView>(R.id.txtItemAccountName)
            val txtEmail = itemView.findViewById<TextView>(R.id.txtItemAccountEmail)

            val colorHex = AVATAR_COLORS[index % AVATAR_COLORS.size]
            avatarContainer.background?.setTint(Color.parseColor(colorHex))

            val initial = account.name.trim().firstOrNull()?.uppercase() ?: "G"
            txtAvatar.text = initial
            txtName.text = account.name
            txtEmail.text = account.email

            itemView.setOnClickListener {
                proceedWithAccount(account.name, account.email)
            }

            dynamicContainer?.addView(itemView)

            // Add divider between account items
            if (index < targetAccounts.size - 1) {
                val divider = View(activity).apply {
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        (1 * activity.resources.displayMetrics.density).toInt()
                    )
                    setBackgroundColor(activity.getColor(R.color.border_light))
                }
                dynamicContainer?.addView(divider)
            }
        }

        btnAddAccount?.setOnClickListener {
            showAddGoogleAccountDialog(activity) { newName, newEmail ->
                proceedWithAccount(newName, newEmail)
            }
        }

        bottomSheet.show()
    }

    private fun showAddGoogleAccountDialog(
        activity: Activity,
        onAccountEntered: (name: String, email: String) -> Unit
    ) {
        val input = EditText(activity).apply {
            hint = "e.g. yourname@gmail.com"
            setSingleLine()
            setPadding(48, 36, 48, 36)
        }

        AlertDialog.Builder(activity)
            .setTitle("Add Google Account")
            .setMessage("Enter the Google email address you want to continue with:")
            .setView(input)
            .setPositiveButton("Continue") { _, _ ->
                val email = input.text.toString().trim()
                if (email.contains("@") && email.contains(".")) {
                    val rawName = email.substringBefore("@")
                        .replace(".", " ")
                        .split(" ")
                        .joinToString(" ") { it.replaceFirstChar { char -> char.uppercase() } }
                    val name = if (rawName.isNotEmpty()) rawName else "Google User"
                    onAccountEntered(name, email)
                } else {
                    Toast.makeText(activity, "Please enter a valid Google email address", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
