package com.marwadi.learnly

import android.app.Dialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RelativeLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton
import androidx.core.content.ContextCompat

data class LeaderboardEntry(
    val rank: Int,
    val name: String,
    val points: Int,
    val avatarResId: Int,
    val streak: Int,
    val isCurrentUser: Boolean = false,
    val note: String = ""
)

class LeaderboardActivity : AppCompatActivity() {

    private var isFriendsTab: Boolean = false
    private var isAllTime: Boolean = false

    private lateinit var tabGlobal: TextView
    private lateinit var tabFriends: TextView
    private lateinit var chipThisWeek: TextView
    private lateinit var chipAllTime: TextView

    private lateinit var imgPodium1: ImageView
    private lateinit var txtPodiumName1: TextView
    private lateinit var txtPodiumPoints1: TextView
    private lateinit var txtPodiumStreak1: TextView

    private lateinit var imgPodium2: ImageView
    private lateinit var txtPodiumName2: TextView
    private lateinit var txtPodiumPoints2: TextView
    private lateinit var txtPodiumStreak2: TextView

    private lateinit var imgPodium3: ImageView
    private lateinit var txtPodiumName3: TextView
    private lateinit var txtPodiumPoints3: TextView
    private lateinit var txtPodiumStreak3: TextView

    private lateinit var layoutLeaderboardList: LinearLayout
    private lateinit var cardInviteFriends: View
    private lateinit var btnInviteFriends: View

    private lateinit var txtStickyRankNumber: TextView
    private lateinit var txtStickyUserStatus: TextView

    private var currentUserName: String = "Nirav"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_leaderboard)

        NavigationHelper.setupBottomNav(this, NavTab.PROFILE)

        val prefs = getSharedPreferences("LearnlyProfile", MODE_PRIVATE)
        currentUserName = prefs.getString("userName", "Nirav") ?: "Nirav"

        val btnBack = findViewById<ImageButton>(R.id.btnBackLeaderboard)
        btnBack.setOnClickListener {
            finish()
        }

        tabGlobal = findViewById(R.id.tabGlobal)
        tabFriends = findViewById(R.id.tabFriends)
        chipThisWeek = findViewById(R.id.chipThisWeek)
        chipAllTime = findViewById(R.id.chipAllTime)

        imgPodium1 = findViewById(R.id.imgPodium1)
        txtPodiumName1 = findViewById(R.id.txtPodiumName1)
        txtPodiumPoints1 = findViewById(R.id.txtPodiumPoints1)
        txtPodiumStreak1 = findViewById(R.id.txtPodiumStreak1)

        imgPodium2 = findViewById(R.id.imgPodium2)
        txtPodiumName2 = findViewById(R.id.txtPodiumName2)
        txtPodiumPoints2 = findViewById(R.id.txtPodiumPoints2)
        txtPodiumStreak2 = findViewById(R.id.txtPodiumStreak2)

        imgPodium3 = findViewById(R.id.imgPodium3)
        txtPodiumName3 = findViewById(R.id.txtPodiumName3)
        txtPodiumPoints3 = findViewById(R.id.txtPodiumPoints3)
        txtPodiumStreak3 = findViewById(R.id.txtPodiumStreak3)

        layoutLeaderboardList = findViewById(R.id.layoutLeaderboardList)
        cardInviteFriends = findViewById(R.id.cardInviteFriends)
        btnInviteFriends = findViewById(R.id.btnInviteFriends)

        txtStickyRankNumber = findViewById(R.id.txtStickyRankNumber)
        txtStickyUserStatus = findViewById(R.id.txtStickyUserStatus)

        // Tab click listeners
        tabGlobal.setOnClickListener {
            if (isFriendsTab) {
                isFriendsTab = false
                updateTabDisplay()
                populateLeaderboard()
            }
        }

        tabFriends.setOnClickListener {
            if (!isFriendsTab) {
                isFriendsTab = true
                updateTabDisplay()
                populateLeaderboard()
            }
        }

        // Timeframe filter click listeners
        chipThisWeek.setOnClickListener {
            if (isAllTime) {
                isAllTime = false
                chipThisWeek.setBackgroundResource(R.drawable.bg_chip_selected)
                chipThisWeek.setTextColor(ContextCompat.getColor(this, R.color.white))
                chipAllTime.setBackgroundResource(R.drawable.bg_chip_unselected)
                chipAllTime.setTextColor(ContextCompat.getColor(this, R.color.text_body))
                populateLeaderboard()
            }
        }

        chipAllTime.setOnClickListener {
            if (!isAllTime) {
                isAllTime = true
                chipAllTime.setBackgroundResource(R.drawable.bg_chip_selected)
                chipAllTime.setTextColor(ContextCompat.getColor(this, R.color.white))
                chipThisWeek.setBackgroundResource(R.drawable.bg_chip_unselected)
                chipThisWeek.setTextColor(ContextCompat.getColor(this, R.color.text_body))
                populateLeaderboard()
            }
        }

        btnInviteFriends.setOnClickListener {
            shareFriendInvite()
        }

        updateTabDisplay()
        populateLeaderboard()
    }

    private fun updateTabDisplay() {
        if (!isFriendsTab) {
            tabGlobal.setBackgroundResource(R.drawable.bg_tab_active)
            tabGlobal.setTextColor(ContextCompat.getColor(this, R.color.white))
            tabFriends.setBackgroundResource(R.drawable.bg_tab_inactive)
            tabFriends.setTextColor(ContextCompat.getColor(this, R.color.text_muted))
            cardInviteFriends.visibility = View.GONE
        } else {
            tabFriends.setBackgroundResource(R.drawable.bg_tab_active)
            tabFriends.setTextColor(ContextCompat.getColor(this, R.color.white))
            tabGlobal.setBackgroundResource(R.drawable.bg_tab_inactive)
            tabGlobal.setTextColor(ContextCompat.getColor(this, R.color.text_muted))
            cardInviteFriends.visibility = View.VISIBLE
        }
    }

    private fun populateLeaderboard() {
        // 1. Immediately render with cached cohort so user NEVER sees a blank screen
        val cachedStudents = AdminDataRepository.getStudents()
        buildAndRenderEntries(cachedStudents)

        // 2. Query Firestore asynchronously to merge any live registered accounts
        FirebaseHelper.fetchAllStudents { liveStudents ->
            if (isFinishing || isDestroyed) return@fetchAllStudents
            buildAndRenderEntries(liveStudents)
        }
    }

    private fun buildAndRenderEntries(studentList: List<AdminStudent>) {
        val prefs = getSharedPreferences("LearnlyProfile", MODE_PRIVATE)
        val currentUid = prefs.getString("userUid", "") ?: ""
        val currentEmail = prefs.getString("userEmail", "") ?: ""
        val currentStreak = UserStatsHelper.getStreak(this)
        val currentXP = UserStatsHelper.getTotalXP(this)
        val multiplier = if (isAllTime) 3 else 1

        val entries = mutableListOf<LeaderboardEntry>()
        var foundCurrentUser = false

        val avatarPool = listOf(
            R.drawable.ic_avatar_default,
            R.drawable.ic_avatar_rahul,
            R.drawable.ic_avatar_alex,
            R.drawable.ic_avatar_priya,
            R.drawable.ic_avatar_ananya,
            R.drawable.ic_avatar_kabir
        )

        // Convert registered students into Leaderboard entries
        for (student in studentList) {
            val isCurrent = (student.id == currentUid ||
                             (currentEmail.isNotEmpty() && student.email.equals(currentEmail, ignoreCase = true)) ||
                             student.name.equals(currentUserName, ignoreCase = true))

            if (isCurrent) {
                foundCurrentUser = true
            }

            val streak = if (isCurrent) currentStreak else student.streak.coerceAtLeast(1)
            val points = (if (isCurrent) currentXP else student.totalXP.coerceAtLeast(100)) * multiplier
            val avatar = avatarPool[Math.abs(student.name.hashCode()) % avatarPool.size]
            val displayName = if (isCurrent) "$currentUserName (You)" else student.name
            val note = if (isCurrent) "Your learning rank" else "Registered Student"

            entries.add(
                LeaderboardEntry(
                    rank = 0,
                    name = displayName,
                    points = points,
                    avatarResId = avatar,
                    streak = streak,
                    isCurrentUser = isCurrent,
                    note = note
                )
            )
        }

        // Always ensure the active current student is included
        if (!foundCurrentUser) {
            entries.add(
                LeaderboardEntry(
                    rank = 0,
                    name = "$currentUserName (You)",
                    points = currentXP * multiplier,
                    avatarResId = R.drawable.ic_avatar_default,
                    streak = currentStreak,
                    isCurrentUser = true,
                    note = "Your learning rank"
                )
            )
        }

        // Sort descending by points (XP), then by streak
        entries.sortByDescending { it.points * 10000 + it.streak }

        // Assign proper ranks 1, 2, 3...
        val ranked = entries.mapIndexed { index, entry ->
            entry.copy(rank = index + 1)
        }

        // In Friends tab, show study group friends cohort
        val displayList = if (isFriendsTab) {
            val friends = ranked.filterIndexed { index, entry -> entry.isCurrentUser || index % 2 == 0 || index < 4 }
            friends.mapIndexed { i, entry -> entry.copy(rank = i + 1) }
        } else {
            ranked
        }

        renderLeaderboardUI(displayList)
    }

    private fun renderLeaderboardUI(entries: List<LeaderboardEntry>) {
        val col1 = findViewById<View>(R.id.podiumCol1)
        val col2 = findViewById<View>(R.id.podiumCol2)
        val col3 = findViewById<View>(R.id.podiumCol3)

        // Rank 1 (Center)
        if (entries.isNotEmpty()) {
            val first = entries[0]
            col1.visibility = View.VISIBLE
            imgPodium1.setImageResource(first.avatarResId)
            txtPodiumName1.text = first.name
            txtPodiumPoints1.text = "${String.format("%,d", first.points)} XP"
            txtPodiumStreak1.text = "🔥 ${first.streak}d"
            col1.setOnClickListener { showLearnerDetailDialog(first) }
        }

        // Rank 2 (Left)
        if (entries.size >= 2) {
            val second = entries[1]
            col2.visibility = View.VISIBLE
            imgPodium2.setImageResource(second.avatarResId)
            txtPodiumName2.text = second.name
            txtPodiumPoints2.text = "${String.format("%,d", second.points)} XP"
            txtPodiumStreak2.text = "🔥 ${second.streak}d"
            col2.setOnClickListener { showLearnerDetailDialog(second) }
        }

        // Rank 3 (Right)
        if (entries.size >= 3) {
            val third = entries[2]
            col3.visibility = View.VISIBLE
            imgPodium3.setImageResource(third.avatarResId)
            txtPodiumName3.text = third.name
            txtPodiumPoints3.text = "${String.format("%,d", third.points)} XP"
            txtPodiumStreak3.text = "🔥 ${third.streak}d"
            col3.setOnClickListener { showLearnerDetailDialog(third) }
        }

        // Populate Remaining Rows in layoutLeaderboardList
        layoutLeaderboardList.removeAllViews()
        val listItems = if (entries.size > 3) entries.drop(3) else entries
        for (item in listItems) {
            val rowView = createLeaderboardRow(item)
            layoutLeaderboardList.addView(rowView)
        }

        // Update Sticky Rank Bar at Bottom
        val userEntry = entries.find { it.isCurrentUser } ?: entries.firstOrNull()
        if (userEntry != null) {
            txtStickyRankNumber.text = "#${userEntry.rank}"
            val xpStr = String.format("%,d", userEntry.points)
            val rankColor = if (userEntry.rank <= 3) R.color.brand_primary else R.color.brand_secondary
            txtStickyRankNumber.backgroundTintList = ContextCompat.getColorStateList(this, rankColor)
            txtStickyUserStatus.text = "You ($currentUserName) • $xpStr XP • 🔥 ${userEntry.streak} Day Streak"
        }
    }

    private fun createLeaderboardRow(item: LeaderboardEntry): View {
        val row = RelativeLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dpToPx(58)
            ).apply {
                topMargin = dpToPx(6)
            }
            if (item.isCurrentUser) {
                setBackgroundResource(R.drawable.bg_quiz_option_correct)
                backgroundTintList = ContextCompat.getColorStateList(context, R.color.bg_light_secondary)
            } else {
                setBackgroundResource(R.drawable.bg_card_white)
            }
            elevation = dpToPx(2).toFloat()
            setPadding(dpToPx(16), 0, dpToPx(16), 0)
            isClickable = true
            isFocusable = true
            setOnClickListener {
                showLearnerDetailDialog(item)
            }
        }

        // Rank Number
        val txtRank = TextView(this).apply {
            id = View.generateViewId()
            layoutParams = RelativeLayout.LayoutParams(
                dpToPx(26),
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                addRule(RelativeLayout.ALIGN_PARENT_START)
                addRule(RelativeLayout.CENTER_VERTICAL)
            }
            text = item.rank.toString()
            setTextColor(if (item.isCurrentUser) ContextCompat.getColor(context, R.color.brand_secondary) else ContextCompat.getColor(context, R.color.text_muted))
            textSize = 14f
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        row.addView(txtRank)

        // Avatar
        val imgAvatar = ImageView(this).apply {
            id = View.generateViewId()
            layoutParams = RelativeLayout.LayoutParams(
                dpToPx(36),
                dpToPx(36)
            ).apply {
                addRule(RelativeLayout.RIGHT_OF, txtRank.id)
                addRule(RelativeLayout.CENTER_VERTICAL)
                marginStart = dpToPx(8)
            }
            setImageResource(item.avatarResId)
        }
        row.addView(imgAvatar)

        // Name & Streak Container
        val nameLayout = LinearLayout(this).apply {
            id = View.generateViewId()
            orientation = LinearLayout.VERTICAL
            layoutParams = RelativeLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                addRule(RelativeLayout.RIGHT_OF, imgAvatar.id)
                addRule(RelativeLayout.CENTER_VERTICAL)
                marginStart = dpToPx(12)
            }

            val txtName = TextView(context).apply {
                text = item.name
                setTextColor(if (item.isCurrentUser) ContextCompat.getColor(context, R.color.brand_secondary) else ContextCompat.getColor(context, R.color.text_title))
                textSize = 14f
                setTypeface(null, android.graphics.Typeface.BOLD)
            }
            addView(txtName)

            val txtStreak = TextView(context).apply {
                text = "🔥 ${item.streak} days streak"
                setTextColor(ContextCompat.getColor(context, R.color.text_muted))
                textSize = 11f
            }
            addView(txtStreak)
        }
        row.addView(nameLayout)

        // Points on Right
        val txtPoints = TextView(this).apply {
            layoutParams = RelativeLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                addRule(RelativeLayout.ALIGN_PARENT_END)
                addRule(RelativeLayout.CENTER_VERTICAL)
            }
            text = "${String.format("%,d", item.points)} XP"
            setTextColor(if (item.isCurrentUser) ContextCompat.getColor(context, R.color.brand_secondary) else ContextCompat.getColor(context, R.color.brand_primary))
            textSize = 13f
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        row.addView(txtPoints)

        return row
    }

    private fun showLearnerDetailDialog(item: LeaderboardEntry) {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.setCancelable(true)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_card_white)
            setPadding(dpToPx(24), dpToPx(24), dpToPx(24), dpToPx(24))
            gravity = Gravity.CENTER_HORIZONTAL
            layoutParams = ViewGroup.LayoutParams(
                dpToPx(300),
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }

        val avatar = ImageView(this).apply {
            layoutParams = LinearLayout.LayoutParams(dpToPx(64), dpToPx(64))
            setImageResource(item.avatarResId)
        }
        root.addView(avatar)

        val name = TextView(this).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dpToPx(10)
            }
            text = item.name
            textSize = 18f
            setTextColor(ContextCompat.getColor(context, R.color.text_title))
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        root.addView(name)

        val stats = TextView(this).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dpToPx(4)
            }
            text = "Rank #${item.rank} • ${String.format("%,d", item.points)} XP • 🔥 ${item.streak} Day Streak"
            textSize = 12f
            setTextColor(ContextCompat.getColor(context, R.color.brand_primary))
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        root.addView(stats)

        val lang = TextView(this).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dpToPx(6)
            }
            text = "Learning English ➔ Gujarati"
            textSize = 12f
            setTextColor(ContextCompat.getColor(context, R.color.text_muted))
        }
        root.addView(lang)

        val btnCheer = AppCompatButton(this).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dpToPx(44)).apply {
                topMargin = dpToPx(18)
            }
            setBackgroundResource(R.drawable.bg_btn_primary_gradient)
            text = if (item.isCurrentUser) "Great Job! 🎉" else "Give High-Five! 👋"
            setTextColor(Color.WHITE)
            isAllCaps = false
            textSize = 14f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setOnClickListener {
                Toast.makeText(context, "You cheered on ${item.name}! 🙌", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
            }
        }
        root.addView(btnCheer)

        dialog.setContentView(root)
        dialog.show()
    }

    private fun shareFriendInvite() {
        val inviteCode = "LEARNLY-$currentUserName-2026"
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText("Learnly Invite Code", inviteCode)
        clipboard.setPrimaryClip(clip)

        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "Join me on Learnly!")
            putExtra(Intent.EXTRA_TEXT, "Hey! I'm learning languages on Learnly. Use my invite code $inviteCode to join my leaderboard and challenge me! Download Learnly today.")
        }
        try {
            startActivity(Intent.createChooser(shareIntent, "Invite friends via"))
        } catch (_: Exception) {
            Toast.makeText(this, "Invite code copied to clipboard: $inviteCode", Toast.LENGTH_LONG).show()
        }
    }

    private fun dpToPx(dp: Int): Int {
        return (dp * resources.displayMetrics.density).toInt()
    }

    override fun onResume() {
        super.onResume()
        NavigationHelper.setupBottomNav(this, NavTab.PROFILE)
        populateLeaderboard()
    }
}
