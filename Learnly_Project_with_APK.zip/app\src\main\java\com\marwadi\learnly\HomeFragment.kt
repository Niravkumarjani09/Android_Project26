package com.marwadi.learnly

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.fragment.app.Fragment

class HomeFragment : Fragment() {

    private lateinit var txtPairComfortable: TextView
    private lateinit var txtPairLearn: TextView
    private lateinit var imgPairFlag1: ImageView
    private lateinit var imgPairFlag2: ImageView

    private var progressOverallRing: ProgressBar? = null
    private var txtProgressPercent: TextView? = null
    private var txtProgressHint: TextView? = null
    private var txtStreak: TextView? = null
    private var txtHomeTotalXP: TextView? = null
    private var txtAccuracy: TextView? = null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_home, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        txtPairComfortable = view.findViewById(R.id.txtPairComfortable)
        txtPairLearn = view.findViewById(R.id.txtPairLearn)
        imgPairFlag1 = view.findViewById(R.id.imgPairFlag1)
        imgPairFlag2 = view.findViewById(R.id.imgPairFlag2)

        progressOverallRing = view.findViewById(R.id.progressOverallRing)
        txtProgressPercent = view.findViewById(R.id.txtProgressPercent)
        txtProgressHint = view.findViewById(R.id.txtProgressHint)
        txtStreak = view.findViewById(R.id.txtStreak)
        txtHomeTotalXP = view.findViewById(R.id.txtHomeTotalXP)
        txtAccuracy = view.findViewById(R.id.txtAccuracy)

        val cardOverallProgress = view.findViewById<View>(R.id.cardOverallProgress)
        val cardLanguagePair = view.findViewById<View>(R.id.cardLanguagePair)
        val btnLessonsBanner = view.findViewById<View>(R.id.btnLessonsBanner)
        val btnDailyPuzzleCard = view.findViewById<View>(R.id.btnDailyPuzzleCard)
        val btnPracticeModeCard = view.findViewById<View>(R.id.btnPracticeModeCard)

        updateLanguagePair()
        updateDashboardStats()

        cardOverallProgress?.setOnClickListener {
            (activity as? HomeActivity)?.switchToTab(NavTab.PROGRESS)
        }

        cardLanguagePair.setOnClickListener {
            val intent = Intent(requireContext(), LanguageSetupActivity::class.java)
            startActivity(intent)
        }

        btnLessonsBanner.setOnClickListener {
            (activity as? HomeActivity)?.switchToTab(NavTab.LESSONS)
        }

        btnDailyPuzzleCard.setOnClickListener {
            (activity as? HomeActivity)?.switchToTab(NavTab.PUZZLE)
        }

        btnPracticeModeCard.setOnClickListener {
            val prefs = requireContext().getSharedPreferences("LearnlyProfile", Context.MODE_PRIVATE)
            val comfortableLanguage = prefs.getString("comfortableLanguage", "Gujarati") ?: "Gujarati"
            val learningLanguage = prefs.getString("learningLanguage", "English") ?: "English"

            val intent = Intent(requireContext(), PracticeModeActivity::class.java)
            intent.putExtra("comfortableLanguage", comfortableLanguage)
            intent.putExtra("learningLanguage", learningLanguage)
            startActivity(intent)
        }
    }

    private fun updateDashboardStats() {
        val context = context ?: return

        val streak = UserStatsHelper.getStreak(context)
        val xp = UserStatsHelper.getTotalXP(context)
        val percent = UserStatsHelper.getOverallProgressPercent(context)
        val accuracy = UserStatsHelper.getAccuracy(context)

        txtStreak?.text = if (streak == 1) "1 Day Streak" else "$streak Days Streak"
        txtHomeTotalXP?.text = "${String.format("%,d", xp)} XP"
        txtProgressPercent?.text = "$percent%"
        progressOverallRing?.progress = percent
        txtAccuracy?.text = "$accuracy% Accuracy"

        txtProgressHint?.text = when {
            percent == 0 -> "Start learning!"
            percent < 40 -> "Keep going!"
            percent < 80 -> "Great momentum!"
            else -> "Superb mastery!"
        }
    }

    private fun updateLanguagePair() {
        val context = context ?: return
        val prefs = context.getSharedPreferences("LearnlyProfile", Context.MODE_PRIVATE)
        val comfortableLanguage = prefs.getString("comfortableLanguage", "Gujarati") ?: "Gujarati"
        val learningLanguage = prefs.getString("learningLanguage", "English") ?: "English"

        txtPairComfortable.text = comfortableLanguage
        txtPairLearn.text = learningLanguage

        if (comfortableLanguage == "English") {
            imgPairFlag1.setImageResource(R.drawable.ic_flag_uk)
            imgPairFlag2.setImageResource(R.drawable.ic_flag_india)
        } else {
            imgPairFlag1.setImageResource(R.drawable.ic_flag_india)
            imgPairFlag2.setImageResource(R.drawable.ic_flag_uk)
        }
    }

    override fun onResume() {
        super.onResume()
        updateLanguagePair()
        updateDashboardStats()
    }
}
