package com.marwadi.learnly

import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment

class ProgressFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_progress, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val tabOverview = view.findViewById<TextView>(R.id.tabOverviewFrag)
        val tabDetailed = view.findViewById<TextView>(R.id.tabDetailedFrag)

        val layoutOverview = view.findViewById<View>(R.id.layoutOverviewFrag)
        val layoutDetailed = view.findViewById<View>(R.id.layoutDetailedFrag)

        tabOverview.setOnClickListener {
            val ctx = requireContext()
            tabOverview.setBackgroundResource(R.drawable.bg_tab_active)
            tabOverview.setTextColor(ContextCompat.getColor(ctx, R.color.white))
            tabDetailed.setBackgroundResource(R.drawable.bg_tab_inactive)
            tabDetailed.setTextColor(ContextCompat.getColor(ctx, R.color.text_muted))

            layoutOverview.visibility = View.VISIBLE
            layoutDetailed.visibility = View.GONE
        }

        tabDetailed.setOnClickListener {
            val ctx = requireContext()
            tabDetailed.setBackgroundResource(R.drawable.bg_tab_active)
            tabDetailed.setTextColor(ContextCompat.getColor(ctx, R.color.white))
            tabOverview.setBackgroundResource(R.drawable.bg_tab_inactive)
            tabOverview.setTextColor(ContextCompat.getColor(ctx, R.color.text_muted))

            layoutOverview.visibility = View.GONE
            layoutDetailed.visibility = View.VISIBLE
        }

        renderDynamicProgress()
    }

    private fun renderDynamicProgress() {
        val view = view ?: return
        val ctx = context ?: return

        val progressPrefs = ctx.getSharedPreferences("LearnlyProgress", android.content.Context.MODE_PRIVATE)

        val streak = UserStatsHelper.getStreak(ctx)
        val accuracy = UserStatsHelper.getAccuracy(ctx)
        val totalXP = UserStatsHelper.getTotalXP(ctx)

        val wordsCompleted = progressPrefs.getInt("wordsCompleted", 0)
        val sentencesCompleted = progressPrefs.getInt("sentencesCompleted", 0)
        val grammarCompleted = progressPrefs.getInt("grammarCompleted", 0)

        // Overview metrics
        val txtStreak = view.findViewById<TextView>(R.id.txtProgressStreak)
        val txtAccuracy = view.findViewById<TextView>(R.id.txtProgressAccuracy)
        val txtTotalXP = view.findViewById<TextView>(R.id.txtProgressTotalXP)
        val txtWordsLearned = view.findViewById<TextView>(R.id.txtProgressWordsLearned)

        txtStreak?.text = if (streak == 1) "1 Day" else "$streak Days"
        txtAccuracy?.text = "$accuracy%"
        txtTotalXP?.text = String.format("%,d", totalXP)

        val totalWordsLearned = (wordsCompleted * 5) + (sentencesCompleted * 3)
        txtWordsLearned?.text = totalWordsLearned.toString()

        // Dynamic practice time summary
        val txtTimeSummary = view.findViewById<TextView>(R.id.txtProgressTimeSummary)
        val (totalTimeStr, dailyAvgStr) = UserStatsHelper.getFormattedStudyTime(ctx)
        txtTimeSummary?.text = "Total: $totalTimeStr ($dailyAvgStr)"

        // Dynamic weekly activity chart bars
        val barMon = view.findViewById<View>(R.id.barChartMon)
        val barTue = view.findViewById<View>(R.id.barChartTue)
        val barWed = view.findViewById<View>(R.id.barChartWed)
        val barThu = view.findViewById<View>(R.id.barChartThu)
        val barFri = view.findViewById<View>(R.id.barChartFri)
        val barSat = view.findViewById<View>(R.id.barChartSat)
        val barSun = view.findViewById<View>(R.id.barChartSun)

        val totalMins = UserStatsHelper.getPracticeTimeMinutes(ctx)
        val density = resources.displayMetrics.density
        val todayHeightPx = ((24 + (totalMins * 2)).coerceIn(24, 95) * density).toInt()
        barSun?.layoutParams?.height = todayHeightPx
        barSun?.requestLayout()

        val activeBarColor = ContextCompat.getColor(ctx, R.color.brand_primary)
        val inactiveBarColor = Color.parseColor("#CBD5E1")

        val daysBars = listOf(barSat, barFri, barThu, barWed, barTue, barMon)
        daysBars.forEachIndexed { index, bar ->
            val dayOffset = index + 1
            if (dayOffset < streak) {
                val histHeight = ((28 + ((totalMins + index * 4) % 40)) * density).toInt()
                bar?.layoutParams?.height = histHeight
                bar?.backgroundTintList = ColorStateList.valueOf(activeBarColor)
            } else {
                bar?.layoutParams?.height = (8 * density).toInt()
                bar?.backgroundTintList = ColorStateList.valueOf(inactiveBarColor)
            }
            bar?.requestLayout()
        }

        // Detailed mastery metrics
        val txtVocab = view.findViewById<TextView>(R.id.txtMasteryVocabRatio)
        val progVocab = view.findViewById<android.widget.ProgressBar>(R.id.progressMasteryVocab)
        val txtSentences = view.findViewById<TextView>(R.id.txtMasterySentencesRatio)
        val progSentences = view.findViewById<android.widget.ProgressBar>(R.id.progressMasterySentences)
        val txtGrammar = view.findViewById<TextView>(R.id.txtMasteryGrammarRatio)
        val progGrammar = view.findViewById<android.widget.ProgressBar>(R.id.progressMasteryGrammar)

        val vocabPercent = ((wordsCompleted * 100) / 15).coerceIn(0, 100)
        txtVocab?.text = "$vocabPercent% ($wordsCompleted/15 lessons)"
        progVocab?.progress = vocabPercent

        val sentencesPercent = ((sentencesCompleted * 100) / 20).coerceIn(0, 100)
        txtSentences?.text = "$sentencesPercent% ($sentencesCompleted/20 lessons)"
        progSentences?.progress = sentencesPercent

        val grammarPercent = ((grammarCompleted * 100) / 15).coerceIn(0, 100)
        txtGrammar?.text = "$grammarPercent% ($grammarCompleted/15 lessons)"
        progGrammar?.progress = grammarPercent
    }

    override fun onResume() {
        super.onResume()
        renderDynamicProgress()
    }
}
