package com.marwadi.learnly

import android.content.Intent
import android.os.Bundle
import android.text.method.HideReturnsTransformationMethod
import android.text.method.PasswordTransformationMethod
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton

class LoginActivity : AppCompatActivity() {

    private var isPasswordVisible = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val btnBack = findViewById<ImageButton>(R.id.btnBack)
        val edtEmail = findViewById<EditText>(R.id.edtEmail)
        val edtPassword = findViewById<EditText>(R.id.edtPassword)
        val btnTogglePassword = findViewById<ImageButton>(R.id.btnTogglePassword)
        val btnLogin = findViewById<AppCompatButton>(R.id.btnLogin)
        val btnGoogle = findViewById<LinearLayout>(R.id.btnGoogle)
        val txtCreateAccount = findViewById<TextView>(R.id.txtCreateAccount)
        val txtForgotPassword = findViewById<TextView>(R.id.txtForgotPassword)

        btnBack.setOnClickListener {
            finish()
        }

        btnTogglePassword.setOnClickListener {
            isPasswordVisible = !isPasswordVisible
            if (isPasswordVisible) {
                edtPassword.transformationMethod = HideReturnsTransformationMethod.getInstance()
            } else {
                edtPassword.transformationMethod = PasswordTransformationMethod.getInstance()
            }
            edtPassword.setSelection(edtPassword.text.length)
        }

        txtForgotPassword.setOnClickListener {
            Toast.makeText(this, "Password reset link sent to your email", Toast.LENGTH_SHORT).show()
        }

        val btnGoToAdminPortal = findViewById<TextView>(R.id.btnGoToAdminPortal)
        val btnAdminLoginOption = findViewById<AppCompatButton>(R.id.btnAdminLoginOption)

        val openAdmin = {
            val intent = Intent(this, AdminLoginActivity::class.java)
            startActivity(intent)
        }

        btnGoToAdminPortal?.setOnClickListener { openAdmin() }
        btnAdminLoginOption?.setOnClickListener { openAdmin() }

        btnLogin.setOnClickListener {
            val email = edtEmail.text.toString().trim()
            val password = edtPassword.text.toString().trim()

            // 1. Email Validation
            if (email.isEmpty()) {
                edtEmail.error = "Please enter your email"
                edtEmail.requestFocus()
                return@setOnClickListener
            }
            if (!email.contains("admin", ignoreCase = true) && !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                edtEmail.error = "Please enter a valid email address"
                edtEmail.requestFocus()
                return@setOnClickListener
            }

            // 2. Password Validation
            if (password.isEmpty()) {
                edtPassword.error = "Please enter your password"
                edtPassword.requestFocus()
                return@setOnClickListener
            }

            btnLogin.isEnabled = false
            btnLogin.text = "Signing in..."

            FirebaseHelper.login(this, email, password) { success, role, hasLanguageConfigured, errorMsg ->
                btnLogin.isEnabled = true
                btnLogin.text = "Login  →"

                if (success) {
                    if (role.equals("admin", ignoreCase = true)) {
                        FirebaseHelper.recordActivity("Administrator logged in", email, "admin")
                        Toast.makeText(this, "Welcome Admin! 🛡️", Toast.LENGTH_SHORT).show()
                        val intent = Intent(this, AdminMainActivity::class.java)
                        startActivity(intent)
                        finish()
                    } else {
                        val prefs = getSharedPreferences("LearnlyProfile", MODE_PRIVATE)
                        val savedName = prefs.getString("userName", email.substringBefore("@")) ?: email.substringBefore("@")
                        GoogleAuthHelper.saveAccount(this, savedName, email)
                        FirebaseHelper.recordActivity("Student signed in", email, "student")
                        Toast.makeText(this, "Welcome back! 👋", Toast.LENGTH_SHORT).show()
                        val intent = if (hasLanguageConfigured) {
                            Intent(this, HomeActivity::class.java)
                        } else {
                            Intent(this, LanguageSetupActivity::class.java)
                        }
                        startActivity(intent)
                        finish()
                    }
                } else {
                    // Fallback for offline, local account, or configuration notice
                    val prefs = getSharedPreferences("LearnlyProfile", MODE_PRIVATE)
                    val savedEmail = prefs.getString("userEmail", "") ?: ""
                    val savedPassword = prefs.getString("userPassword", "") ?: ""

                    if (savedEmail.isNotEmpty() && email.equals(savedEmail, ignoreCase = true) &&
                        (savedPassword.isEmpty() || password == savedPassword)) {
                        GoogleAuthHelper.saveAccount(this, prefs.getString("userName", email.substringBefore("@")) ?: email.substringBefore("@"), email)
                        Toast.makeText(this, "Welcome back! 👋", Toast.LENGTH_SHORT).show()
                        val hasLanguage = prefs.contains("comfortableLanguage") && prefs.contains("learningLanguage")
                        val intent = if (hasLanguage) Intent(this, HomeActivity::class.java) else Intent(this, LanguageSetupActivity::class.java)
                        startActivity(intent)
                        finish()
                    } else if (errorMsg != null && (errorMsg.contains("CONFIGURATION_NOT_FOUND", ignoreCase = true) ||
                                                    errorMsg.contains("network", ignoreCase = true) ||
                                                    errorMsg.contains("service", ignoreCase = true) ||
                                                    errorMsg.contains("internal error", ignoreCase = true))) {
                        prefs.edit().putString("userEmail", email).putString("userPassword", password).putString("userRole", "student").apply()
                        GoogleAuthHelper.saveAccount(this, prefs.getString("userName", email.substringBefore("@")) ?: email.substringBefore("@"), email)
                        Toast.makeText(this, "Welcome back! 👋", Toast.LENGTH_SHORT).show()
                        val hasLanguage = prefs.contains("comfortableLanguage") && prefs.contains("learningLanguage")
                        val intent = if (hasLanguage) Intent(this, HomeActivity::class.java) else Intent(this, LanguageSetupActivity::class.java)
                        startActivity(intent)
                        finish()
                    } else {
                        Toast.makeText(this, errorMsg ?: "Invalid email or password", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }

        btnGoogle.setOnClickListener {
            val filterQuery = edtEmail.text.toString().trim().ifEmpty { null }
            GoogleAuthHelper.showAccountChooser(this, filterQuery) { _, _ ->
                val prefs = getSharedPreferences("LearnlyProfile", MODE_PRIVATE)
                val langConfigured = prefs.getBoolean("hasLanguageConfigured", false)
                val intent = if (langConfigured) {
                    Intent(this, HomeActivity::class.java)
                } else {
                    Intent(this, LanguageSetupActivity::class.java)
                }
                startActivity(intent)
                finish()
            }
        }

        txtCreateAccount.setOnClickListener {
            val intent = Intent(this, CreateAccountActivity::class.java)
            startActivity(intent)
            finish()
        }
    }
}