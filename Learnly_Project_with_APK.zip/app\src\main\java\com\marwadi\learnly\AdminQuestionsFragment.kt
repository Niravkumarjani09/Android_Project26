package com.marwadi.learnly

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment

class AdminQuestionsFragment : Fragment() {

    private lateinit var edtSearchQuestions: EditText
    private lateinit var questionsContainer: LinearLayout
    private lateinit var chipAll: TextView
    private lateinit var chipWords: TextView
    private lateinit var chipSentences: TextView
    private lateinit var chipGrammar: TextView

    private var selectedCategory: String = "All"
    private var searchQuery: String = ""

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_admin_questions, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        edtSearchQuestions = view.findViewById(R.id.edtSearchQuestions)
        questionsContainer = view.findViewById(R.id.adminQuestionsContainer)
        chipAll = view.findViewById(R.id.chipFilterAllQuestions)
        chipWords = view.findViewById(R.id.chipFilterVocabulary)
        chipSentences = view.findViewById(R.id.chipFilterSentences)
        chipGrammar = view.findViewById(R.id.chipFilterGrammarQ)

        val btnAddQuestionTop = view.findViewById<ImageButton>(R.id.btnAddQuestionTop)
        btnAddQuestionTop.setOnClickListener {
            val intent = Intent(requireContext(), AdminAddQuestionActivity::class.java)
            startActivity(intent)
        }

        chipAll.setOnClickListener { setFilter("All") }
        chipWords.setOnClickListener { setFilter("Vocabulary") }
        chipSentences.setOnClickListener { setFilter("Sentence") }
        chipGrammar.setOnClickListener { setFilter("Grammar") }

        edtSearchQuestions.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                searchQuery = s?.toString()?.trim() ?: ""
                renderQuestions()
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        renderQuestions()
    }

    override fun onResume() {
        super.onResume()
        renderQuestions()
    }

    private fun setFilter(category: String) {
        selectedCategory = category

        val chips = listOf(chipAll, chipWords, chipSentences, chipGrammar)
        for (c in chips) {
            c.setBackgroundResource(R.drawable.bg_admin_chip_unselected)
            c.setTextColor(resources.getColor(R.color.text_body, null))
        }

        val activeChip = when (category) {
            "Vocabulary" -> chipWords
            "Sentence" -> chipSentences
            "Grammar" -> chipGrammar
            else -> chipAll
        }

        activeChip.setBackgroundResource(R.drawable.bg_admin_chip_selected)
        activeChip.setTextColor(resources.getColor(R.color.white, null))

        renderQuestions()
    }

    private fun renderQuestions() {
        questionsContainer.removeAllViews()
        val inflater = LayoutInflater.from(requireContext())
        var questions = AdminDataRepository.getQuestions()

        if (selectedCategory != "All") {
            questions = questions.filter { it.categoryTag.equals(selectedCategory, ignoreCase = true) }
        }

        if (searchQuery.isNotEmpty()) {
            questions = questions.filter {
                it.questionText.contains(searchQuery, ignoreCase = true) ||
                it.categoryTag.contains(searchQuery, ignoreCase = true) ||
                it.sourceLanguage.contains(searchQuery, ignoreCase = true) ||
                it.targetLanguage.contains(searchQuery, ignoreCase = true)
            }
        }

        if (questions.isEmpty()) {
            val emptyView = TextView(requireContext()).apply {
                text = "No questions found matching criteria"
                setTextColor(resources.getColor(R.color.text_muted, null))
                textSize = 14f
                setPadding(20, 60, 20, 40)
                gravity = android.view.Gravity.CENTER
            }
            questionsContainer.addView(emptyView)
            return
        }

        for (question in questions) {
            val itemView = inflater.inflate(R.layout.item_admin_question, questionsContainer, false)
            val txtTag = itemView.findViewById<TextView>(R.id.txtQuestionCategoryTag)
            val txtText = itemView.findViewById<TextView>(R.id.txtQuestionText)
            val txtLanguagePair = itemView.findViewById<TextView>(R.id.txtQuestionLanguagePair)
            val txtOptionsCount = itemView.findViewById<TextView>(R.id.txtQuestionOptionsCount)
            val btnEdit = itemView.findViewById<ImageButton>(R.id.btnEditQuestion)
            val btnDelete = itemView.findViewById<ImageButton>(R.id.btnDeleteQuestion)

            txtTag.text = question.categoryTag
            txtText.text = question.questionText
            txtLanguagePair.text = "${question.sourceLanguage} → ${question.targetLanguage}"
            txtOptionsCount.text = "${question.options.size} options"

            when (question.categoryTag) {
                "Vocabulary" -> {
                    txtTag.setBackgroundResource(R.drawable.bg_badge_active)
                    txtTag.setTextColor(resources.getColor(R.color.brand_green_dark, null))
                }
                "Sentence" -> {
                    txtTag.setBackgroundResource(R.drawable.bg_badge_tag)
                    txtTag.setTextColor(resources.getColor(R.color.accent_purple_card_start, null))
                }
                else -> {
                    txtTag.setBackgroundResource(R.drawable.bg_badge_tag)
                    txtTag.setTextColor(resources.getColor(R.color.brand_primary, null))
                }
            }

            btnEdit.setOnClickListener {
                val intent = Intent(requireContext(), AdminAddQuestionActivity::class.java).apply {
                    putExtra("EXTRA_QUESTION", question)
                }
                startActivity(intent)
            }

            btnDelete.setOnClickListener {
                AlertDialog.Builder(requireContext())
                    .setTitle("Delete Question")
                    .setMessage("Are you sure you want to delete this question?")
                    .setPositiveButton("Delete") { _, _ ->
                        AdminDataRepository.deleteQuestion(question.id)
                        Toast.makeText(requireContext(), "Question deleted", Toast.LENGTH_SHORT).show()
                        renderQuestions()
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            }

            questionsContainer.addView(itemView)
        }
    }
}

