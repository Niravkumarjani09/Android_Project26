package com.marwadi.learnly

import android.content.Context
import org.json.JSONObject

object AdminDataRepository {

    private val lessonsList = mutableListOf(
        AdminLesson("les_1", "Basic Words", "Learn essential vocabulary", "Basic Words", "English", "Gujarati", 12),
        AdminLesson("les_2", "Basic Sentences", "Practice common sentences", "Basic Sentences", "English", "Gujarati", 10),
        AdminLesson("les_3", "Everyday Grammar", "Understand basic grammar", "Everyday Grammar", "English", "Gujarati", 15),
        AdminLesson("les_4", "મૂળભૂત શબ્દો", "Learn essential vocabulary", "Basic Words", "Gujarati", "English", 12),
        AdminLesson("les_5", "મૂળભૂત વાક્યો", "Practice common sentences", "Basic Sentences", "Gujarati", "English", 10)
    )

    private val questionsList = mutableListOf(
        AdminQuestion(
            id = "q_1",
            lessonId = "les_1",
            questionText = "What is the meaning of 'Apple'?",
            categoryTag = "Vocabulary",
            sourceLanguage = "English",
            targetLanguage = "Gujarati",
            options = listOf("સફરજન", "કેળું", "કેરી", "દ્રાક્ષ"),
            correctAnswerIndex = 0,
            explanation = "Apple translates directly to સફરજન in Gujarati."
        ),
        AdminQuestion(
            id = "q_2",
            lessonId = "les_2",
            questionText = "Translate to English: 'હું ઘરે જાઉં છું'",
            categoryTag = "Sentence",
            sourceLanguage = "Gujarati",
            targetLanguage = "English",
            options = listOf("I am going home", "I eat food", "Where is home", "We go home"),
            correctAnswerIndex = 0,
            explanation = "'હું' is I, 'ઘરે' is home, and 'જાઉં છું' is going."
        ),
        AdminQuestion(
            id = "q_3",
            lessonId = "les_3",
            questionText = "Choose the correct form: 'He ___ a book.'",
            categoryTag = "Grammar",
            sourceLanguage = "English",
            targetLanguage = "Gujarati",
            options = listOf("read", "reads", "reading", "is read"),
            correctAnswerIndex = 1,
            explanation = "Third-person singular present tense takes 'reads'."
        ),
        AdminQuestion(
            id = "q_4",
            lessonId = "les_1",
            questionText = "Which word means 'Water'?",
            categoryTag = "Vocabulary",
            sourceLanguage = "English",
            targetLanguage = "Gujarati",
            options = listOf("પાણી", "હવા", "અગ્નિ", "જમીન"),
            correctAnswerIndex = 0,
            explanation = "'Water' is translated as 'પાણી'."
        )
    )

    private val studentsList = mutableListOf(
        AdminStudent("std_1", "Aarav Patel", "aarav@gmail.com", true, accuracy = 98, streak = 14, puzzlesCompleted = 24, totalXP = 2850),
        AdminStudent("std_2", "Hetvi Shah", "hetvi@gmail.com", true, accuracy = 95, streak = 12, puzzlesCompleted = 19, totalXP = 2450),
        AdminStudent("std_3", "Rohan Mehta", "rohan@gmail.com", true, accuracy = 92, streak = 9, puzzlesCompleted = 16, totalXP = 2210),
        AdminStudent("std_4", "Priya Patel", "priya.p@gmail.com", true, accuracy = 90, streak = 7, puzzlesCompleted = 14, totalXP = 1950),
        AdminStudent("std_5", "Kabir Joshi", "kabir@gmail.com", true, accuracy = 88, streak = 8, puzzlesCompleted = 12, totalXP = 1820),
        AdminStudent("std_6", "Ananya Roy", "ananya@gmail.com", true, accuracy = 86, streak = 6, puzzlesCompleted = 10, totalXP = 1650),
        AdminStudent("std_7", "Carlos Gomez", "carlos@gmail.com", true, accuracy = 84, streak = 5, puzzlesCompleted = 8, totalXP = 1520),
        AdminStudent("std_8", "Neha Suthar", "neha@gmail.com", true, accuracy = 85, streak = 6, puzzlesCompleted = 11, totalXP = 1400),
        AdminStudent("std_9", "Dev Malhotra", "dev@gmail.com", true, accuracy = 82, streak = 4, puzzlesCompleted = 7, totalXP = 1290),
        AdminStudent("std_10", "Diya Joshi", "diya@gmail.com", false, accuracy = 74, streak = 2, puzzlesCompleted = 5, totalXP = 1150)
    )

    private val recentActivities = mutableListOf(
        AdminRecentActivity("act_1", "New student registered", "priya.shah@example.com", "2h ago", "student"),
        AdminRecentActivity("act_2", "Lesson updated", "Basic Sentences (English → Gujarati)", "4h ago", "lesson"),
        AdminRecentActivity("act_3", "New quiz question added", "Grammar - 3 questions", "5h ago", "question")
    )

    // Lessons API
    fun getLessons(): List<AdminLesson> = lessonsList.toList()

    fun addLesson(lesson: AdminLesson) {
        lessonsList.add(0, lesson)
        FirebaseHelper.saveLessonToFirestore(lesson)
        recentActivities.add(0, AdminRecentActivity(
            id = "act_${System.currentTimeMillis()}",
            title = "New lesson created",
            subtitle = "${lesson.title} (${lesson.sourceLanguage} → ${lesson.targetLanguage})",
            timeAgo = "Just now",
            type = "lesson"
        ))
    }

    fun updateLesson(lesson: AdminLesson) {
        val index = lessonsList.indexOfFirst { it.id == lesson.id }
        if (index != -1) {
            lessonsList[index] = lesson
            FirebaseHelper.saveLessonToFirestore(lesson)
        }
    }

    fun deleteLesson(id: String) {
        lessonsList.removeAll { it.id == id }
        FirebaseHelper.deleteLessonFromFirestore(id)
    }

    // Questions API
    fun getQuestions(): List<AdminQuestion> = questionsList.toList()

    fun addQuestion(question: AdminQuestion) {
        questionsList.add(0, question)
        FirebaseHelper.saveQuestionToFirestore(question)
        recentActivities.add(0, AdminRecentActivity(
            id = "act_${System.currentTimeMillis()}",
            title = "New quiz question added",
            subtitle = "${question.categoryTag} - ${question.questionText.take(28)}...",
            timeAgo = "Just now",
            type = "question"
        ))
    }

    fun updateQuestion(question: AdminQuestion) {
        val index = questionsList.indexOfFirst { it.id == question.id }
        if (index != -1) {
            questionsList[index] = question
            FirebaseHelper.saveQuestionToFirestore(question)
        }
    }

    fun deleteQuestion(id: String) {
        questionsList.removeAll { it.id == id }
        FirebaseHelper.deleteQuestionFromFirestore(id)
    }

    // Students API
    fun getStudents(): List<AdminStudent> = studentsList.toList()

    fun addStudent(student: AdminStudent) {
        val existingIndex = studentsList.indexOfFirst { it.id == student.id || it.email.equals(student.email, ignoreCase = true) }
        if (existingIndex != -1) {
            studentsList[existingIndex] = student
        } else {
            studentsList.add(0, student)
        }
    }

    fun setStudents(list: List<AdminStudent>) {
        studentsList.clear()
        studentsList.addAll(list)
    }

    fun mergeWithRepository(liveList: List<AdminStudent>): List<AdminStudent> {
        val mergedMap = LinkedHashMap<String, AdminStudent>()
        for (s in liveList) {
            val key = if (s.email.isNotEmpty()) s.email.lowercase() else s.id
            mergedMap[key] = s
        }
        for (s in studentsList) {
            val key = if (s.email.isNotEmpty()) s.email.lowercase() else s.id
            if (!mergedMap.containsKey(key)) {
                mergedMap[key] = s
            }
        }
        val result = mergedMap.values.toList()
        setStudents(result)
        return result
    }

    fun toggleStudentStatus(id: String) {
        val student = studentsList.find { it.id == id }
        student?.let {
            it.isActive = !it.isActive
            FirebaseHelper.updateStudentStatus(it.id, it.isActive)
        }
    }

    fun deleteStudent(id: String) {
        studentsList.removeAll { it.id == id }
    }

    // Recent Activities API
    fun getRecentActivities(): List<AdminRecentActivity> = recentActivities.toList()

    fun addRecentActivity(activity: AdminRecentActivity) {
        recentActivities.add(0, activity)
        if (recentActivities.size > 20) {
            recentActivities.removeAt(recentActivities.size - 1)
        }
    }

    fun initFromSeed(context: Context) {
        if (questionsList.size > 8) return
        try {
            val jsonString = context.assets.open("curriculum_seed.json").bufferedReader().use { it.readText() }
            val root = JSONObject(jsonString)
            val lArray = root.getJSONArray("lessons")
            val qArray = root.getJSONArray("questions")

            lessonsList.clear()
            for (i in 0 until lArray.length()) {
                val item = lArray.getJSONObject(i)
                lessonsList.add(
                    AdminLesson(
                        id = item.getString("id"),
                        title = item.getString("title"),
                        description = item.getString("description"),
                        category = item.getString("category"),
                        sourceLanguage = item.getString("sourceLanguage"),
                        targetLanguage = item.getString("targetLanguage"),
                        questionCount = item.optInt("questionCount", 12)
                    )
                )
            }

            questionsList.clear()
            for (i in 0 until qArray.length()) {
                val item = qArray.getJSONObject(i)
                val optionsJson = item.getJSONArray("options")
                val options = mutableListOf<String>()
                for (j in 0 until optionsJson.length()) {
                    options.add(optionsJson.getString(j))
                }
                questionsList.add(
                    AdminQuestion(
                        id = item.getString("id"),
                        lessonId = item.optString("lessonId", ""),
                        questionText = item.getString("questionText"),
                        categoryTag = item.getString("categoryTag"),
                        sourceLanguage = item.getString("sourceLanguage"),
                        targetLanguage = item.getString("targetLanguage"),
                        options = options,
                        correctAnswerIndex = item.getInt("correctAnswerIndex"),
                        explanation = item.optString("explanation", "")
                    )
                )
            }
        } catch (_: Exception) {}
    }

    // Platform Stats API
    fun getStats(): AdminPlatformStats {
        return AdminPlatformStats(
            totalStudents = 240 + studentsList.size,
            totalLessons = lessonsList.size,
            totalQuestions = questionsList.size,
            puzzlesCompleted = 892
        )
    }
}
