package com.marwadi.learnly

import android.content.Context

/**
 * Unified single source of truth for user statistics (Streak, Total XP, Progress, Accuracy).
 * Ensures 100% consistency across Home, Progress, Profile, and Leaderboard.
 */
object UserStatsHelper {

    fun getStreak(context: Context): Int {
        val prefs = context.getSharedPreferences("LearnlyProfile", Context.MODE_PRIVATE)
        return prefs.getInt("streak", 1).coerceAtLeast(1)
    }

    fun setStreak(context: Context, streak: Int) {
        val prefs = context.getSharedPreferences("LearnlyProfile", Context.MODE_PRIVATE)
        prefs.edit().putInt("streak", streak.coerceAtLeast(1)).apply()
    }

    fun incrementStreak(context: Context): Int {
        val newStreak = getStreak(context) + 1
        setStreak(context, newStreak)
        return newStreak
    }

    fun getAccuracy(context: Context): Int {
        val prefs = context.getSharedPreferences("LearnlyProfile", Context.MODE_PRIVATE)
        return prefs.getInt("accuracy", 100)
    }

    fun setAccuracy(context: Context, accuracy: Int) {
        val prefs = context.getSharedPreferences("LearnlyProfile", Context.MODE_PRIVATE)
        prefs.edit().putInt("accuracy", accuracy.coerceIn(0, 100)).apply()
    }

    /**
     * Unified Total XP formula across the entire application:
     * - Base welcome starter XP on registration: 100 XP
     * - Each completed lesson: 100 XP
     * - Each daily puzzle solved: 50 XP
     * - Extra XP: stored in extraXP
     */
    fun getTotalXP(context: Context): Int {
        val progressPrefs = context.getSharedPreferences("LearnlyProgress", Context.MODE_PRIVATE)
        val completedLessons = progressPrefs.getInt("completedLessons", 0)
        val puzzlesSolved = progressPrefs.getInt("puzzlesSolved", 0)
        val extraXP = progressPrefs.getInt("extraXP", 0)
        val baseXP = 100
        return baseXP + (completedLessons * 100) + (puzzlesSolved * 50) + extraXP
    }

    fun addXP(context: Context, amount: Int) {
        val progressPrefs = context.getSharedPreferences("LearnlyProgress", Context.MODE_PRIVATE)
        val currentExtra = progressPrefs.getInt("extraXP", 0)
        progressPrefs.edit().putInt("extraXP", currentExtra + amount).apply()
    }

    /**
     * Unified overall progress percentage across lessons:
     * Based on completed lessons in Vocabulary (15), Sentences (20), Grammar (15) = 50 total.
     */
    fun getOverallProgressPercent(context: Context): Int {
        val progressPrefs = context.getSharedPreferences("LearnlyProgress", Context.MODE_PRIVATE)
        val words = progressPrefs.getInt("wordsCompleted", 0)
        val sentences = progressPrefs.getInt("sentencesCompleted", 0)
        val grammar = progressPrefs.getInt("grammarCompleted", 0)
        val totalDone = words + sentences + grammar
        val totalAvailable = 50
        return ((totalDone * 100) / totalAvailable).coerceIn(0, 100)
    }

    /**
     * Calculates learning practice time in minutes dynamically:
     * - Starting baseline: 5 mins for registration/profile setup
     * - Completed lessons: 6 mins each
     * - Puzzles solved: 3 mins each
     * - Extra practice minutes: stored in practiceMinutes
     */
    fun getPracticeTimeMinutes(context: Context): Int {
        val progressPrefs = context.getSharedPreferences("LearnlyProgress", Context.MODE_PRIVATE)
        val completedLessons = progressPrefs.getInt("completedLessons", 0)
        val puzzlesSolved = progressPrefs.getInt("puzzlesSolved", 0)
        val practiceMinutes = progressPrefs.getInt("practiceMinutes", 0)
        return 5 + (completedLessons * 6) + (puzzlesSolved * 3) + practiceMinutes
    }

    fun addPracticeMinutes(context: Context, minutes: Int) {
        val progressPrefs = context.getSharedPreferences("LearnlyProgress", Context.MODE_PRIVATE)
        val current = progressPrefs.getInt("practiceMinutes", 0)
        progressPrefs.edit().putInt("practiceMinutes", current + minutes).apply()
    }

    /**
     * Formats practice time into total string (e.g. "18 mins" or "1 hr 12 mins")
     * and daily average string (e.g. "Daily avg: 18 mins").
     */
    fun getFormattedStudyTime(context: Context): Pair<String, String> {
        val totalMins = getPracticeTimeMinutes(context)
        val streak = getStreak(context).coerceAtLeast(1)
        val hours = totalMins / 60
        val mins = totalMins % 60

        val totalStr = when {
            hours > 0 && mins > 0 -> "$hours hrs $mins mins"
            hours > 0 -> "$hours hrs"
            else -> "$mins mins"
        }

        val dailyAvg = (totalMins / streak).coerceAtLeast(mins)
        val avgStr = "Daily avg: $dailyAvg mins"

        return Pair(totalStr, avgStr)
    }

    /**
     * Resets stats cleanly for a brand new registered user (Day 1 streak, 100 base XP, 0% progress).
     */
    fun resetStatsForNewUser(context: Context) {
        val profilePrefs = context.getSharedPreferences("LearnlyProfile", Context.MODE_PRIVATE)
        profilePrefs.edit()
            .putInt("streak", 1)
            .putInt("accuracy", 100)
            .apply()

        val progressPrefs = context.getSharedPreferences("LearnlyProgress", Context.MODE_PRIVATE)
        progressPrefs.edit()
            .putInt("completedLessons", 0)
            .putInt("puzzlesSolved", 0)
            .putInt("wordsCompleted", 0)
            .putInt("sentencesCompleted", 0)
            .putInt("grammarCompleted", 0)
            .putInt("practiceMinutes", 0)
            .putInt("extraXP", 0)
            .apply()
    }
}
